1. create folders E:\MERRT3.0\MFMLog
2. Extract MFM.zip into E:\MERRT3.0
3. VPN Connection should be running
4. JDK1.6 should be installed
5. Command prompt run -->startFeedManager.bat