package com.telepacific.merrt.JMX;

class CEPPropertiesReader {

	public String readProperty(String string) {
		// TODO Auto-generated method stub
		
		
		return null;
	}

}
