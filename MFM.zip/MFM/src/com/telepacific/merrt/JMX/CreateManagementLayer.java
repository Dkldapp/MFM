/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.telepacific.merrt.JMX;

import com.telepacific.merrt.JMX.CEPPropertiesReader;


import java.io.IOException;
import java.lang.management.ManagementFactory;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.HashMap;
import java.util.Map;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.rmi.RMIConnectorServer;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;

/**
 * Class to create management layer for functional groups,hosts and components 
 * of an environment and expose the MBean in Tomcat JConsole. This class is developed 
 * in such a way that only one instance of this class will be available in JVM
 * memory irrespective of any number of application environment 
 * or business environment is started.
 * @author 
 */
public class CreateManagementLayer {

    private static JMXServiceURL jmxServerURL = null;
    private static JMXConnector jmxServerConnector = null;
    private static MBeanServer mbeanServer = null;
    private static JMXServiceURL connectorServerURL = null;
    private static JMXConnectorServer connectorServer = null;
    private static CreateManagementLayer createMbeanServer = null;
    private static CEPPropertiesReader cepPropertiesReader = null;
    private static MBeanServerConnection mbeanServerConnection = null;

    /**
     * Singleton Method to get the instance of CreateManagementLayer.
     * This method does the following process
     *  1. Get mbean server from Tomcat server.
     *  2. Create registry using the given port number.
     *  3. Start the JMX mbean server.
     *  4. Create a JMX Client connection
     * @return createMbeanServer CreateManagementLayer instance.
     */
    public static CreateManagementLayer getInstance() {
        if (createMbeanServer == null) {
            createMbeanServer = new CreateManagementLayer();
            cepPropertiesReader = new CEPPropertiesReader();
            createMbeanServer();
            createRegistry();
            startJMXServer();
            createManagementMbeanClientConnection();
        }
        return createMbeanServer;
    }

    public CreateManagementLayer() {
    	
    }

    /**
     * Method to create Tomcat mbean server.
     */
    private static void createMbeanServer() {
        //Tomcat Mbean Server
        //mbeanServer = org.Tomcat.mx.util.MBeanServerLocator.locateTomcat();
        //Default Java MBEanServer
        mbeanServer = ManagementFactory.getPlatformMBeanServer();
    }

    /**
     * Method to create and register mbean for business process.
     * @param argEnvName environment name.
     * @param argFgName business process name.
     * @return objectName the business process object mbean
     */
    public ObjectName FeedProcessJMXMBean(String argEnvName, String argFgName) {
        ObjectName objectName = null;
        FeedProcessJMXMBean feedProcessJMXMBean = null;
        String bpObjectTemplate = null;
        try {
            bpObjectTemplate = "test ";//cepPropertiesReader.readProperty("BP_MBEAN_OBJECT_NAME_TEMPLATE");
          //  bpObjectTemplate = bpObjectTemplate.replaceAll("ENAME", argEnvName);
          //  bpObjectTemplate = bpObjectTemplate.replaceAll("#", argFgName);
            // Construct the ObjectName for the MBean that we will register in MBean Server.
            objectName = new ObjectName(bpObjectTemplate);
            // Create the Business activity MBean
            feedProcessJMXMBean = new FeedProcessJMX();
            // Register the business process mbean
            mbeanServer.registerMBean(feedProcessJMXMBean, objectName);
        } catch (Exception jmxException) {
            System.out.println("JMX Exception Occured=" + jmxException.getMessage());
        }
        return objectName;
    }

    /**
     * Method to create a registry for a given port in CEP Properties file.
     */
    private static void createRegistry() {

        try {
          //  LocateRegistry.createRegistry(Integer.parseInt(cepPropertiesReader.readProperty("FG_HOST_COMP_JMX_PORT_NO")));
        	  LocateRegistry.createRegistry(4646);
        } catch (NumberFormatException e1) {
            e1.printStackTrace();
        } catch (RemoteException e1) {
            e1.printStackTrace();
        }
    }

    /**
     * Method to start JMX Server for the given URL in CEP Properties file.
     */
    private static void startJMXServer() {
        Map<String,String> env = new HashMap<String,String>(1);
        try {
            env.put(RMIConnectorServer.JNDI_REBIND_ATTRIBUTE, "true");
            //connectorServerURL = new JMXServiceURL(cepPropertiesReader.readProperty("FG_HOST_COMP_JMX_SERVER_URL"));
            connectorServerURL = new JMXServiceURL("service:jmx:rmi://10.105.156.155:4646/jndi/rmi:// 10.105.156.155:4646/jmxrmi");
            connectorServer = JMXConnectorServerFactory.newJMXConnectorServer(connectorServerURL,
                    env, mbeanServer);
            connectorServer.start();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to unregister the eMapIT License Mbean
     */
    public void unRegisterEmapITLicenseMBean() {
        ObjectName licenseMbeanObject = null;
        try {
          //  licenseMbeanObject = new ObjectName(cepPropertiesReader.readProperty("EMAPIT_LICENSE_MBEAN_OBJECT_NAME_TEMPLATE"));
        	  licenseMbeanObject = new ObjectName("Testing license");
            mbeanServer.unregisterMBean(licenseMbeanObject);
        } catch (MalformedObjectNameException ex) {
            System.out.println("Exception in Class LicenseValidator:unRegisterEmapITMBean():" + ex.getMessage());
        } catch (NullPointerException ex) {
            System.out.println("Exception in Class LicenseValidator:unRegisterEmapITMBean():" + ex.getMessage());
        } catch (InstanceNotFoundException ex) {
            System.out.println("Exception in Class LicenseValidator:unRegisterEmapITMBean():" + ex.getMessage());
        } catch (MBeanRegistrationException ex) {
            System.out.println("Exception in Class LicenseValidator:unRegisterEmapITMBean():" + ex.getMessage());
        }
    }

    /**
     * Method to create mbean server client connection.
     */
    private static void createManagementMbeanClientConnection() {
        try {
            //jmxServerURL = new JMXServiceURL(cepPropertiesReader.readProperty("FG_HOST_COMP_JMX_SERVER_URL"));
        	jmxServerURL = new JMXServiceURL("service:jmx:rmi://10.105.156.155:4646/jndi/rmi://10.105.156.155:4646/jmxrmi");
            jmxServerConnector = JMXConnectorFactory.connect(jmxServerURL, null);
            mbeanServerConnection = jmxServerConnector.getMBeanServerConnection();
            System.out.println("JMX Management Connection Created Successfully.");
        } catch (Exception jmxException) {
            System.out.println("JMX Exception Occured=" + jmxException.getMessage());
        }
    }

    /**
     * Method to get client connection.
     * @return mbeanServerConnection MBeanServerConnection instance.
     */
    public MBeanServerConnection getManagementMbeanClientConnection() {
        return mbeanServerConnection;
    }

    /**
     * Get mbean server instance.
     * @return mbeanServer Tomcat mbean server.
     */
    public MBeanServer getMBeanServer() {
        return mbeanServer;
    }
}
