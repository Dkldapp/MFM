/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telepacific.merrt.JMX;

import javax.management.NotificationBroadcasterSupport;
import java.util.Date;
import com.telepacific.merrt.mfm.MFMInitialize;
/**
 * Class for Setting the attributes value of business process. This class also sends
 * notification on value change of a attribute.
 * @author 
 */
public class FeedProcessJMX extends NotificationBroadcasterSupport implements FeedProcessJMXMBean {
   
    private int feedHandlerID = 0;
    private String feedHandlerName = null;
    private String serverLocation = null;
    private String folderName = null;
    private Date lastProcessedFeedFile = null;
    private String FeedHandlerStatus = null;
    private MFMInitialize mfmInitialize = null;
    
	public int getFeedHandlerID() {
		return feedHandlerID;
	}
	public void setFeedHandlerID(int feedHandlerID) {
		this.feedHandlerID = feedHandlerID;
	}
	public String getFeedHandlerName() {
		return feedHandlerName;
	}
	public void setFeedHandlerName(String feedHandlerName) {
		this.feedHandlerName = feedHandlerName;
	}
	public String getServerLocation() {
		return serverLocation;
	}
	public void setServerLocation(String serverLocation) {
		this.serverLocation = serverLocation;
	}
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public Date getLastProcessedFeedFile() {
		return lastProcessedFeedFile;
	}
	public void setLastProcessedFeedFile(Date lastProcessedFeedFile) {
		this.lastProcessedFeedFile = lastProcessedFeedFile;
	}
	public String getFeedHandlerStatus() {
		return FeedHandlerStatus;
	}
	public void setFeedHandlerStatus(String feedHandlerStatus) {
		FeedHandlerStatus = feedHandlerStatus;
	}
    
	public void stopFeedHandler(){
		
		MFMInitialize.feedHandlerStop(getFeedHandlerID());
	}
	public void restartFeedHandler(){
		MFMInitialize.feedHandlerRestart(getFeedHandlerID());
	}
}
