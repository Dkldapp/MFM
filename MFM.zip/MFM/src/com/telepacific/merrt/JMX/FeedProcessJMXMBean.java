/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telepacific.merrt.JMX;

import java.util.Date;

/**
 * Interface for business process that has attribute method definitions.
 * @author 
 */
public interface FeedProcessJMXMBean {

	public int getFeedHandlerID();
	public void setFeedHandlerID(int feedHandlerID);
	public String getFeedHandlerName();
	public void setFeedHandlerName(String feedHandlerName);
	public String getServerLocation();
	public void setServerLocation(String serverLocation);
	public String getFolderName(); 
	public void setFolderName(String folderName);
	public Date getLastProcessedFeedFile();
	public void setLastProcessedFeedFile(Date lastProcessedFeedFile);
	public String getFeedHandlerStatus();
	public void setFeedHandlerStatus(String feedHandlerStatus);
	public void stopFeedHandler();
	public void restartFeedHandler();
     

}
