package com.telepacific.merrt.JMX;

import java.lang.management.ManagementFactory;
import java.util.Hashtable;

import javax.management.MBeanServer;
import javax.management.ObjectName;


import com.telepacific.merrt.feedmanager.dataprocessor.DataProcessorThread;



public class JMXMain {

    
	
	 public static void main(String[] args) throws Exception {
	        // Get the Platform MBean Server
	        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

		// Construct the ObjectName for the Hello MBean we will register
		ObjectName mbeanName = new ObjectName("com.telepacific.merrt.JMX:type=FeedManagerControl");
		//mbeanName.

		// Create the Hello World MBean
		FeedProcessJMX mbean = new FeedProcessJMX();

		// Register the Hello World MBean
		mbs.registerMBean(mbean, mbeanName);
		
		Hashtable<Integer, DataProcessorThread> threads = new Hashtable<Integer, DataProcessorThread>();
		DataProcessorThread [] arrayDataProcessorThread;
		
		arrayDataProcessorThread = null; //DataProcessorManagerBusiness.getInstance().getDataFeedThreads();
		
		
		if (arrayDataProcessorThread.length > 0){
			
			for (int i=0;arrayDataProcessorThread.length >0; i++)
				System.out.println(" Thread Name1 "+arrayDataProcessorThread[i]);
			
		} else {
			System.out.println(" Wait thread initializiang in progress. Please try JConsole after 10 mins...");
		}
		
	        // Wait forever
	     //   System.out.println("Waiting for incoming requests...");
	        //Thread.sleep(Long.MAX_VALUE);
	    }
}
