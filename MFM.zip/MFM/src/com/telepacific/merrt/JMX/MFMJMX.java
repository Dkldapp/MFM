package com.telepacific.merrt.JMX;

import javax.management.NotificationBroadcasterSupport;

import com.telepacific.merrt.mfm.MFMInitialize;

/**
 * Class for Setting the attributes value of business process. This class also sends
 * notification on value change of a attribute.
 * @author 
 */
public class MFMJMX extends NotificationBroadcasterSupport implements MFMJMXMBean {
   
	
    private int MFMID = 0;
    private String MFMName = null;
    private String serverLocation = null;
    private boolean MFMStatus;
    private int JMXPort = 0;
    private int sequenceNumber = 0;
    private MFMInitialize mfmInitialize = null;

	public int getMFMID() {
		return MFMID;
	}

	public void setMFMID(int mFMID) {
		MFMID = mFMID;
	}

	public String getMFMName() {
		return MFMName;
	}

	public void setMFMName(String mFMName) {
		MFMName = mFMName;
	}
	public String getServerLocation() {
		return serverLocation;
	}

	public void setServerLocation(String serverLocation) {
		this.serverLocation = serverLocation;
	}

	public int getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public boolean getMFMStatus() {
		return MFMStatus;
	}

	public int getJMXPort() {
		return JMXPort;
	}

	public void setJMXPort(int jMXPort) {
		JMXPort = jMXPort;
	}

	public void stopMFM(){
		MFMInitialize.mfmShutDown();
		
	}
	
	public void restartMFM(){
		MFMInitialize.mfmRestart();
	}    
}
