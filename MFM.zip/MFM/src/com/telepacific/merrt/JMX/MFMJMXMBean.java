
package com.telepacific.merrt.JMX;

import com.telepacific.merrt.mfm.MFMInitialize;


/**
 * Interface for business process that has attribute method definitions.
 * @author 
 */
public interface MFMJMXMBean {
  
	public int getMFMID();

	public void setMFMID(int mFMID);

	public String getMFMName();

	public void setMFMName(String mFMName);

	public String getServerLocation();

	public void setServerLocation(String serverLocation);

	public boolean getMFMStatus();
	
	public int getJMXPort();
	
	public void setJMXPort(int jMXPort);
	
	
	public void stopMFM();
	
	public void restartMFM();
	
}
