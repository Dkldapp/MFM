package com.telepacific.merrt.config;

public class MFMFeedMapping {

	public int getMFMId() {
		return MFMId;
	}
	public void setMFMId(int mFMId) {
		MFMId = mFMId;
	}
	public int getDataFeedId() {
		return dataFeedId;
	}
	public void setDataFeedId(int dataFeedId) {
		this.dataFeedId = dataFeedId;
	}
	private int MFMId;
	private int dataFeedId;
}
