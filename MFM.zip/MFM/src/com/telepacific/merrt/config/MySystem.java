/**
 * <p>Title: MySystem</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.config;

public class MySystem {
    public MySystem() {

    }

    public static void out() {
        System.out.println();
    }
}
