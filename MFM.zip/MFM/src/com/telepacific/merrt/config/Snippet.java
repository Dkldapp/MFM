package com.telepacific.merrt.config;

public class Snippet {
	public static void main(String[] args) {
	//	com.telepacific.merrt.config.config
	}
}

