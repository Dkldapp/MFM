/**
 * <p>Title: DataFeed</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafeed;

import java.util.Date;

public class DataFeed {
    public static final int PROCESS_TYPE_ARCHIVE_ONLY = 0;
    public static final int PROCESS_TYPE_DATABASE_ONLY = 1;
    public static final int PROCESS_TYPE_ARCHIVE_AND_DATABASE = 2;

    private int dataFeedID;
    private String dataFeedName;
    private String displayName;
    private int dataTypeID;
    private String path;
    private String databaseName;
    private String fileMask;
    private int tableExpire;
    private int processTypeID;
    private String tableName;
    private boolean continuous;
    private String region;
    private boolean enabled;
    private int sourceTypeID;
    private String inputJDBC;
    private String inputDbDriver;
    private String inputTable;
    private int pollInterval;
    private String inputTableWhere;
    private Date dateLastPoll;
    private String lastPollObj;
    private long lastPollIndex;
    private boolean offline;






	public DataFeed() {

    }
	


    public boolean isContinuous() {
        return continuous;
    }

    public void setContinuous(boolean continuous) {
        this.continuous = continuous;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }


    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public int getDataFeedID() {
        return dataFeedID;
    }

    public void setDataFeedID(int dataFeedID) {
        this.dataFeedID = dataFeedID;
    }

    public String getDataFeedName() {
        return dataFeedName;
    }

    public void setDataFeedName(String dataFeedName) {
        this.dataFeedName = dataFeedName;
    }

    public int getDataTypeID() {
        return dataTypeID;
    }

    public void setDataTypeID(int dataTypeID) {
        this.dataTypeID = dataTypeID;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getFileMask() {
        return fileMask;
    }

    public void setFileMask(String fileMask) {
        this.fileMask = fileMask;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getProcessTypeID() {
        return processTypeID;
    }

    public void setProcessTypeID(int processTypeID) {
        this.processTypeID = processTypeID;
    }

    public int getTableExpire() {
        return tableExpire;
    }

    public void setTableExpire(int tableExpire) {
        this.tableExpire = tableExpire;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }


    public Date getDateLastPoll() {
        return dateLastPoll;
    }

    public void setDateLastPoll(Date dateLastPoll) {
        this.dateLastPoll = dateLastPoll;
    }

    public String getInputDbDriver() {
        return inputDbDriver;
    }

    public void setInputDbDriver(String inputDbDriver) {
        this.inputDbDriver = inputDbDriver;
    }

    public String getInputJDBC() {
        return inputJDBC;
    }

    public void setInputJDBC(String inputJDBC) {
        this.inputJDBC = inputJDBC;
    }

    public String getInputTable() {
        return inputTable;
    }

    public void setInputTable(String inputTable) {
        this.inputTable = inputTable;
    }

    public String getInputTableWhere() {
        return inputTableWhere;
    }

    public void setInputTableWhere(String inputTableWhere) {
        this.inputTableWhere = inputTableWhere;
    }

    public long getLastPollIndex() {
        return lastPollIndex;
    }

    public void setLastPollIndex(long lastPollIndex) {
        this.lastPollIndex = lastPollIndex;
    }

    public String getLastPollObj() {
        return lastPollObj;
    }

    public void setLastPollObj(String lastPollObj) {
        this.lastPollObj = lastPollObj;
    }

    public int getPollInterval() {
        return pollInterval;
    }

    public void setPollInterval(int pollInterval) {
        this.pollInterval = pollInterval;
    }

    public int getSourceTypeID() {
        return sourceTypeID;
    }

    public void setSourceTypeID(int sourceTypeID) {
        this.sourceTypeID = sourceTypeID;
    }


    public boolean isOffline() {
        return offline;
    }

    public void setOffline(boolean offline) {
        this.offline = offline;
    }
}
