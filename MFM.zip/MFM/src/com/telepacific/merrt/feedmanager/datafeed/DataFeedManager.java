/**
 * <p>Title: DataFeedManagerBusiness</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafeed;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.telepacific.merrt.feedmanager.datafeed.DataFeed;
import com.telepacific.merrt.feedmanager.datafeed.DataFeedManagerDAO;

public class DataFeedManager {
	
	private Hashtable<Integer, DataFeed> hmDataFeed = new Hashtable<Integer, DataFeed>();

    private static DataFeedManager instance = null;
    private static DataFeedManagerDAO dataFeedMgrDAO;
    
	Logger log = Logger.getLogger(DataFeedManager.class);
    
    public static DataFeedManager getInstance() {
    	
        if (instance == null) {
            instance = new DataFeedManager();
            if (dataFeedMgrDAO == null)
            	dataFeedMgrDAO = new DataFeedManagerDAO();
        }
        return instance;
        
    }

    private DataFeedManager() {
    	try{
	    	DataFeed[] dataFeed = new DataFeedManagerDAO().getDataFeed();
	    	int i =0;
	    	while ( i < dataFeed.length)
	    	{
	    		hmDataFeed.put(dataFeed[i].getDataFeedID(),dataFeed[i]);
	    		i++;
	    	}
    	}catch(Exception e){
    		log.error(" DataFeedManager() "+e.toString());
    	}
    }

    public Hashtable getDataFeed(){
    	return hmDataFeed;
    }
	public DataFeed getDataFeed(int dataFeedID) {
        return hmDataFeed.get(dataFeedID);
    }

        
	public void setDataFeed(DataFeed dataFeed) {
		hmDataFeed.put(dataFeed.getDataFeedID(),dataFeed);
		
    }
   
	public void delete(DataFeed dataFeed) {
		hmDataFeed.remove(dataFeed.getDataFeedID());
    }
}
