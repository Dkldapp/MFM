/**
 * <p>Title: DataFeedManagerDAO</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafeed;

import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.feedmanager.datafeed.DataFeed;
import com.telepacific.merrt.feedmanager.datafeed.DataFeedManager;

import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

public class DataFeedManagerDAO{
    public DataFeedManagerDAO() {

    }

    
	public DataFeed[] getDataFeed() {
        //System.out.println("########DataFeedManagerDAO.getDataFeed()########");
        List data = new Vector();
        Transaction tx = null;


        Session session = InitSessionFactory.getInstance().getCurrentSession();

        tx = session.beginTransaction();
        data = session.createQuery("select u from DataFeed as u").list();
        tx.commit();
        DataFeed[] rtn = (DataFeed[]) data.toArray(new DataFeed[data.size()]);
        Arrays.sort(rtn, new Comparator<DataFeed>() {
            @Override
			public int compare(DataFeed o1, DataFeed o2) {
                return o2.getDataFeedName().compareTo(o1.getDataFeedName());
            }
        });
        
        return rtn;
    }

    
	public DataFeed getDataFeed(int dataFeedID) {
        return null;
    }


	public void reload() {

    }


	public DataFeed setDataFeed(DataFeed dataFeed) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (dataFeed.getDataFeedID() <= 0) {
                session.save(dataFeed);
            } else {
                session.update(dataFeed);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return dataFeed;
    }


	public void delete(DataFeed dataFeed) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(dataFeed);
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }
}
