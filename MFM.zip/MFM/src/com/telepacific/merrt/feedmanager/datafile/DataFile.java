/**
 * <p>Title: DataFile</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafile;

import com.telepacific.merrt.config.SystemManager;
import com.telepacific.merrt.feedmanager.dataprocessor.DataProcessorThread;
import com.telepacific.merrt.feedmanager.datatype.DataType;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManager;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.record.Record;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManager;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordField;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManager;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManagerBusiness;
import com.telepacific.merrt.feedmanager.usagefile.utils.BCD;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

public class DataFile {
	
    private DataType dataType;
    private static DataTypeManager dataTypeManager = DataTypeManagerBusiness.getInstance();
    private static RecordManager recordManager = RecordManagerBusiness.getInstance();
    private static RecordFieldManager recordFieldManager = RecordFieldManagerBusiness.getInstance();
    private File file;
    private boolean demo_mode = false;

    private long records = 0;
    private long errorRecords = 0;
    private long earliestRecordDate = 0;
    private long record_parsed = 0;
    private Hashtable<String, BufferedWriter> fileWriters = new Hashtable<String, BufferedWriter>();
    private ArrayList<String> files = new ArrayList<String>();
    private BufferedWriter errorLogWriter = null;

    final String[] formats = new String[1];

    Logger log = Logger.getLogger(DataProcessorThread.class);
    
    public DataFile(DataType dataType, File file) {
    	
    	
//    	
//    	if(dataType.getDataTypeID()==16)
//    	{
//    		this.file = file;
//    		runMomentumFeeds(dataType.getDataTypeID(),file);
//    	
//    	}
    	
        if (demo_mode) {
        	log.info("############RUNNING IN DEMO MODE!############");
            SystemManager.getInstance().println("############RUNNING IN DEMO MODE!############");
        }
        formats[0] = "yyyy-MM-dd HH:mm:ss.0";

        earliestRecordDate = 0;
        this.dataType = dataType;
        this.file = file;
        FileInputStream fis = null;
        int iBuffer;
        int iPosition = 0;

        StringBuffer datarecord = new StringBuffer();
        StringBuffer strRecordLength = new StringBuffer();
        int iRecordLength = 0;
        long iNewRecordIndex = (dataType.getHeaderLength() > 0 ? dataType.getHeaderLength() + 1 : 0);
        boolean newrecord = false;
        try {
            fis = new FileInputStream(file);
            int i = -1;
            while (true) {
                i++;
                iBuffer = fis.read();
                if (iBuffer < 0) {
                    break;
                }

                if (dataType.getHeaderLength() == 0 || (i) > dataType.getHeaderLength()) {
                    if (iBuffer < 0) {
                        iBuffer += 256;
                    }
                    if (newrecord || iPosition > 500) {
                        iPosition = 0;
                        try {
                            parseRecord(datarecord);
                        } catch (Exception error) {
                            if (datarecord.indexOf("aa090") == -1) {
                                error.printStackTrace();
                                
                                SystemManager.getInstance().println(error + " - " + datarecord + " - " + record_parsed);
                            }
                        }
                        datarecord = new StringBuffer();
                        newrecord = false;
                    }

                    if (dataType.isBcd()) {
                        
                        try {
                            datarecord.append(BCD.formatByte(BCD.getHighOrder(iBuffer)));
                            datarecord.append(BCD.formatByte(BCD.getLowOrder(iBuffer)));
                            iPosition ++;
//                      
                        } catch(Exception error) {
                            SystemManager.getInstance().println(file.getName());
                            error.printStackTrace();
                        }
                        //System.out.println(iBuffer);
                        //}
//                        System.out.print(BCD.formatByte(BCD.getHighOrder(iBuffer)));
//                        System.out.print(BCD.formatByte(BCD.getLowOrder(iBuffer)));


                        if (i >= (iNewRecordIndex)) {
                            strRecordLength.append(BCD.formatByte(BCD.getHighOrder(iBuffer))).append(BCD.formatByte(BCD.getLowOrder(iBuffer)));
                        }

                        if (strRecordLength.length() == 4) {
                            try {
                                iRecordLength = Integer.valueOf(strRecordLength.toString(), 16).intValue();
                                if (strRecordLength.toString().equals("003f")) {
//                                    System.out.println(strRecordLength + " - " + iRecordLength + " is record length.");
//                                    System.out.println("FOUND 003F######");
//                                    iRecordLength = 63 * 2;
                                }
                                if (strRecordLength.toString().equals("0037")) {
                                    iRecordLength = 55;//iRecordLength * 2;
//                                    System.err.println("--" + iRecordLength + " - " + strRecordLength + " - " + iNewRecordIndex);
                                }
                            } catch (Exception error) {
                                error.printStackTrace();
                            }

                            if (iRecordLength > 300) {
                                iRecordLength = 4;
                            }

                            iNewRecordIndex += iRecordLength;
                            strRecordLength = new StringBuffer();
                        }
                        if (i == iNewRecordIndex - 1 && i != 0) {
                            newrecord = true;
                        }
                    } else {
                        switch (iBuffer) {
                            case 10:
                                newrecord = true;
                                break;
                            case 13:
                                break;
                            default:
                                datarecord.append((char) iBuffer);
                        }
                        if (dataType.getFixedRecordLength() > 0 && datarecord.length() == dataType.getFixedRecordLength()) {
                            newrecord = true;
                        }
                    }
                }
            }

            try {
            	// no validation for mobile data here
            	if (dataType.getDataTypeID() == 15){
            		files.add(file.getAbsolutePath());
            		
            	} else { // validation for other than mobile data files.
            		parseRecord(datarecord);
            	}
                
            } catch (Exception error) {
                //error.printStackTrace();
                if (datarecord.indexOf("aa090") == -1) {
                    error.printStackTrace();
                    SystemManager.getInstance().println(error + " - " + datarecord + " - " + record_parsed);
                }
                log.error("Error in catch of files.add(file.getAbsolutePath()"+error.toString());
            }
            this.closeWriters();
            fis.close();
        } catch (Exception error) {
            log.error("Error in constructor "+error.toString());
        }
    }

  /*  private void runMomentumFeeds(int dataTypeID, File mfile) {
    	
try{
	 long usage = mfile.lastModified();
	  Date usagedate=new Date(usage);
      //csv file containing data
  String strFile = mfile.getAbsolutePath();
  	File f = new File(strFile);
  	
 //	 readfile(f);
  //create BufferedReader to read csv file
  BufferedReader br = new BufferedReader( new FileReader(strFile));
  String strLine = "";
//              StringTokenizer st = null;
  StringBuffer outputRec = new StringBuffer();
 // int lineNumber = 0, tokenNumber = 0;

  //read comma separated file line by line
  while( (strLine = br.readLine()) != null)
  {
	  if(strLine.contains("version") || strLine.contains("Start")||strLine.contains("End"))
	  {
		  
	  }else
	  {
 	 outputRec.append(strLine);
	  }
//             	 tokenNumber=0;
//                      lineNumber++;
//
//                      //break comma separated line using ","
//                      st = new StringTokenizer(strLine, ",");
//
//                      while(st.hasMoreTokens())
//                      {
//                              //display csv values
//                   
//                      }
          outputRec.append("\n");
}
//  for(String s:usernumbers)
//  {
// 	  
//  //  System.out.println("Usrr nambeu valeus "+outputRec.toString());
//  }
 
  

  writeRecord(usagedate,outputRec);
//    System.out.println(" Otput  "+outputRec.toString());
  }
  
  catch(Exception e)
  {
 	 System.out.println("Exception"+e);
  }
    	
    	// TODO Auto-generated method stub
		
	}*/

	private void parseRecord(StringBuffer datarecord) {
        record_parsed ++;
        
//        System.out.println(datarecord + " - Test - " + record_parsed);
        
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS");
        String cdate = null;
        String ctime = null;
        String cdatetime = null;
        String cardatetime = null;

        String cardate = null;
        String reldatetime = null;
        String cartime = null;
        String reldate = null;
        String reltime = null;

        String cduration = null;
        String carduration = null;
        String trunkGroup1 = null;
        String trunkGroup2 = null;
        String trunkGroupMem1 = null;
        String trunkGroupMem2 = null;

        String origNPA = null;
        String origNumber = "";
        String termNPA = null;
        String termNumber = "";
        String overseasInd = null;
        String termNumber101 = null;
        String numberID = null;
        String modNumber = null;
        String lrnRoute1 = null;
        String lrnRoute2 = null;
        String lrn1 = null;
        String lrn2 = null;

        String origLRN = null;
        String termLRN = null;
        String inboundTGN = null;
        String outboundTGN = null;
        String overflowDigits = null;
        String termNumberLength = null;
        String origTermID = null;
        String pos99 = null;
        String ocnOffnetOrig = null;
        String ocnOffnetTerm = null;
        String callingPartyNum = null;
     
        // Hosted PBX Dev Project -4553
        String userNumber=null;	   
        String GroupNumber=null;	   
        String ReceivedCallinNumber=null;	 
        String LastRedirectedNumber=null;
        String ConfigurableCLID=null;	   
        String TerminationCause =null;	   
        String ReleasingParty  = null;	   
        String CallingPresentationIndicator = null;	   
        String CLIDPermitted = null;	   
        String RelatedCallIDreason=null;	   
        String SIPNVITE  =null;	   
        String Codec =null;	   
        String AccessDeviceaddress=null;	   
        String AccessCallID  =  null;	   
        String firstdirectedNumber = null;	   
        String RedirectionReason  = null;	   
        String redirectingpresentationndicator=null;	   
        String Redirectingreason=null;	   
        String TrungGroupName  =null;	   
        String TrunkGroupAction =null;	   
        String SIPErrorCode= null;	   
        String UserGroupID =null;	   
        String CallCategory = null;	   
        String NetworkCallType = null;	   
        String TranslatedNumber= null;	   
        String Route  = null;	   
        String Callrelease=null;
//                                                               
        
        

        String callType = null;

        String callDirection = null;
        String cic = null;
        String authCode = null;
        String dialedNumber = null;

        String structureCode = null;
        String structureCodePrefix = null;
        String tgn360 = null;
        String tgnInd1 = null;
        String tgnInd2 = null;
        String accountCode = null;
        Date usageDate = null;
        int tghit = 0;
        int lrnghit = 0;
        int lrnrghit = 0;
        Hashtable<String, String> output = new Hashtable<String, String>();
        String key = null;
        String keyfull = null;
        String modkey = null;
        RecordField[] flds;
        Record record;
        Record modrecord;
        int recordLength = 0;
        boolean ignore = false;
        String value;
        boolean invalidrecord = false;
        Hashtable<String, Hashtable<Integer, String>> mapvalues = new Hashtable<String, Hashtable<Integer, String>>();
        Hashtable<Integer, String> fldvalues;
 
        if  (dataType.getKeyStart() != 0 || dataType.getKeyLength() != 0) {

/*            if (datarecord.toString().indexOf("002d000000290000aa") != -1) {
                datarecord= new StringBuffer(datarecord.toString().replace("002d000000290000aa", "00290000aa"));
            }
            if (datarecord.toString().indexOf("00ad000000a90000aa") != -1) {
                datarecord= new StringBuffer(datarecord.toString().replace("00ad000000a90000aa", "00a90000aa"));
            }
            if (datarecord.toString().indexOf("005d000000590000aa") != -1) {
                datarecord = new StringBuffer(datarecord.toString().replace("005d000000590000aa", "00590000aa"));
            }
*/
            if (datarecord.length() > dataType.getKeyStart() + dataType.getKeyLength()) {
                if (dataType.getKeyStart() != 0) {
                    keyfull = datarecord.substring(dataType.getKeyStart() -1, dataType.getKeyStart() + dataType.getKeyLength());
                    key = keyfull.substring(1, keyfull.length());
                } else {
                    key = datarecord.substring(dataType.getKeyStart(), dataType.getKeyStart() + dataType.getKeyLength());
                }
//                System.err.println(key);
//                if (keyfull.substring(0,1).equals("1")) {
//                    System.out.println(datarecord.length());
//                }
                if (key != null) {
                    record = recordManager.getRecordByRecordName(key);
                    if (record != null) {
                        flds = recordFieldManager.getRecordFieldByRecordID(record.getRecordID());
//                        System.err.println(datarecord);
                        for (RecordField recordField : flds) {
                            recordLength += recordField.getLength();
                            value = datarecord.substring(recordField.getStart(), recordField.getStart() + recordField.getLength());
                            if (recordField.getMapFieldName() != null) {

                                if (mapvalues.containsKey(recordField.getMapFieldName())) {
                                    fldvalues = mapvalues.get(recordField.getMapFieldName());
                                } else {
                                    fldvalues = new Hashtable<Integer, String>();
                                    mapvalues.put(recordField.getMapFieldName(), fldvalues);
                                }
                                fldvalues.put(new Integer(fldvalues.size()), value);

//                                System.err.println(recordField.getMapFieldName() + " - " + value);
                            }
                        }
                        //System.err.println(datarecord.length() + " - " + recordLength + " - " + datarecord);
//                        System.err.println(datarecord.length() + " - " + recordLength + " - " + record.getRecordName() + " - " + datarecord + " - " + datarecord.substring(dataType.getKeyStart() - 1, dataType.getKeyStart()));
                        if (dataType.getKeyStart() != 0) {
                        	try{
                            switch (new Integer(keyfull.substring(0,1))) {
                                //switch (new Integer(datarecord.substring(dataType.getKeyStart() - 1, dataType.getKeyStart()))) {
                                case 1:
                                    recordLength += 8;
                                    break;
                                case 2:
                                    recordLength += 14;
                                    break;
                                case 4:
                                    break;
                                case 5:
                                    recordLength += 8;
                                    break;
                                case 6:
                                    recordLength += 14;
                                    break;
                                case 7:
                                    recordLength += 22;
                                    break;
                                default:
                            }}
                        	catch(Exception e){
                        		log.error("Exception in Datafile :: "+e);
                        		
                        	}
                        	
                        }

                        if (datarecord.length() > recordLength && dataType.getModKeyLength()>0) {
                            String modules = datarecord.substring(recordLength, datarecord.length());
                            boolean moreMods = true;
                            int modindex = 0;
                            int modLength = 0;
                            //System.err.println(modules);

                            while (modindex < modules.length()) {
                                modkey = modules.substring(modindex + dataType.getModKeyStart(), modindex + dataType.getModKeyStart() + dataType.getModKeyLength());
                                //System.err.println(modkey);
                                modrecord = recordManager.getRecordByRecordName(modkey);
                                if (modrecord != null) {
                                    flds = recordFieldManager.getRecordFieldByRecordID(modrecord.getRecordID());
                                    modLength = 0;
                                    for (RecordField recordField : flds) {
                                        modLength += recordField.getLength();
                                        value = modules.substring(modindex + recordField.getStart(), modindex + recordField.getStart() + recordField.getLength());
                                        if (recordField.getMapFieldName() != null) {
                                            if (mapvalues.containsKey(recordField.getMapFieldName())) {
                                                fldvalues = mapvalues.get(recordField.getMapFieldName());
                                            } else {
                                                fldvalues = new Hashtable<Integer, String>();
                                                mapvalues.put(recordField.getMapFieldName(), fldvalues);
                                            }
                                            fldvalues.put(new Integer(fldvalues.size()), value);
//                                        System.err.println(recordField.getMapFieldName() + " - " + value);
                                        }
//                                    System.err.println(recordField.getFieldName() + " - " + value);
                                    }
                                } else {
                                    break;
                                }
                                modindex += modLength;
                            }

                        }
                    } else {
                        invalidrecord = true;
                    }
                }
            } else {
                invalidrecord = true;
            }
            if (invalidrecord) {
                if (datarecord.length() > 20) {
                    errorRecords++;
                    //System.err.println("record error: " + datarecord);
                    try {
//                        getErrorWriter().write(datarecord.toString() + " - " + record_parsed + "\r\n");
//                        getErrorWriter().flush();
                    } catch (Exception error) {
                        error.printStackTrace();
                    }
                }
            }
        } else {
            //either delimited or fixed length
        
            record = recordManager.getRecordByDataTypeID(dataType.getDataTypeID())[0];

            if (record.getDelimination() != null && record.getDelimination().length() > 0) {
                //delimited
           	
                String[] dvalues = datarecord.toString().split(record.getDelimination());

                flds = recordFieldManager.getRecordFieldByRecordID(record.getRecordID());

                for (RecordField recordField : flds) {
                    if (recordField.getStart() < dvalues.length) {
                        value = dvalues[recordField.getStart()];
                        if (recordField.getMapFieldName() != null) {
                            if (mapvalues.containsKey(recordField.getMapFieldName())) {
                                fldvalues = mapvalues.get(recordField.getMapFieldName());
                            } else {
                                fldvalues = new Hashtable<Integer, String>();
                                mapvalues.put(recordField.getMapFieldName(), fldvalues);
                            }
                            fldvalues.put(new Integer(fldvalues.size()), value);
                        }
                    }
                    
//                    System.err.println(recordField.getFieldName() + " - " + value);
                }
            } else {
                //fixed length
            	
                flds = recordFieldManager.getRecordFieldByRecordID(record.getRecordID());
                
                for (RecordField recordField : flds) {
                	
                    value = datarecord.substring(recordField.getStart(), recordField.getStart() + recordField.getLength());
//                    System.err.println(recordField.getMapFieldName() + " - " + value + " - " + mapvalues.size());
                    if (recordField.getMapFieldName()==null) {
                        recordField.setMapFieldName("");
                    }
                    if (mapvalues.containsKey(recordField.getMapFieldName())) {
                        fldvalues = mapvalues.get(recordField.getMapFieldName());
                    } else {
                        fldvalues = new Hashtable<Integer, String>();
                        mapvalues.put(recordField.getMapFieldName(), fldvalues);
                    }
                    fldvalues.put(new Integer(fldvalues.size()), value);
                }
            }
        }

        if (!invalidrecord) {
    	
            //String mvall;
            for (String mval : mapvalues.keySet()) {
                //mvall = mval.toLowerCase();
                fldvalues = mapvalues.get(mval);
                for (String val : fldvalues.values()) {
//                    if (rf.getLength() > 0) {
                	if(val.contains("version"))
                	{
                		val="";
                	}
                    output.put(mval, val);
//                    }
//                    System.out.println("mval: " + mval + ", val: " + val);
                    if (mval.equals("CONNECT_DATE")) {
                        cdate = val;
                    } else if (mval.equals("CONNECT_TIME")) {
                        ctime = val;
                    } else if (mval.equals("DURATION")) {
                        cduration = val;
                    } else if (mval.equals("CARRIER_CONNECT_DATE")) {
                        cardate = val;
                    } else if (mval.equals("CARRIER_CONNECT_DATE_TIME")) {
                        cardatetime = val;
                    } else if (mval.equals("CONNECT_DATE_TIME")) {
                        cdatetime = val;
                    } else if (mval.equals("RELEASE_DATE_TIME")) {
                        reldatetime = val;
                    } else if (mval.equals("CARRIER_CONNECT_TIME")) {
                        cartime = val;
                    } else if (mval.equals("CARRIER_DURATION")) {
                        carduration = val;
                    } else if (mval.equals("ORIG_NPA")) {
                        origNPA = val;
                    } else if (mval.equals("ORIG_NUMBER")) {
                        origNumber = val;
                    } else if (mval.equals("TERM_NPA")) {
                        termNPA = val;
                    } else if (mval.equals("TERM_NUMBER")) {
                        termNumber = val;
                    } else if (mval.equals("DIALED_NUMBER")) {
                        dialedNumber = val;
                    } else if (mval.equals("OVERSEAS_IND")) {
                        overseasInd = val;
                    } else if (mval.equals("CALL_DIRECTION")) {
                        callDirection = val;
                    } else if (mval.equals("CIC")) {
                        cic = val;
                    } else if (mval.equals("AUTH_CODE")) {
                        authCode = val;
                    } else if (mval.equals("CALL_TYPE")) {
                        callType = val;
                    } else if (mval.equals("STRUCTURE_CODE")) {
                        structureCode = val;
                    } else if (mval.equals("STRUCTURE_CODE_PREFIX")) {
                        structureCodePrefix = val;
                    } else if (mval.equals("TGN_360")) {
                        tgn360 = val;
                    } else if (mval.equals("TERM_NUMBER_101")) {
                        termNumber101 = val;
                    } else if (mval.equals("NUMBER_ID")) {
                        numberID = val;
                    } else if (mval.equals("MOD_NUMBER")) {
                        modNumber = val;
                    } else if (mval.equals("ACCOUNT_CODE")) {
                        accountCode = val;
                    } else if (mval.equals("TERM_NUMBER_LENGTH")) {
                        termNumberLength = val;
                    } else if (mval.equals("OVERFLOW_DIGITS")) {
                        overflowDigits = val;
                    } else if (mval.equals("ORIG_TERM_ID")) {
                        origTermID = val;
                    } else if (mval.equals("LRN_ORIG")) {
                        origLRN = val;
                    } else if (mval.equals("LRN_TERM")) {
                        termLRN = val;
                    } else if (mval.equals("POS_99")) {
                        pos99 = val;
                    } else if (mval.equals("OCN_OFFNET_ORIG")) {
                        ocnOffnetOrig = val;
                    } else if (mval.equals("OCN_OFFNET_TERM")) {
                        ocnOffnetTerm = val;
                    } else if (mval.equals("CALLING_PARTY_NUM")) {
                        callingPartyNum = val;
                    } 
                    // Hosted PBX -Dev starts 
                    
                    if(dataType.getDataTypeID()==16)
                    {                    
                    if (mval.equals("USER_NUMBER")) {
                    	userNumber = val;
                    } 
                    else if (mval.equals("GROUP_NUMBER")) {
                    	GroupNumber = val;
                    } 
                    
                    else if (mval.equals("RECD_CALLING_NUMBER")) {
                    	ReceivedCallinNumber = val;
                    } 
                    else if (mval.equals("CONFIG_CLID")) {
                    	ConfigurableCLID = val;
                    } 
                    else if (mval.equals("TERM_CAUSE")) {
                    	TerminationCause = val;
                    } 
                    else if (mval.equals("RELEASING_PARTY")) {
                    	ReleasingParty = val;
                    } 
                    else if (mval.equals("CALLING_PRES_IND")) {
                    	CallingPresentationIndicator = val;
                    } 
                    else if (mval.equals("CLID_PERMITTED")) {
                    	CLIDPermitted = val;
                    } 
                    else if (mval.equals("REL_CALL_ID_REASON")) {
                    	RelatedCallIDreason = val;
                    } 
                    else if (mval.equals("SIP_INVITE")) {
                    	SIPNVITE = val;
                    } 
                    else if (mval.equals("CODEC")) {
                    	Codec = val;
                    } 
                    else if (mval.equals("ACCESS_DEVICE_ADDRESS")) {
                    	AccessDeviceaddress = val;
                    } 
                    else if (mval.equals("ACCESS_CALL_ID")) {
                    	AccessCallID = val;
                    } 
                    else if (mval.equals("FIRST_REDIR_NUMBER")) {
                    	firstdirectedNumber = val;
                    } 
                    else if (mval.equals("REDIRECTION_REASON")) {
                    	RedirectionReason = val;
                    } 
                    else if (mval.equals("LAST_REDIR_NUMBER")) {
                    	LastRedirectedNumber = val;
                    } 
                    else if (mval.equals("REDIR_PRES_IND")) {
                    	redirectingpresentationndicator = val;
                    } 
                    else if (mval.equals("REDIRECTING_REASON")) {
                    	Redirectingreason = val;
                    } 
                    else if (mval.equals("TRUNK_GROUP_NAME")) {
                    	TrungGroupName = val;
                    } 
                    else if (mval.equals("TRUNK_GROUP_ACTION")) {
                    	TrunkGroupAction = val;
                    } 
                    else if (mval.equals("CALL_RELEASE")) {
                    	Callrelease = val;
                    } 
                    else if (mval.equals("SIP_ERROR_CODE")) {
                    	SIPErrorCode = val;
                    } 
                    else if (mval.equals("USER_GROUP_ID")) {
                    	UserGroupID = val;
                    } 
                    else if (mval.equals("CALL_CATEGORY")) {
                    	CallCategory = val;
                    } 
                    else if (mval.equals("NETWORK_CALL_TYPE")) {
                    	NetworkCallType = val;
                    } 
                    else if (mval.equals("TRANSLATED_NUMBER")) {
                    	TranslatedNumber = val;
                    } 
                    
                    else if (mval.equals("ROUTE")) {
                    	Route = val;
                    } 
                    }
                    // HPBX  Dev ends 
                    else if (mval.equals("TRUNK_GROUP")) {
                        if (tghit == 0) {
                            trunkGroup1 = val;
                        } else {
                            trunkGroup2 = val;
                        }
                        tghit++;
                    } else if (mval.equals("LRN_ROUTE")) {
                        if (lrnrghit == 0) {
                            lrnRoute1 = val;
                        } else {
                            lrnRoute2 = val;
                        }
                        lrnrghit++;

                    } else if (mval.equals("LRN")) {
                        if (lrnghit == 0) {
                            lrn1 = val;
                        } else {
                            lrn2 = val;
                        }
                        lrnghit++;
                    } else {

                    }
                    
                }
            }

            if (lrnRoute1 != null && lrnRoute1.equals("001c")) {
                origLRN = lrn1;
            }
            if (lrnRoute1 != null && lrnRoute1.equals("002c")) {
                termLRN = lrn1;
            }

            if (lrnRoute2 != null && lrnRoute2.equals("001c")) {
                origLRN = lrn2;
            }
            if (lrnRoute2 != null && lrnRoute2.equals("002c")) {
                termLRN = lrn2;
            }

            if (dataType.getDataTypeID() == 1) {
                if ("2,3,6,7".contains(structureCodePrefix)) {
                    accountCode = datarecord.substring(recordLength - 5, recordLength);
                }
                if (callType.equals("141c") && structureCode.equals("0360c") && (trunkGroup1==null||trunkGroup1.equals(""))) {
                    trunkGroup2 = tgn360;
//                System.out.println(callType + " - " + structureCode + " - " + structureCodePrefix + " - " + tgn360);
                }
                tgnInd1 = (trunkGroup1 != null ? trunkGroup1.substring(0, 1) : "");
                tgnInd2 = (trunkGroup2 != null ? trunkGroup2.substring(0, 1) : "");
                trunkGroup1 = (trunkGroup1 != null ? trunkGroup1 : "");
                trunkGroup2 = (trunkGroup2 != null ? trunkGroup2 : "");
/*
                if (!trunkGroup1.equals("")) {
                    outboundTGN = trunkGroup1;
                }
                if (!trunkGroup2.equals("")) {
                    inboundTGN = trunkGroup2;
                }
*/
                if (!trunkGroup1.equals("")) {
                        //Set first module in records TGN
                    if ("1,3,5,7,9".indexOf(tgnInd1) != -1) {
                        inboundTGN = trunkGroup1;
                    } else if ("2,4,6,8".indexOf(tgnInd1) != -1) {
                        outboundTGN = trunkGroup1;
                    } else if (!trunkGroup2.equals("")) {
                        outboundTGN = trunkGroup1;
                    } else if (",047c,119c,710c,714c,720c,".indexOf(callType) > -1&& trunkGroup2.equals("")) {
                        inboundTGN = trunkGroup1;
                    } else {
                        outboundTGN = trunkGroup1;
                    }
                }

                if (!trunkGroup2.equals("")) {
                    //Set second module (if any) in records TGN
                    if ("1,3,5,7,9".indexOf(tgnInd2) != -1) {
                        inboundTGN = trunkGroup2;
                    } else if ("2,4,6,8".indexOf(tgnInd2) != -1) {
                        outboundTGN = trunkGroup2;
                    } else {
                        inboundTGN = trunkGroup2;
//                    } else {
//                        outboundTGN = trunkGroup2;
                    }
                }

/*
                if (tgnInd1.equals("") || tgnInd1.equals("0") || tgnInd2.equals("") || tgnInd2.equals("0")) {
                    if (",047c,119c,263c,710c,714c,720c,".indexOf(callType) > -1 && trunkGroup2.equals("")) {
                        String tmpTGN = trunkGroup1;
                        trunkGroup1 = trunkGroup2;
                        trunkGroup2 = tmpTGN;
                    }

                    outboundTGN = trunkGroup1;
                    inboundTGN = trunkGroup2;
                } else {
                    if ("1,3,5,7,9".indexOf(tgnInd2) != -1) {
                        inboundTGN = trunkGroup2;
                    }
                    if ("2,4,6,8".indexOf(tgnInd2) != -1) {
                        outboundTGN = trunkGroup2;
                    }

                }
*/
                try {
                } catch (Exception error) {
                    overseasInd = "";
                }
                try {
                    origLRN = (origLRN != null ? origLRN.substring(1, 11) : "");
                    new Long(origLRN);
                } catch (Exception error) {
                    origLRN = "";
                }
                try {
                    termLRN = (termLRN != null ? termLRN.substring(1, 11) : "");
                    new Long(termLRN);
                } catch (Exception error) {
                    termLRN = "";
                }

                trunkGroupMem1 = (outboundTGN != null && outboundTGN.length() >= 9 ? outboundTGN.substring(5, 9) : "");
                trunkGroupMem2 = (inboundTGN != null && inboundTGN.length() >= 9 ? inboundTGN.substring(5, 9) : "");
                outboundTGN = (outboundTGN != null && outboundTGN.length() > 5 ? outboundTGN.substring(1, 5) : "");
                inboundTGN = (inboundTGN != null&&inboundTGN.length()>5 ? inboundTGN.substring(1, 5) : "");

            }

            if (dataType.getDataTypeID()==14 || dataType.getDataTypeID()==16) {
            	
            	try{
                if (callDirection!=null) {
                	
                	log.info("callDirection Value :::::"+callDirection);
                    if (callDirection.toLowerCase().equals("originating")) {
                        callDirection = "0";
                    } else {
                        callDirection = "1";
                    }
                }
                if (origNumber != null) {
                	
                	log.info("origNumber Value start :::::"+origNumber);
                    origNumber = origNumber.replaceAll("\\+1", "");
                    origNumber = origNumber.replaceAll("\\+", "");
                    origNumber = origNumber.replaceAll("\\*", "");
                    origNumber = origNumber.replaceAll("Unavailable", "");
                    origNumber = origNumber.replaceAll("smartvoice.telepacific.com", "");
                    if (origNumber.length()==11&&origNumber.startsWith("1")) {
                        origNumber = origNumber.substring(1, 11);
                    }
                    log.info("origNumber Value end :::::"+origNumber);
                }
                if (termNumber != null) {
                	log.info("termNumber Value start :::::"+termNumber);
                    termNumber = termNumber.replaceAll("\\+1", "");
                    termNumber = termNumber.replaceAll("\\+", "");
                    termNumber = termNumber.replaceAll("\\*", "");
                    termNumber = termNumber.replaceAll("Unavailable", "");
                    termNumber = termNumber.replaceAll("smartvoice.telepacific.com", "");
                    if (termNumber.length() == 11 && termNumber.startsWith("1")) {
                        termNumber = termNumber.substring(1, 11);
                    }
                    
                	log.info("termNumber Value end :::::"+termNumber);
                }
                if (dialedNumber != null) {
                	
                	log.info("dialedNumber Value start :::::"+dialedNumber);
                    dialedNumber = dialedNumber.replaceAll("\\+1", "");
                    dialedNumber = dialedNumber.replaceAll("\\+", "");
                    dialedNumber = dialedNumber.replaceAll("\\*", "");
                    dialedNumber = dialedNumber.replaceAll("Unavailable", "");
                    dialedNumber = dialedNumber.replaceAll("smartvoice.telepacific.com", "");
                    if (dialedNumber.length() == 11 && dialedNumber.startsWith("1")) {
                        dialedNumber = dialedNumber.substring(1, 11);
                    }
                    
                	log.info("dialedNumber Value end :::::"+dialedNumber);
                }

                if (cardatetime != null && cardatetime.length() > 0) {
                	log.info("car date time start: " + cardate + " - " + cartime + " - " + dataType.getHhStart() + " - " + getUsageDate(cardate, cartime));
                    cardate = cardatetime.substring(0, 8);
                    cartime = cardatetime.substring(8, cardatetime.length());
                	log.info("car date time end: " + cardate + " - " + cartime + " - " + dataType.getHhStart() + " - " + getUsageDate(cardate, cartime));
                }
                if (cdatetime != null && cdatetime.length() > 0) {
                	log.info("c date time start: " + cdate + " - " + ctime + " - " + dataType.getHhStart() + " - " + getUsageDate(cdate, ctime));
                    cdate = cdatetime.substring(0, 8);
                    ctime = cdatetime.substring(8, cdatetime.length());
                    log.info("c date time end: " + cdate + " - " + ctime + " - " + dataType.getHhStart() + " - " + getUsageDate(cdate, ctime));
                    
                } else {
                	log.info("c date time:"+cardate);
                    cdate = cardate;
                    ctime = cartime;
                    log.info("c date time:"+cartime);
                }
                if (reldatetime != null && reldatetime.length() > 0) {
                	log.info("reldatetime time start:"+reldatetime);
                    reldate = reldatetime.substring(0, 8);
                    reltime = reldatetime.substring(8, reldatetime.length());
                	log.info("reldatetime time end:"+reldatetime);
                }

            	} catch(Exception x)
            	{
            	   log.error("String Index exception "+x);
            	}
            }
            if (!origNumber.startsWith("019")) {
                origNumber = (origNPA != null ? origNPA : "") + (origNumber != null ? origNumber : "");
            } else {
                origNumber = (modNumber!=null?modNumber : origNumber);
            }
            termNumber = (termNPA != null ? termNPA : "") + (termNumber != null ? termNumber : "");

            overseasInd = (overseasInd != null ? overseasInd : "");
            //overseasInd = new Boolean(overseasInd).toString();
//                    System.out.println(overseasInd);

            if (numberID != null) {
//                System.out.println(numberID + " - " + modNumber + " - " + origNumber);
                if ((numberID.equals("1c") || numberID.equals("3c") || numberID.equals("6c") || numberID.equals("7c")) && (origNumber != null && origNumber.equals("000c0000000c"))) {
                    origNumber = modNumber.substring(modNumber.length()-15, modNumber.length()-1);
                    try {
                        origNumber = String.valueOf(Long.parseLong(origNumber));
                    } catch(Exception error) {

                    }
//                    System.out.println(origNumber + " - " + origNumber.length());
                    if (origNumber.substring(0,1).equals("1") && origNumber.length()==11) {
                        origNumber = origNumber.substring(1, origNumber.length());
                    }
                }
                if (numberID.equals("2c") && (termNumber != null && termNumber.equals("00000c0000000c"))) {
                    termNumber = modNumber.substring(modNumber.length() - 15, modNumber.length() - 1);
                    try {
                        termNumber = String.valueOf(Long.parseLong(termNumber));
                    } catch (Exception error) {
                    }
//                    System.out.println(origNumber + " - " + origNumber.length());
                    if (termNumber.substring(0, 1).equals("1") && termNumber.length() == 11) {
                        termNumber = termNumber.substring(1, termNumber.length());
                    }
                }
            }

            if (termNumber101 != null) {
                termNumber = termNumber101;
            }

            origNumber = origNumber.replaceAll("c", "");
            termNumber = termNumber.replaceAll("c", "");
            if (termNumber.length() > 1) {
                if (termNumber.substring(0, 2).equals("00") && overseasInd.equals("2c")) {
                    overseasInd = "0c";
                }
                if (termNumber.substring(0, 1).equals("01") && termNumber.length() == 11 && overseasInd.equals("2c")) {
                    overseasInd = "0c";
                }
            }
            if (termNumberLength!=null&&!termNumberLength.equals("10")) {
                termNumber = termNumber + "" + (overflowDigits!=null?overflowDigits:"");
            }
            //System.out.println("duration = '" + cduration + "'");
            if (origTermID != null && origTermID.equals("2")) {
                inboundTGN = trunkGroup1;
            }
            if (origTermID != null && origTermID.equals("1")) {
                outboundTGN = trunkGroup1;
            }
//            System.out.println(origTermID + " - " + trunkGroup1 + " - " + inboundTGN + " - " + outboundTGN);

            output.put("CALL_TYPE", (callType != null ? callType : ""));
            output.put("CALL_DIRECTION", (callDirection != null ? callDirection : ""));
            output.put("AUTH_CODE", (authCode != null ? authCode : ""));
            output.put("CALLING_PARTY_NUM", (callingPartyNum != null ? callingPartyNum : ""));
/*            if (demo_mode) {//////////////////////
                output.put("DIALED_NUMBER", (dialedNumber != null ? dialedNumber.substring(0, 3) + "555" + dialedNumber.substring(6, 10) : ""));
                output.put("CIC", (cic != null ? cic.length()==10?cic.substring(0,3) + "555" + cic.substring(6,10):cic : ""));
                output.put("TEL_NUMBER_ORIG", origNumber.replaceAll(" ", "").length() == 10 ? origNumber.replaceAll(" ", "").substring(0, 3) + "555" + origNumber.replaceAll(" ", "").substring(6, 10) : origNumber.replaceAll(" ", ""));
                output.put("TEL_NUMBER_TERM", termNumber.replaceAll(" ", "").length() == 10 ? termNumber.replaceAll(" ", "").substring(0, 3) + "555" + termNumber.replaceAll(" ", "").substring(6, 10) : termNumber.replaceAll(" ", ""));
            } else {
*/
                output.put("DIALED_NUMBER", (dialedNumber != null ? dialedNumber : ""));
                output.put("CIC", (cic != null ? cic : ""));
                output.put("TEL_NUMBER_ORIG", origNumber.replaceAll(" ", ""));
                output.put("TEL_NUMBER_TERM", termNumber.replaceAll(" ", ""));
//            }
                output.put("OVERSEAS_IND", (overseasInd != null ? overseasInd : ""));
                output.put("ACCOUNT_CODE", (accountCode != null ? accountCode : ""));

            if (pos99 != null) {
                output.put("POS_99", pos99.substring(18, 19));
            }
            if (ocnOffnetOrig != null) {
                output.put("OCN_OFFNET_ORIG", ocnOffnetOrig);
            }

            if (ocnOffnetTerm != null) {
                output.put("OCN_OFFNET_TERM", ocnOffnetTerm);
            }

            if (inboundTGN != null) {
                output.put("TG_NUMBER_INBOUND", (inboundTGN != null ? inboundTGN : ""));
            }
            if (outboundTGN != null) {
                output.put("TG_NUMBER_OUTBOUND", (outboundTGN != null ? outboundTGN : ""));
            }
            if (trunkGroupMem2 != null) {
                output.put("TG_MEM_NUM_INBOUND", (trunkGroupMem2 != null ? trunkGroupMem2 : ""));
            }
            if (trunkGroupMem1 != null) {
                output.put("TG_MEM_NUM_OUTBOUND", (trunkGroupMem1 != null ? trunkGroupMem1 : ""));
            }
            //System.out.println("TGM2: " + trunkGroupMem2 + " TGM1: " + trunkGroupMem1);

            if (origLRN!=null) {
                output.put("LRN_ORIG", (origLRN != null ? origLRN : ""));
            }
            if (termLRN!=null) {
                output.put("LRN_TERM", (termLRN != null ? termLRN : ""));
            }

            usageDate = getUsageDate(cdate, ctime);
            if(usageDate.getTime()<0 || usageDate == null){
            	usageDate = new Date();
            }
            
            output.put("DATE_TIME_BILLING", format.format(usageDate));
            if (cardate != null) {
                usageDate = getUsageDate(cardate, cartime);
                output.put("DATE_TIME_NETWORK", format.format(usageDate));
            } else {
                output.put("DATE_TIME_NETWORK", format.format(usageDate));
            }
            if (usageDate.getTime() > earliestRecordDate) {
                earliestRecordDate = usageDate.getTime();
            }

            
            if(dataType.getDataTypeID()==16)
            {
            	try {
            output.put("USER_NUMBER", (userNumber!=null ? userNumber:""));
            output.put("GROUP_NUMBER", (GroupNumber!=null ? GroupNumber:""));
            
            output.put("RECD_CALLING_NUMBER",(ReceivedCallinNumber!=null ? ReceivedCallinNumber:""));
            
            output.put("CONFIG_CLID", (ConfigurableCLID!=null ? ConfigurableCLID:""));
            
            output.put("TERM_CAUSE", (TerminationCause!=null ? TerminationCause:""));
            
            output.put("RELEASING_PARTY", (ReleasingParty!=null ? ReleasingParty:""));
            
            output.put("CALLING_PRES_IND", (CallingPresentationIndicator!=null ? CallingPresentationIndicator:""));
            
            output.put("CLID_PERMITTED", (CLIDPermitted!=null ? CLIDPermitted:""));
            
            output.put("REL_CALL_ID_REASON", (RelatedCallIDreason!=null ? RelatedCallIDreason:""));
            
            output.put("SIP_INVITE", (SIPNVITE!=null ? SIPNVITE:""));
            
            output.put("CODEC", (Codec!=null ? Codec:""));
            
            output.put("ACCESS_DEVICE_ADDRESS", (AccessDeviceaddress!=null ? AccessDeviceaddress:""));
            
            output.put("ACCESS_CALL_ID", (AccessCallID!=null ? AccessCallID:""));
            
            output.put("FIRST_REDIR_NUMBER", (firstdirectedNumber!=null ? firstdirectedNumber:""));
            output.put("REDIRECTION_REASON", (RedirectionReason!=null ? RedirectionReason:""));
            
            output.put("LAST_REDIR_NUMBER", (LastRedirectedNumber!=null ? LastRedirectedNumber:""));
            
            output.put("REDIR_PRES_IND", (redirectingpresentationndicator!=null ? redirectingpresentationndicator:""));
            
            output.put("REDIRECTING_REASON", (Redirectingreason!=null ? Redirectingreason:""));
            
            output.put("TRUNK_GROUP_NAME", (TrungGroupName!=null ? TrungGroupName:""));
            output.put("TRUNK_GROUP_ACTION", (TrunkGroupAction!=null ? TrunkGroupAction:""));
            
            output.put("CALL_RELEASE", (Callrelease!=null ? Callrelease:""));
            
            output.put("SIP_ERROR_CODE", (SIPErrorCode!=null ? SIPErrorCode:""));
            
            output.put("USER_GROUP_ID", (UserGroupID!=null ? UserGroupID:""));
            
            output.put("CALL_CATEGORY", (CallCategory!=null ? CallCategory:""));
            output.put("NETWORK_CALL_TYPE", (NetworkCallType!=null ? NetworkCallType:""));
            
            output.put("TRANSLATED_NUMBER", (TranslatedNumber!=null ? TranslatedNumber:""));
            
            output.put("ROUTE1", (Route!=null ? Route:""));
            	}
            	catch(Exception r)
            	
            	{
            		System.err.println("momentum Error "+r.getLocalizedMessage());
              log.error("momentum Error "+r.getLocalizedMessage());		
            
            }
            
            }
            
            
            
            
            
            
            
            
            if (cduration==null) {
                if (reldatetime!=null) {
                    output.put("DURATION_BILLING", Long.toString(getUsageDate(reldate, reltime).getTime() - getUsageDate(cdate, ctime).getTime()));
                    output.put("DURATION_NETWORK", Long.toString(getUsageDate(reldate, reltime).getTime() - getUsageDate(cardate, cartime).getTime()));
                }
            } else {
                output.put("DURATION_BILLING", Long.toString(getUsageDuration(cduration)));
                if (carduration != null) {
                    output.put("DURATION_NETWORK", Long.toString(getUsageDuration(carduration)));
                } else {
                    output.put("DURATION_NETWORK", Long.toString(getUsageDuration(cduration)));
                }
            }
            
            // HPBX 
            
           
            
            
            
            /**
             * take car date and build file
             */
            
            Record outputRecord=null;
            
            if(dataType.getDataTypeID()==16)
            {
             outputRecord = recordManager.getRecordByRecordName("Momentum");
            }
            else
            {
             outputRecord = recordManager.getRecordByRecordName("MAP_1");
            }
            
            
        //    Record outputRecord = recordManager.getRecordByRecordName("MAP_1");
            RecordField[] outputFields = recordFieldManager.getRecordFieldByRecordID(outputRecord.getRecordID());
            String val=null;
            Long valLong=null;
            StringBuffer outputRec = new StringBuffer();
            boolean validated = false;
            int icount = 0;
            int validCount = 0;
            for (RecordField rf : outputFields) {
                if (rf.getLength() > 0) {
                    icount++;
                    if(dataType.getDataTypeID()==16)
                    {
                    val = output.get(rf.getMapFieldName());
                    }
                    else
                    {
                    	 val = output.get(rf.getFieldName());
                    }
                   
                    if (val != null && !rf.getMapFieldName().equals("")) { 
                    	if (dataType.getDataTypeID()==1) {
                    		val = val.replaceAll("c", "");
                    	}

                    	if(val!=null && !val.equals("")){
                    		validated = true;
                    		validCount++;
                    		String pattern= "^[0-9]*$"; //////////This pattern matches only number,if number found then new Long else just append a value 
                    		if(!val.matches(pattern)){
                    			
                    			outputRec.append(val).append(",");
                    			val=null;
                    		}
                    		else if(val.matches(pattern))
                    		{
                    			valLong=new Long(val);
                    			
                    			outputRec.append(valLong).append(",");
                    			val=null;
                    		}
                    	}
                    	else if(val!=null && val.equals("")){
                    		
                    		outputRec.append(val).append(",");
                    		val=null;
                    	}

                    }
            			 
                    //System.out.println(icount + " - " + rf.getFieldName() + "  = " + val);
                }
            }

            //outputRec.append(datarecord);

            //try {Thread.sleep(3000);} catch(Exception error) {}
            
  
             if (validated==true && validCount>4) { //validCount is used here coz in broadsoft csv there are first 2 lines which has only 2 cloumns so just at safer side ignoring this two lines i used 4 count
                this.writeRecord(usageDate, outputRec);
                records++;
            } else {
                errorRecords++;
            }
        }
        // not invalid record ends here
    }

    private boolean writeRecord(Date usageDate, StringBuffer record) {

    	try{
	        if (record != null && record.length() > 0 && usageDate != null) {
	            BufferedWriter fileWriter = this.getWriter(usageDate, record);
	            try {
	                fileWriter.write(record.append("\r\n").toString());
	            } catch (Exception error) {
	               log.error(error.toString());
	            }
	        }
    	}catch(Exception e){
    		log.error("Error while writing the record "+e.toString());
    	}
    	
        return true;
    }

    private void closeWriters() {
        try {
            for (BufferedWriter fileWriter : fileWriters.values()) {
                fileWriter.flush();
                fileWriter.close();
            }
            if (errorLogWriter != null) {
                errorLogWriter.flush();
                errorLogWriter.close();
            }
        } catch (Exception error) {
        	log.error("Error while closing the writers "+error.toString());
        }
    }

  private Hashtable<String, Integer> record_count_by_date = new Hashtable<String, Integer>();
  //  private long records_per_file = 0;

    private BufferedWriter getWriter(Date usageDate, StringBuffer record) {
    	
    	BufferedWriter fileWriter = null;
    	
    	try{ 
	        SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd");
	        String dateKey = format.format(usageDate);
	      
	        File fileout;
	
	
	        if (fileWriters.containsKey(dateKey)) {
	            fileWriter = fileWriters.get(dateKey);
	        } else {
	            record_count_by_date.put(dateKey, 0);
	            fileout = new File(file.getAbsolutePath() + "." + dateKey + ".dbout");
	            log.error("DB out File Name"+fileout.getName()); 
	            try {
	                fileWriter = new BufferedWriter(new FileWriter(fileout, false));
	            } catch (Exception error) {
	            	
	            	log.error("Error in getWriter"+error.toString());
	            }
	            files.add(fileout.getAbsolutePath());
	            fileWriters.put(dateKey, fileWriter);
	        }
    	} catch(Exception e){
    	System.err.println(e.toString());
    	}
        return fileWriter;
    }

    private BufferedWriter getErrorWriter() {

        //BufferedWriter errorLogWriter = null;
    	
        if (errorLogWriter==null) {
            File fileout;
            File errdir = new File(file.getParentFile() + "\\err\\");
            errdir.mkdirs();
            fileout = new File(errdir.getAbsolutePath() + "\\" + file.getName() + ".err.log");
            try {
                errorLogWriter = new BufferedWriter(new FileWriter(fileout, false));
            } catch (Exception error) {
                log.error(error.toString());
            }
        }
        
        return errorLogWriter;
    }

    public String[] getFiles() {
    	
    	Comparator comparator = Collections.reverseOrder();
		Collections.sort(files,comparator);
		
        return files.toArray(new String[files.size()]);
    }

    public Date getUsageDate(String date, String time) {
        Date rtn = null;

        Calendar cal = Calendar.getInstance();
        try {
	        int yy = 0, mm = 0, dd = 0, hh = 0, ss = 0, mi = 0, ml = 0;
	        if (date != null) {
	//            for (String format : formats) {
	            if (time == null && formats[0].length() == date.length()) {
	                SimpleDateFormat dateformat = new SimpleDateFormat(formats[0]);
	                try {
	                    rtn = dateformat.parse(date);
	                    return rtn;
	                } catch (Exception error) {
	
	                }
	            }
	//            }
	            String syy = date.substring(dataType.getYyyyStart(), dataType.getYyyyStart() + dataType.getYyyyLength());
	            String smm = date.substring(dataType.getMmStart(), dataType.getMmStart() + dataType.getMmLength());
	            String sdd = date.substring(dataType.getDdStart(), dataType.getDdStart() + dataType.getDdLength());
	            cal.setTimeInMillis(new Date().getTime());
	            int yyNow = cal.get(Calendar.YEAR);
	            yy = Integer.parseInt(syy) + dataType.getYyyyIncrement();
	            if (yy>yyNow) {
	                yy = yy - 10;
	            }
	            mm = Integer.parseInt(smm) - 1;
	            dd = Integer.parseInt(sdd);
	        }
	
	        if (time != null) {
	            String shh = time.substring(dataType.getHhStart(), dataType.getHhStart() + dataType.getHhLength());
	            String smi = time.substring(dataType.getMiStart(), dataType.getMiStart() + dataType.getMiLength());
	            String sss = time.substring(dataType.getSsStart(), dataType.getSsStart() + dataType.getSsLength());
	            String sml = "";
	            if (dataType.getMlStart() != 0) {
	                sml = time.substring(dataType.getMlStart(), dataType.getMlStart() + dataType.getMlLength());
	            }
	            hh = Integer.parseInt(shh);
	            mi = Integer.parseInt(smi);
	            ss = Integer.parseInt(sss);
	            ml = 0;
	            if (dataType.getMlStart() != 0) {
	                ml = Integer.parseInt(sml);
	            }
	            if (dataType.getMlStart() != 0) {
	                cal.set(Calendar.MILLISECOND, ml * 100);
	            } else {
	                cal.set(Calendar.MILLISECOND, 0);
	            }
	        }
	        if (demo_mode) {
	            cal.setTimeInMillis(new Date().getTime());
	            yy = cal.get(Calendar.YEAR);
	            mm = cal.get(Calendar.MONTH);
	        }
	
	        cal.set(yy, mm, dd, hh, mi, ss);
        } catch (Exception ex) {
        	return new Date();
        }
//        System.out.println(yy + " - " + mm);
        return new Date(cal.getTimeInMillis());
    }

    private long getUsageDuration(String duration) {
        long l = 0;
        int mi;
        int ss;
        int ts;
  
        try
        {
        if (duration != null) {
            switch (dataType.getDurationTypeID()) {
                case DataType.DURATION_TYPE_MI_SS_ML:
                    String smi = duration.substring(dataType.getDurMiStart(), dataType.getDurMiStart() + dataType.getDurMiLength());
                    String sss = duration.substring(dataType.getDurSsStart(), dataType.getDurSsStart() + dataType.getDurSsLength());
                    String sts = duration.substring(dataType.getDurMlStart(), dataType.getDurMlStart() + dataType.getDurMlLength());

                    mi = Integer.parseInt(smi) * 60000;
                    ss = Integer.parseInt(sss) * 1000;
                    ts = Integer.parseInt(sts) * 100;
                    l = mi + ss + ts;
                    break;
                case DataType.DURATION_TYPE_SECONDS:
                    ss = Integer.parseInt(duration.replaceAll(" ", "")) * 1000;
                    l = ss;
                    break;
                case DataType.DURATION_TYPE_MILLISECONDS:
                    ss = Integer.parseInt(duration.replaceAll(" ", ""));
                    l = ss;
                    break;
                default:
                    ss = Integer.parseInt(duration.replaceAll(" ", ""));
                    l = ss;
                    break;
            }
        }
        }
        catch(Exception e)
        {
        	return  l;
        }
        return l;
    }


    public long getRecords() {
        return records;
    }

    public long getErrorRecords() {
        return errorRecords;
    }

    public Date getEarliestRecordDate() {
        return new Date(earliestRecordDate);
    }

    public static void main(String[] args) {


//        Calendar cal = Calendar.getInstance();
//        cal.setTimeInMillis(new Date().getTime());
//        System.out.println(new Integer(cal.get(Calendar.YEAR)).toString().substring(2,4));
        //System.out.println("001670197c".substring(5, 9));
/*        SimpleDateFormat format = new SimpleDateFormat("yyyy_mm_dd");
        try {
            System.out.println(format.parse("TBL_2008_11_05".replaceAll("TBL_", "")));
        } catch(Exception error) {
            error.printStackTrace();
        }
*/
        //System.out.println("abc123".endsWith("123"));
        //UncompressInputStream.ZUnZipFile(new File("F:\\udash\\rw090101.102c.Z"), true);
        /*

        DataType dataType = new DataType();
        dataType.setDataTypeID(1);
        dataType.setBcd(true);
        dataType.setKeyLength(4);
        dataType.setModKeyStart(0);
        dataType.setModKeyLength(3);
//        dataType.setFixedRecordLength(3);
//        dataType.setHeaderLength(1);
//        dataType.setTrailerLength(1);
//                File file = new File("e:\\eva\\test\\test.00.txt");
//        File file = new File("e:\\eva\\test\\010214.030215.04658.01.2");
        dataType = dataTypeManager.getDataType(1);
//        dataType.setHeaderLength(27);
//        dataType.setKeyStart(11);
        File file = new File("F:\\udash\\rw090101.102c");
//        File file = new File("e:\\eva\\010214.030215.04625.01.2_decoded");
//        File file = new File("e:\\eva\\test\\ry061214.107");

        DataFile dataFile = new DataFile(dataType, file);

        */

        //System.out.println("00123c5552222c".substring(0, 2));

    }
}
