/**
 * <p>Title: DataFileBCDWrite</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafile;

import java.io.*;

import org.apache.log4j.Logger;

public class DataFileBCDWrite {
    public DataFileBCDWrite(File in, File out) {
    	Logger log = Logger.getLogger(DataFileBCDWrite.class);
        try {
            FileOutputStream fos = new FileOutputStream(out);
            DataOutputStream dos = new DataOutputStream(fos);
            BufferedReader input = new BufferedReader(new FileReader(in));

            int iBuffer = 0;
            String record = null; //"00330000aa00500c001c121c0000000c121c0000000c80318c0c000c949c2964400c0c00626c9279578c1443491c000000299c";

            while ((record = input.readLine()) != null) {
                iBuffer++;
                DataFileBCDWrite.writeAsciiRecordToBCD(record, dos);

            }
            fos.close();
            dos.close();
            input.close();
            log.info("BCD Convert Complete - Records: " + iBuffer + " - " + out.getName());
        } catch (Exception e) {
            log.error("Exception: " + e);
        }
    }

    public static void writeAsciiRecordToBCD(String record, DataOutputStream dos) {
        String v;

        String rec = "";
        String two = "";
        rec = "";
        v = "";
        two = "";
        for (int i = 0; i < record.length(); i++) {
            v = record.substring(i, i + 1);
            two += v;
            if (two.length() == 2) {
                rec += two;
                try {
                    dos.write(Integer.parseInt(two, 16));
                } catch(Exception error) {
                    error.printStackTrace();
                }
                two = "";
            }
        }

    }

    public static void main(String[] args) {
        File out = new File("D:\\Java\\projects\\UsageWorks\\files\\bcd\\out.bcd");
        File in = new File("D:\\Java\\projects\\UsageWorks\\files\\bcd\\in.txt");
        new DataFileBCDWrite(in, out);
    }
}
