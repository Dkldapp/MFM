/**
 * <p>Title: DataFileCollect</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafile;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;

import org.apache.log4j.Logger;

import com.telepacific.fileutils.FileHelper;
import com.telepacific.merrt.feedmanager.datafeed.DataFeed;
import com.telepacific.merrt.feedmanager.utils.GeneralFileFilter;
import com.telepacific.merrt.feedmanager.utils.UsageFileTool;
import com.telepacific.merrt.validators.FeedHandlerUtils;
 
public class DataFileCollect {
    private DataFeed dataFeed;
    public DataFileCollect() {
    }

    Logger log = Logger.getLogger(DataFileCollect.class);
    public void run() {
        File inpath;
        FilenameFilter filter;
        String path = FeedHandlerUtils.getMFMPath(dataFeed.getPath());
        
        File droppath = new File(path);
        File logFile = new File(droppath.getAbsolutePath() + "\\collect.log");
        inpath = new File(dataFeed.getInputJDBC());
        filter = new GeneralFileFilter(dataFeed.getInputDbDriver());

        BufferedWriter errorLogWriter = null;

        try {
            droppath.mkdirs();
            errorLogWriter = new BufferedWriter(new FileWriter(logFile, true));
        } catch (Exception error) {
            error.printStackTrace();
        }

        if (inpath.isDirectory()) {
            for (File file : inpath.listFiles(filter)) {
                if (file.isFile()&&!FileHelper.isFileOpen(file) && file.exists()&&!UsageFileTool.isDuplicateFileInLog(file, logFile)) {
                    try {
                        UsageFileTool.copyFile(file, new File(UsageFileTool.getRollFileName(droppath.getAbsolutePath() + "\\" + file.getName())));
                        errorLogWriter.write(file.getName() + "\r\n");
                        log.info(file.getName() + " - Copied");
                    } catch (Exception error) {
                        log.info(error.toString());
                    }
                }
            }
        }

        try {
            errorLogWriter.close();
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public DataFeed getDataFeede() {
        return dataFeed;
    }

    public void setDataFeed(DataFeed dataFeed) {
        this.dataFeed = dataFeed;
    }

    public static void main(String[] args) {
        DataFeed dataFeed = new DataFeed();
        dataFeed.setInputJDBC("\\\\notebook-pro\\share\\");
        dataFeed.setPath("C:\\usageworks\\test");
        dataFeed.setFileMask("*");
        DataFileCollect collect = new DataFileCollect();
        collect.setDataFeed(dataFeed);
        collect.run();
        try {
            Thread.sleep(3000);
        } catch(Exception error){
            error.printStackTrace();
        }
        collect.run();
    }
}
