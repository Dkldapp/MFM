package com.telepacific.merrt.feedmanager.datafile;

public class DataFilesStatus {
	private int filesReceviedID;
	private int feedID;
	private String feedFileName;
	private String status;
	private int recordCount;
	private String errorRecordId;

	public int getFilesReceviedID() {
		return filesReceviedID;
	}
	public void setFilesReceviedID(int filesReceviedID) {
		this.filesReceviedID = filesReceviedID;
	}
	public int getFeedID() {
		return feedID;
	}
	public void setFeedID(int feedID) {
		this.feedID = feedID;
	}
	public String getFeedFileName() {
		return feedFileName;
	}
	public void setFeedFileName(String feedFileName) {
		this.feedFileName = feedFileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public String getErrorRecordId() {
		return errorRecordId;
	}
	public void setErrorRecordId(String errorRecordId) {
		this.errorRecordId = errorRecordId;
	}
	

}
