/**
 * <p>Title: DataRecord</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datafile;

public class DataRecord {
    public DataRecord() {

    }
}
