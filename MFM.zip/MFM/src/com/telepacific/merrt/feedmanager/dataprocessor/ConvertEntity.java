/**
 * <p>Title: ConvertEntity</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.dataprocessor;

public class ConvertEntity {
    public static final int PROCESS_TYPE_ARCHIVE_ONLY = 0;
    public static final int PROCESS_TYPE_DATABASE_ONLY = 1;
    public static final int PROCESS_TYPE_ARCHIVE_AND_DATABASE = 2;

    private String name;
    private int id;
    private String path;
    private String filePattern = "*";
    private int dataTypeID;
    private String database;
    private String table;
    private int processType = PROCESS_TYPE_ARCHIVE_AND_DATABASE;

    private boolean continuous = false;

    public ConvertEntity() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    public String getFilePattern() {
        return filePattern;
    }

    public void setFilePattern(String filePattern) {
        this.filePattern = filePattern;
    }

    public int getDataTypeID() {
        return dataTypeID;
    }

    public void setDataTypeID(int dataTypeID) {
        this.dataTypeID = dataTypeID;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getProcessType() {
        return processType;
    }

    public void setProcessType(int processType) {
        this.processType = processType;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public boolean isContinuous() {
        return continuous;
    }

    public void setContinuous(boolean continuous) {
        this.continuous = continuous;
    }
}
