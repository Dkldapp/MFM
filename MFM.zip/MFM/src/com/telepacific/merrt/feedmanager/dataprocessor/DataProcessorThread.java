package com.telepacific.merrt.feedmanager.dataprocessor;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.telepacific.fileutils.FileCompressor;
import com.telepacific.fileutils.FileHelper;
import com.telepacific.merrt.JMX.FeedProcessJMXMBean;
import com.telepacific.merrt.config.MERRTFeedManagerDAO;
import com.telepacific.merrt.config.SystemManager;
import com.telepacific.merrt.config.UDashProps;
import com.telepacific.merrt.config.UncompressInputStream;
import com.telepacific.merrt.feedmanager.datafeed.DataFeed;
import com.telepacific.merrt.feedmanager.datafeed.DataFeedManager;
import com.telepacific.merrt.feedmanager.datafile.DataFile;
import com.telepacific.merrt.feedmanager.datafile.DataFilesStatus;
import com.telepacific.merrt.feedmanager.datatype.DataType;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManager;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.record.Record;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManager;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordField;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManager;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManagerBusiness;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotification;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationBusiness;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationManager;
import com.telepacific.merrt.feedmanager.utils.GeneralFileFilter;
import com.telepacific.merrt.feedmanager.utils.UsageFileTool;
import com.telepacific.merrt.validators.FeedHandlerUtils;

public class DataProcessorThread extends Thread {
	
	public static final int STATUS_STOPPED = 0;
	public static final int STATUS_IDLE = 1;
	public static final int STATUS_PROCESSING = 2;
	public static final int STATUS_STOPPING = 3;
	public static final int STATUS_DATABASE_QUERY = 4;
	public static final int STATUS_DATABASE_COUNT = 5;
	public static final int STATUS_DATABASE_EXPORT = 6;

	private DataFeed dataFeed;
	private static  boolean doRun = false;
	private int status = STATUS_STOPPED;
	private static DataTypeManager dataTypeManager = DataTypeManagerBusiness
			.getInstance();
	private boolean isSS7ThreadCreated=false;
	private boolean running = false;
	private File file = null;
	private Date lastStatusDate = new Date();
	private int filesInQueue = 0;
	static URL root;
	
	public static String merrt_UNC_path = null;
	public static boolean ss7TestFlag = false;

	public static boolean filesListLoadFlag = true;
	// public static DataFilesStatus dataFilesStatus;
	static MERRTFeedManagerDAO initFeedManager = new MERRTFeedManagerDAO();
	// public static FeedHandlerUtils feedHandlerUtils;
	private String tbl;
    private String database;

	private long records = 0;
	private long errorRecords = 0;

	private long startTime = 0;
	private long endTime = 0;

	private long pollStartTime = 0;
	private long pollEndTime = 0;
	
	private long kepupdateStartTime = 0;
	private long keepupdateEndTime = 0;
	
	private long ss7FileCreateStartTime = 0;
	private long ss7FileCreateEndTime = 0;
	
	private long databaseRecordAt = 0;
	private long databaseRecordWrite = 0;

	private DataFeedNotificationManager dataFeedNotificationManager;
	private DataFeedNotification dataFeedNotification;
	public static FeedProcessJMXMBean feedProcessJMXBean;
	
	private static final Object lock = new Object();

	static HashMap<String, String> processedFileList = new HashMap<String, String>();

	Logger log = Logger.getLogger(DataProcessorThread.class);
	public List<String> feedfilelist =null;

	public DataProcessorThread(DataFeed dataFeed) {
		
		root = getClass().getProtectionDomain().getCodeSource().getLocation();
		this.dataFeed = dataFeed;
		dataType = dataTypeManager.getDataType(dataFeed.getDataTypeID());
		dataFeedNotificationManager = DataFeedNotificationBusiness.getInstance();
		dataFeedNotificationManager.reload();
		dataFeedNotification = dataFeedNotificationManager
				.getDataFeedNotificationByDataFeedID(dataFeed.getDataFeedID());
		if (dataFeedNotification == null) {
			dataFeedNotification = new DataFeedNotification();
			dataFeedNotification.setDataFeedID(dataFeed.getDataFeedID());
			dataFeedNotification.setStatus(0);
			dataFeedNotification.setQueued(new Long(0));
			dataFeedNotification.setThresholdMinutes(0);
			dataFeedNotification.setDataFeedNotificationID(-1);
			dataFeedNotification.setDateLastFileCompleted(new Date());
			dataFeedNotification.setDateLastFileReceived(new Date());
			dataFeedNotification.setDateLatestUsage(new Date(0));
			dataFeedNotification.setLastFileName("na");

			dataFeedNotification = dataFeedNotificationManager
					.setDataFeedNotification(dataFeedNotification);

		}

	}

	private boolean buildingDBFile = false;

	// SS7 feed accessing data dircetly from database and build the file. The
	// method used for getting data from database

	private boolean buildFileFromDatabase(final DataFeed dataFeed) {
		
	//System.out.println("Connected to  SS7 Database at NETDW Server to Build files  for Feed   :: "+dataFeed.getDataFeedName());
	//	log.info("Connected to  SS7 Database at NETDW Server to Build files  for Feed   :: "+dataFeed.getDataFeedName());
		
		String path = FeedHandlerUtils.getMFMPath(dataFeed.getPath());
		String FILE_NAME = "";
		Date FILE_DATE ;
		String PROCESS_DATE_START = "";
		
		String PROCESS_DATE_COMPLETE = "";
		String PROCESS_MILLISECONDS = "";

		String KEEP_PROCESS_DATE_COMPLETE = "";
		String KEEP_PROCESS_MILLISECONDS ="";
		
		//log.info(" SS7 path "+path);

		if (buildingDBFile) {
			return true;
		}

		buildingDBFile = true;
		ArrayList<File> files = new ArrayList<File>();
		try {

		
			 URL propertiesFile = new URL(root, "mfmproperties.properties"); 
			 Properties mfmProperties = new Properties();
			 //FileInputStream in = new FileInputStream(".\\mfmproperties.properties");     
			 mfmProperties.load(propertiesFile.openStream()); 
			
			 ss7TestFlag = (mfmProperties.getProperty("isSS7FeedTesting").contains("y"))? true : false;
			 
			 log.info(" SS7 Test Flag "+ss7TestFlag);
			// System.out.println(" SS7 Test Flag "+ss7TestFlag);
			 SimpleDateFormat formatTime = new SimpleDateFormat(
				"MM/dd/yyyy hh:mm:ss aaa");
		     SimpleDateFormat archive_date_dir = new SimpleDateFormat(
				"yyyy\\MM\\dd");
		     pollStartTime = new Date().getTime();
	     	 PROCESS_DATE_START = formatTime.format(new Date(new Date().getTime()));
	    	 StringBuffer SS7DataPoll_log = new StringBuffer();
	    	 
	  		if (dataFeed.getInputTable() != null) {
				databaseRecordAt = 0;
				this.status = STATUS_DATABASE_COUNT;
				if (dataFeedNotification != null) {
					dataFeedNotification.setStatus(new Integer(
							STATUS_DATABASE_COUNT));
					dataFeedNotificationManager
							.setDataFeedNotification(dataFeedNotification);
				}

				String where = (dataFeed.getInputTableWhere() != null ? dataFeed
						.getInputTableWhere() : "");
				Connection conn = DriverManager.getConnection(dataFeed
						.getInputJDBC());
				StringBuffer select = new StringBuffer();
				RecordManager recordManager = RecordManagerBusiness
						.getInstance();
				RecordFieldManager recordFieldManager = RecordFieldManagerBusiness
						.getInstance();
				Record record = recordManager.getRecordByDataTypeID(dataFeed
						.getDataTypeID())[0];
				String databaseTable = null;

				RecordField[] recordFields = recordFieldManager
						.getRecordFieldByRecordID(record.getRecordID());
				int lfld = 0;
				for (RecordField recordField : recordFields) {
					select.append(lfld != 0 ? ", " : "").append(
							recordField.getSelectFieldName());
					lfld++;
					
				}
				String inputTable = dataFeed.getInputTable();
				Calendar cal = Calendar.getInstance();
				cal.setTimeInMillis(new Date().getTime());

				Statement stmt = conn.createStatement();
				ResultSet rs;
				ResultSet rsQueue;

				this.status = STATUS_DATABASE_QUERY;
				if (dataFeedNotification != null) {
					dataFeedNotification.setStatus(new Integer(
							STATUS_DATABASE_QUERY));

					dataFeedNotificationManager
							.setDataFeedNotification(dataFeedNotification);
				}

				try {

					stmt = conn.createStatement();
					rsQueue = stmt.executeQuery(" SELECT * FROM " + inputTable
							+ " " +where);
					long iIndex = 0;
					String fieldValue;

					PrintWriter fileWriter = null;
					long recordsWritten = 0;
					long recordIndex = 0;
					long recordsPerFile = 1000;
					StringBuffer outrecord = new StringBuffer();
					Hashtable<Long, String> fields = new Hashtable<Long, String>();
					File tblFile = null;
					File fileFinished = null;

					while (rsQueue.next()) {
						if (!doRun) {
							break;
						}
						databaseTable = rsQueue.getString("TABLE_NAME");

						// log.info("DB TRANS: " + databaseTable);

						this.status = STATUS_DATABASE_EXPORT;
						if (dataFeedNotification != null) {
							dataFeedNotification.setStatus(new Integer(
									STATUS_DATABASE_EXPORT));
							dataFeedNotificationManager
									.setDataFeedNotification(dataFeedNotification);
						}
						try {
							stmt = conn.createStatement();
							
					//		log.info(" select condition"+select.toString());
							
							rs = stmt.executeQuery(" SELECT " + select
									+ " FROM " + databaseTable + " ");

							while (rs.next()) {
								if (!doRun) {
									break;
								}
								if (recordsWritten == 0) {
									for (int i = 0; i < rs.getMetaData()
											.getColumnCount(); i++) {
										fields.put(
												new Long(i + 1),
												rs.getMetaData().getColumnName(
														i + 1));
									}
								}
								if (recordIndex == 0) {

									if (fileWriter != null) {
										fileWriter.flush();
										fileWriter.close();
									}
									if (tblFile != null && tblFile.length() > 0) {
										fileFinished = new File(
												UsageFileTool
														.getRollFileName(path
																+ "\\"
																+ inputTable
																+ "_"
																+ dataFeed
																		.getDataFeedName()
																		.replaceAll(
																				" ",
																				"_")
																+ "_"
																+ (new Date()
																		.getTime())
																+ ".00"));
										tblFile.renameTo(fileFinished);
									} else if (tblFile != null
											&& tblFile.length() == 0) {
										tblFile.delete();
									}

									// log.info("Database Poll, New File: " +
									// dataFeed.getDataFeedName() + ", " +
									// tblFile.getName());

									tblFile = new File(path
											+ "\\"
											+ inputTable
											+ "_"
											+ dataFeed.getDataFeedName()
													.replaceAll(" ", "_") + "_"
											+ (new Date().getTime()) + ".tmp");
									fileWriter = new PrintWriter(
											new FileWriter(tblFile, false));
									files.add(new File(tblFile
											.getAbsolutePath()));
								}
								recordIndex++;
								if (recordIndex >= recordsPerFile) {
									recordIndex = 0;
								}

								outrecord = new StringBuffer();
								for (int i = 0; i < fields.size(); i++) {
									fieldValue = rs.getString(fields
											.get(new Long(i + 1)));
									outrecord.append((i != 0 ? "," : "")
											+ fieldValue);
								}

								outrecord.append("\r\n");
								fileWriter.write(outrecord.toString());
								recordsWritten++;
								databaseRecordWrite++;
							}
							
							ss7FileCreateEndTime = new Date().getTime();
							PROCESS_DATE_COMPLETE = formatTime.format(new Date(new Date().getTime()));
							long SS7FileCreateTime = ss7FileCreateEndTime - ss7FileCreateStartTime;
							FILE_NAME=tblFile.getName();
							FILE_DATE=new Date();
						//	log.info("Created File Name" +FILE_NAME);
							
							SS7DataPoll_log.append(FILE_NAME).append(",");
							SS7DataPoll_log.append(FILE_DATE).append(",");
							SS7DataPoll_log.append(PROCESS_DATE_START).append(",");
							SS7DataPoll_log.append(PROCESS_DATE_COMPLETE).append(",");
							SS7DataPoll_log.append(SS7FileCreateTime).append("\r\n");						
							this.writeSS7Log(SS7DataPoll_log.toString());

							databaseRecordAt++;
							iIndex++;
							rs.close();
							// return true;
						} catch (Exception error) {

							log.error("An Error: " + error.toString());
						}
						try {

							kepupdateStartTime = 0;
							keepupdateEndTime = 0;
							
							
							if (!ss7TestFlag){ // it is used for testing. It will connect live server for getting data, it will not update flag status to further action
								
								kepupdateStartTime = new Date().getTime();
								
								this.keepUpdating(conn, inputTable, databaseTable,0);
								log.info(" keepupdateStartTime "+kepupdateStartTime);
								
								keepupdateEndTime = new Date().getTime();
								log.info(" keepupdateEndTime "+keepupdateEndTime);
								log.info("Database Poll ending, File created: " + dataFeed.getDataFeedName() + ", " + tblFile.getName());
							} 
								
							long keepupdateProcessTime = keepupdateEndTime - kepupdateStartTime;

								KEEP_PROCESS_DATE_COMPLETE = formatTime.format(new Date(keepupdateEndTime));
								KEEP_PROCESS_MILLISECONDS = Long.toString(keepupdateProcessTime);
						//	log.info(" Keep updating Method Called ");
						} 
						catch (Exception e2) {
							log.error("Error while calling keep Updating method "+e2.getMessage());
							//e2.printStackTrace();
						}
						dataFeed.setLastPollIndex(recordsWritten);
						dataFeed.setLastPollObj(databaseTable);
						DataFeedManager dataFeedManager = DataFeedManager
								.getInstance();
						dataFeedManager.setDataFeed(dataFeed);
					}
					rsQueue.close();
					try {
						if (fileWriter != null) {
							fileWriter.flush();
							fileWriter.close();
						}
						if (tblFile != null && tblFile.length() > 0) {
							fileFinished = new File(
									UsageFileTool
									.getRollFileName(path
											+ "\\"
											+ inputTable
											+ "_"
											+ dataFeed
													.getDataFeedName()
													.replaceAll(
															" ",
															"_")+ "_"
											+ (new Date().getTime()) + ".00"));
							tblFile.renameTo(fileFinished);
						//	log.info("File build completed ::: "+fileFinished.getName());
						} else if (tblFile != null && tblFile.length() == 0) {
							tblFile.delete();
						}

						// file.renameTo(new File(path + filename));
					} catch (Exception ignore) {
						// ignore.printStackTrace();
						log.error(ignore.toString());
					}

				} catch (Exception error) {

					log.error(" An Error in buildFileFromDatabase "
							+ error.toString());
				}
				conn.close();
			}

		} catch (Exception error) {
			log.error(" Error in buildFileFromDatabase " + error.toString());
		}
		buildingDBFile = false;
		
		return true;
	}

	private boolean keepUpdating(Connection conn,String inputTable,String databaseTable, long attempt) {
		try {
		log.info("Keep Updating  table "+inputTable+"  for database table  "+databaseTable+" started ");
		
			Statement stmt = conn.createStatement();
			stmt.executeUpdate("UPDATE " + inputTable
					+ " SET DATE_TRANSFERED = getDate() WHERE TABLE_NAME = '"
					+ databaseTable + "'");
			
			log.info("  Updating   "+inputTable+ " for database table "+databaseTable+"is completed ");
		Thread.sleep(100);
		}
		catch (Exception e)
		{
			log.error(" Problem in updating "+inputTable+ " for database table "+databaseTable+"  Error Message is ::: "+e.toString());	
			
			if (attempt > 3) {
				SystemManager.getInstance().println(
						"Failed dropping table (" + attempt + "): "
								+ inputTable + " - " + databaseTable);
				 log.info(" Failed dropping table (" + attempt + "): " +
				 inputTable + " - " + databaseTable);
				try {
					Thread.sleep(100);
				} catch (Exception error2) {
					log.error(" keep Updating " + error2.toString());
				}
			}
 else 
			{
				keepUpdating(conn, inputTable, databaseTable, attempt++);
				
			}
			
		}
		
		try
		{
			log.info("Deleting database table" +databaseTable);
			Statement  stmt = conn.createStatement();
			stmt.executeUpdate("DROP TABLE " + databaseTable);
			
			log.info("The database  table "+databaseTable+" is  Deleted");
			Thread.sleep(100);

		} 
		
		catch (Exception ex)
		{
			log.error(" Problem in  Deleting  table  "+databaseTable+"  Error Message is ::: "+ex.toString());	
		}
		
//		catch (Exception error) {
//			// error.printStackTrace();
//			log.error(" Problem in  keepupdating "+inputTable+ "for database table "+databaseTable+"  Error Message is ::: "+error.toString());
//			if (attempt > 3) {
//				SystemManager.getInstance().println(
//						"Failed dropping table (" + attempt + "): "
//								+ inputTable + " - " + databaseTable);
//				 log.info(" Failed dropping table (" + attempt + "): " +
//				 inputTable + " - " + databaseTable);
//				try {
//					Thread.sleep(100);
//				} catch (Exception error2) {
//					log.error(" keep Updating " + error2.toString());
//				}
//			}
////			} else 
////			{
////				keepUpdating(conn, inputTable, databaseTable, attempt++);
////			}
//			
//		}
		
	
		return true;
	}

	
	/*
	 * writeSS7Log() method is used to write pooling SS7 file status into log file.
	 */
	private boolean writeSS7Log(String message) {

        log.info("Writing SS7 Log");
		SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
		String path = dataFeed.getPath()+"\\ss7log\\";
		File logDirs = new File(path);
		logDirs.mkdirs();
		File historyFile = new File(path + "\\" + "ss7_data_poll_log.log");
		if (historyFile.exists())
		{
			long bytes = historyFile.length() / 1024;
			long mb = bytes / 1024;

			if (mb > 1) {
				File logDir = new File(path + "\\logs");
				logDir.mkdirs();
				File hrn = new File(path + "\\logs\\" + "ss7_data_poll_log_"
						+ format.format(new Date()) + ".log");
				historyFile.renameTo(hrn);
				historyFile = new File(path + "\\" + "ss7_data_poll_log.log");
			}
		}
		PrintWriter fileWriter = null;
		try {
			boolean exists = historyFile.exists();

			fileWriter = new PrintWriter(new FileWriter(historyFile, true));
			if (!exists) {
				// historyFile.createNewFile();
				fileWriter
						.write("FILE_NAME,FILE_DATE,POLL_DATE_START,POLL_DATE_COMPLETE,POLL_PROCESS_MILLISECONDS\r\n");
			}
		//	log.info("ss7 log created...");
			fileWriter.write(message + "\r\n");

		} catch (Exception error) {

			log.error(" writeSS7Log-1 Error: " + error.toString());

		} finally {
			try {
				fileWriter.flush();
				fileWriter.close();
				// file.renameTo(new File(path + filename));
			} catch (Exception ignore) {
				log.error(" writeSS7Log-2 Error: " + ignore.toString());
			}
		}
		return true;
	}
	
	// This Method wil  Check for Old .dbout files in feed path and delete them if older than two days..
	private void deleteOldDBoutfiles(String oriPath) {
		
		log.info(" Deleting Older dbout Files in path  :: "+oriPath);
		
		File[] allfiles = null;
		long purgeTime=0;
		int daysback=2;
		
		try{
		
		File dir=new File(oriPath);
		allfiles=dir.listFiles();
		purgeTime= System.currentTimeMillis() - (daysback * 24 * 60 * 60 * 1000); 
		
		for(File dboutfile: allfiles)
		{
			if (dboutfile.isDirectory())
				continue;
			if( dboutfile.exists()&& dboutfile.getName().endsWith(".dbout")&& dboutfile.lastModified()<purgeTime)
			{
			
				log.info("The file "+dboutfile.getName()+ "is Older than Two days.. Hence, deleting");
			    if(dboutfile.delete())
			    {
				log.info("The file "+dboutfile.getName()+ " has been deleted Successfully ...");
			    }
			    else
			    {
			    	log.info("The file "+dboutfile.getName()+ " Will not be  deleted ");
			    }
			  
			}
		}
		}
		
		
		
		catch(Exception e)
		{
			log.error("Error in deletting Old DBout files "+e.getMessage() );
		}
		
	}
	
	
	// This Method wil  Check for Old processed files in feed path and delete them if older than n days..
	private void deleteOldProcessedfiles(String oriPath) throws IOException {
		
		 oriPath=oriPath+"\\processed";
		 log.info(" Deleting Older Processed Files in path  :: "+oriPath);
		
		 String daysback="";
		 int days=0;
		
		 URL propertiesFile = new URL(root, "mfmproperties.properties"); 
		 Properties mfmProperties = new Properties();
		 //FileInputStream in = new FileInputStream(".\\mfmproperties.properties");     
		 mfmProperties.load(propertiesFile.openStream()); 
		 daysback=mfmProperties.getProperty("daysToKeepProcessedfiles");
		 days=Integer.parseInt(daysback);
		// System.out.println(" No Of Days to Keep Processed Files   :: "+days);
		 log.info(" No Of Days to Keep Processed Files   :: "+days);
		 
		
		File[] allfiles = null;
		long purgeTime=0;
	
		
		try{
	
		File dir=new File(oriPath);
		allfiles=dir.listFiles();
		purgeTime= System.currentTimeMillis() - (days * 24 * 60 * 60 * 1000); 
		
		for(File processedfile: allfiles)
		{
			if (processedfile.isDirectory())
				continue;
			if( processedfile.exists()&& processedfile.lastModified()<purgeTime)
			{
			
				log.info("The file "+processedfile.getName()+ "is Older than "+days+" days.. Hence, deleting");
			    if(processedfile.delete())
			    {
				log.info("The file "+processedfile.getName()+ " has been deleted Successfully ...");
			    }
			    else
			    {
			    	log.info("The file "+processedfile.getName()+ " Will not be  deleted ");
			    }
			  
			}
		}
		}
		
		
		
		catch(Exception e)
		{
			log.error("Error in deleing Old processed files "+e.getMessage() );
		}
		
	}
	
	
	// The method process the received file content, counts record count and
	// load data into warehouse table.
	// if file have invalid records then the file will be moved to error
	// directory.

	private boolean processFile(File file, String oriPath) {
		DataFilesStatus dataFilesStatus = null;
		try {
         log.info("Processing file started for file :: "+file.getName());
         
         URL propertiesFile = new URL(root, "mfmproperties.properties"); 
		 Properties mfmProperties = new Properties();
		 //FileInputStream in = new FileInputStream(".\\mfmproperties.properties");     
		 mfmProperties.load(propertiesFile.openStream()); 
		
		//  String waitTime = mfmProperties.getProperty("threadSleepTime");
		  long time= 1000;
		
		   log.info("File Inteval  wait time is "+time);
         
			file = new File(file.getAbsolutePath());
			SimpleDateFormat formatTime = new SimpleDateFormat(
					"MM/dd/yyyy hh:mm:ss aaa");
			SimpleDateFormat archive_date_dir = new SimpleDateFormat(
					"yyyy\\MM\\dd");
			startTime = new Date().getTime();

			String FILE_NAME = file.getName();
			String FILE_DATE = formatTime.format(new Date(file.lastModified()));
			String PROCESS_DATE_START = formatTime.format(startTime);
			String FILE_USAGE_DATE = null;
			String FILE_DATABASE = null;
			String FILE_ARCHIVED = null;
			String FILE_RECORDS = null;
			String FILE_RECORDS_ERROR = null;

			if (!file.exists() || file.getName().contains("dbout") || file.getName().endsWith("log") || file.getName().endsWith("tmp")) {
				return false;
			}
			if (file.isDirectory()) {
				return false;
			}
			this.status = STATUS_PROCESSING;
			if (dataFeedNotification != null) {

				// log.info(" dataFeedNotification from data processor thread ");

				dataFeedNotification.setDateLastFileReceived(new Date());
				dataFeedNotification.setStatus(new Integer(STATUS_PROCESSING));
				dataFeedNotification.setLastFileName(file.getName());

				// log.info(" Adding file to Notification Manager "+file.getName());

				dataFeedNotificationManager.setDataFeedNotification(dataFeedNotification);
			}
			lastStatusDate = new Date();

			records = 0;
			errorRecords = 0;

			this.file = file;
			endTime = 0;

			final Calendar cal = Calendar.getInstance();
			boolean archive = false;
			boolean database = false;
			DataFile dataFile = null;
			boolean failed = false;

			cal.setTimeInMillis(file.lastModified());
			if (file.getName().toLowerCase().indexOf(".gz") != -1
					&& file.length() > 0) {
				file = FileCompressor.GUnZipFile(file, true);
			}
			if (file.getName().toLowerCase().indexOf(".zip") != -1
					&& file.length() > 0) {
				FileCompressor.UnZipFile(file, true);
				return false;
			}

			if (file.getName().toLowerCase().endsWith(".z")
					&& file.length() > 0) {
				UncompressInputStream.ZUnZipFile(file, true);
				return false;
			}

			switch (dataFeed.getProcessTypeID()) {
			case DataFeed.PROCESS_TYPE_ARCHIVE_AND_DATABASE:
				archive = true;
				database = true;
				break;
			case DataFeed.PROCESS_TYPE_ARCHIVE_ONLY:
				archive = true;
				database = false;
				break;
			case DataFeed.PROCESS_TYPE_DATABASE_ONLY:
				archive = false;
				database = true;
				break;
			default:

			}

			if (database) {

			    log.info(" Database true for file ..." + file.getName());
				try  {
                dataFile = this.convertFile(file);
                log.info("The File "+file.getName()+"has been  converted "+dataFile.getFiles().length);
				}
				catch (Exception er)
				{
					log.error(" Error while converting file "+file.getName()+"" +er.getLocalizedMessage());
				}
                records = dataFile.getRecords();
				errorRecords = dataFile.getErrorRecords();
				
				FILE_RECORDS = Long.toString(records);
				FILE_RECORDS_ERROR = Long.toString(errorRecords);

				// one time loading files list for duplicate check
				if (filesListLoadFlag) {
					initFeedManager = new MERRTFeedManagerDAO();
					List<String> filesList = initFeedManager.getFeedFilesList(dataFeed.getDataFeedID());

					for (int l = 0; l < filesList.size(); l++) {
					processedFileList.put(filesList.get(l).toString(),"completed");
					}
					filesListLoadFlag = false;
				}

				File processFile = null;
				File oriFile = null;
				
				for (String dbfile : dataFile.getFiles()) {
					
					
		log.info("File waiting thread starts  "+time+" ms for " +dbfile);
				
		          Thread.sleep(time);
		          
		          
		          log.info("File waiting thread ends   "+time+ "ms for "+dbfile);
					processFile = new File(dbfile);
					oriFile = new File(oriPath + "\\" + processFile.getName());
				
					if (processedFileList.get(processFile.getName().toString()) == null // If file not in list, then new file
							|| processedFileList.get(processFile.getName().toString()).equals("new") // // If file in new state alone
							|| processedFileList.get(processFile.getName().toString()).equals("error") ) {// If file already in error list

						if (processedFileList.get(processFile.getName().toString()) == null) 
						{

							processedFileList.put(processFile.getName().toString(), "new");
							dataFilesStatus = new DataFilesStatus();
							dataFilesStatus.setFeedFileName(processFile.getName());
							dataFilesStatus.setFeedID(dataFeed.getDataFeedID());
							dataFilesStatus.setStatus("new");
							dataFilesStatus.setErrorRecordId("4101");
							dataFilesStatus.setRecordCount(0);
							initFeedManager.saveFeedFiles(dataFilesStatus); // received file names updating into table
						}
						   
						
						if (bulkInsertInDatabase(oriFile,processFile)) {
							// process file used only for Wireless Data
							continue;
						} else {
							failed = true;
						}
					
					
					
				}
					Runtime.getRuntime().gc();
				//	Thread.sleep(time);
				}

				cal.setTimeInMillis(dataFile.getEarliestRecordDate().getTime());
				FILE_USAGE_DATE = formatTime.format(dataFile
						.getEarliestRecordDate());
				FILE_DATABASE = new Boolean(!failed).toString();
			}

			if (!failed) {
				//log.info("inside ");
				if (archive) {

//					log.info("inside archive ");
					File archiveRoot;
					File archived;

					String mm;
					String dd;

					mm = Integer.toString(cal.get(Calendar.MONTH));
					dd = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
					mm = (mm.length() == 1 ? "0" + mm : mm);
					dd = (dd.length() == 1 ? "0" + dd : dd);
					archiveRoot = new File(UDashProps.getInstance().getArchiveRoot() + "\\" + dataType.getDataTypeName() + "\\"
											+ dataFeed.getDataFeedName() + "\\" + archive_date_dir.format(new Date(cal.getTimeInMillis())));
					archiveRoot.mkdirs();
					archived = new File(UsageFileTool.getRollFileName(archiveRoot.getAbsolutePath() + "\\" + file.getName()));
					file.renameTo(archived);
					FileCompressor.GZipFile(archived, true);

					// SystemManager.getInstance().println("archived: " +
					// fi.getAbsolutePath());

					FILE_ARCHIVED = "true";

				} else {
				//	file.delete();
					try
					{
					FeedHandlerUtils.fileMove(file.getAbsolutePath(),file.getName(), "processed");
					this.log.info(" processed File moved to Processed folder"+file.getName());
				}
					catch (Exception e)
					{
					this.log.error("processed File  move error "+e.getMessage()+"for file "+file.getName());
				}
				}
			}
			endTime = new Date().getTime();
			long processTime = endTime - startTime;
			if(failed)
			{
				try
				{
				FeedHandlerUtils.fileMove(file.getAbsolutePath(),file.getName(), "err_file");
				this.log.info(" Error File moved to error folder"+file.getName());
				}
				catch (Exception e)
				{
					this.log.error("Error File  move error "+e.getMessage()+"for file "+file.getName());
				}
			}
			log.info("File: [" + file.getName() + " - " + failed + "] - MS: ["
					+ processTime + "], Recs: [" + records + "], Err Recs: ["
					+ errorRecords + "]");
			
			

			log.info("Process File is Completed for "+ file.getName());
			
			String PROCESS_DATE_COMPLETE = formatTime.format(new Date(endTime));
			String PROCESS_MILLISECONDS = Long.toString(processTime);

			StringBuffer log = new StringBuffer();
			log.append(FILE_NAME).append(",");
			log.append(FILE_DATE).append(",");
			log.append(PROCESS_DATE_START).append(",");
			log.append(PROCESS_DATE_COMPLETE).append(",");
			log.append(PROCESS_MILLISECONDS).append(",");
			log.append(FILE_USAGE_DATE).append(",");
			log.append(FILE_DATABASE).append(",");
			log.append(FILE_ARCHIVED).append(",");
			log.append(FILE_RECORDS).append(",");
			log.append(FILE_RECORDS_ERROR);

			this.writeLog(log.toString());
			if (dataFeedNotification != null) {
				dataFeedNotification.setDateLastFileCompleted(new Date());

				if (dataFeedNotification.getDateLatestUsage() == null
						|| dataFile.getEarliestRecordDate().getTime() > dataFeedNotification.getDateLatestUsage().getTime()) {
					dataFeedNotification.setDateLatestUsage(dataFile.getEarliestRecordDate());
				}
				dataFeedNotificationManager.setDataFeedNotification(dataFeedNotification);

			}
			
		}
		catch (Exception e) {
			log.error("  Error in Processing File "+file.getName()+" Error Message is :: "  +e.getLocalizedMessage());
			file.delete();
		}
		
		return true;
	
	}

	
	

	// SS7 load
/*	
	public void ss7load(File file) throws IOException
	
	
	{
		
		 URL propertiesFile = new URL(root, "mfmproperties.properties"); 
		 Properties mfmProperties = new Properties();
		 //FileInputStream in = new FileInputStream(".\\mfmproperties.properties");     
		 mfmProperties.load(propertiesFile.openStream()); 
		 
		 merrt_UNC_path=mfmProperties.getProperty("MERRT_UNC_PATH");
			
		 
		log.info("SS7 file loading  for file ::::"+file.getName());
		
		String tbl;
		String database;

		// if (dataFeed.getTableName() != null &&
		// dataFeed.getTableName().indexOf("") != -1) {
		if (dataFeed.getTableName() != null
				&& !"".equals(dataFeed.getTableName().trim())) {
			// load into getTableName();
			tbl = dataFeed.getTableName();
			database = dataFeed.getDatabaseName();
		} else {
			String[] tbls = file.getName().split("\\.");
			// log.info(file.getName() + " - " + tbls.length);
			tbl = "TBL_" + tbls[tbls.length - 2];
			database = dataFeed.getDatabaseName()
					
					+ "_"
					+ tbls[tbls.length - 2].substring(0,
							tbls[tbls.length - 2].length() - 3);
		}
		
		
    String filepath=file.getAbsolutePath();
	
	filepath=filepath.replace("D:\\", "");
	
		
	String	uncfilepath=merrt_UNC_path+filepath;
	
			
			String ss7_qry = "CALL USP_USAGE_SS7_FILE_LOAD ('"
				+ database + "', '"
				+ tbl + "',"
				+ dataFeed.getDataFeedID() + ", '"
				+ uncfilepath+ "' "; 
			
			log.info("SS7 Database Query :::::::::"+ss7_qry);
			
			
			CallableStatement proc = null;
			try {
				/*int iLoadStatus = stmt.executeUpdate(qry);
				stmt.close();
				
			Connection	conn = DriverManager.getConnection(UDashProps.getInstance().getJDBC());
				proc = conn.prepareCall("{ " + ss7_qry + ",?) }");
                proc.registerOutParameter(1, Types.INTEGER);
                proc.execute();
                log.info("SS7  Query Executed with Result  ::" +proc.getInt(1));
                
                
			}
			catch(Exception e)
			{
				log.error("SS7 file load procedure error ::: "+e.toString());
			}
			
				
		
	}
/*
	/*
	 * writeLog() method is used to write file status into log file.
	 */
	private boolean writeLog(String message) {

		SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
		String path = FeedHandlerUtils.getMFMPath(dataFeed.getPath());

		File historyFile = new File(path + "\\" + "history.log");
		if (historyFile.exists())
		{
			long bytes = historyFile.length() / 1024;
			long mb = bytes / 1024;

			if (mb > 1) {
				File logDir = new File(path + "\\logs");
				logDir.mkdirs();
				File hrn = new File(path + "\\logs\\" + "history_"
						+ format.format(new Date()) + ".log");
				historyFile.renameTo(hrn);
				historyFile = new File(path + "\\" + "history.log");
			}
		}
		PrintWriter fileWriter = null;
		try {
			boolean exists = historyFile.exists();

			fileWriter = new PrintWriter(new FileWriter(historyFile, true));
			if (!exists) {
				// historyFile.createNewFile();
				fileWriter
						.write("FILE_NAME,FILE_DATE,DATE_START,DATE_COMPLETE,PROCESS_DURATION_MS,USAGE_DATE,DATABASE,ARCHIVED,RECORDS,ERROR_RECORDS\r\n");
			}

			fileWriter.write(message + "\r\n");

		} catch (Exception error) {

			log.error(" writeLog Error: " + error.toString());

		} finally {
			try {
				fileWriter.flush();
				fileWriter.close();
				// file.renameTo(new File(path + filename));
			} catch (Exception ignore) {
				log.error(" writeLog Error: " + ignore.toString());
			}
		}
		return true;
	}

	public long getDuration() {
		long end = endTime;
		if (end == 0 && startTime != 0) {
			end = new Date().getTime();
		}
		long processTime = end - startTime;
		return processTime;
	}

	private DataType dataType;

	private DataFile convertFile(File file) {

		DataFile dataFile = new DataFile(dataType, file);

		return dataFile;
	}

	/**
	 * bulkInsertInDatabase() method is used to load data into warehouse table.
	 * Internally, it call USP_USAGE_FILE_LOAD stored procedure, The
	 * USP_USAGE_FILE_LOAD stored creates database and table as well as it
	 * updates control table.
	 * 
	 * @param oriFile
	 * @throws IOException 
	 * 
	 */

	private boolean bulkInsertInDatabase(File file, File processFile) throws IOException {
		
		//log.info("Bulk Insert Stared for file" +file.getName());
		String filepath=null;
		String uncfilepath=null;
		
		 URL propertiesFile = new URL(root, "mfmproperties.properties"); 
		 Properties mfmProperties = new Properties();
		 //FileInputStream in = new FileInputStream(".\\mfmproperties.properties");     
		 mfmProperties.load(propertiesFile.openStream()); 
		 merrt_UNC_path=mfmProperties.getProperty("MERRT_UNC_PATH");
		 
		 
		 Connection conn = null;
		
		
		log.info("### BulkInsert is processing file ::  " + file.getName() + " ###");
		log.info(" MERRT UNC Path :: "+merrt_UNC_path);
	//	System.out.println(" MERRT UNC Path :: "+merrt_UNC_path);
		
		if(merrt_UNC_path.contains("no"))

		{
		    log.info(" MERRT UNC Path= null");
		//	System.out.println(" MERRT UNC Path= null");
			uncfilepath=file.getAbsolutePath();
		}
		
			
		else
		{
		log.info(" MERRT UNC Path- not null");
		filepath=file.getAbsolutePath();
		
		log.info(" Original  Filepath "+filepath);
		
		filepath=filepath.replace("D:\\", "");
		
		//log.info(" Edited  Filepath "+filepath);
		
		uncfilepath=merrt_UNC_path+filepath;
		
		
		}
		
		//System.out.println(" Absolute UNC-Filepath "+uncfilepath);
		log.info(" Absolute UNC-Filepath "+uncfilepath);
		
		//log.info(" Absolute Filepath "+merrt_UNC_path+file.getAbsolutePath());
		boolean rtn = false;
		String qry =null;
	
		
		boolean mobileProcessed = true;
		DataFilesStatus dataFilesStatus = null;
		try {
			
			// duplicate condition checking.
			try
			{
			conn = DriverManager.getConnection(UDashProps.getInstance().getJDBC());
			//log.debug(processedFileList + " : " + file.getName());
			// if
			// ((processedFileList.get(oriFile.getName().toString())).equals("new")){

			// log.info(" Bulk inserted started db: " + file.getAbsolutePath());

			

			// if (dataFeed.getTableName() != null &&
			// dataFeed.getTableName().indexOf("") != -1) {
			if (dataFeed.getTableName() != null
					&& !"".equals(dataFeed.getTableName().trim())) {
				log.info("Getting tabel names 1");
				// load into getTableName();
				tbl = dataFeed.getTableName();
				database = dataFeed.getDatabaseName();
			} else {
				
				log.info("Getting tabel names 2");
				String[] tbls = file.getName().split("\\.");
				// log.info(file.getName() + " - " + tbls.length);
				tbl = "TBL_" + tbls[tbls.length - 2];
				database = dataFeed.getDatabaseName()+ "_"
						+ tbls[tbls.length - 2].substring(0,
								tbls[tbls.length - 2].length() - 3);
			}
			
			log.info(" Table name :::" +tbl);
			log.info(" Db  name :::: " +database);
			}
			catch (Exception w)
			{
				log.error(" Error 1 ::" +w.getLocalizedMessage());
			}
	
			
			// Duplicate check 
			
			feedfilelist=initFeedManager.getCompletedFeedFilesListbyfilename(file);
			
			if(feedfilelist.size()!=0)
			{
				String status =feedfilelist.get(0).toString();
				status=status.trim();
			    log.info("Feed file status in table for file "+file.getName()+" is "  +status);
				if(status.equalsIgnoreCase("completed"))
				{
			
			log.info("The File ---"+file.getName()+"is Already Processed by Application .. putting as Duplicate Entry...");
			dataFilesStatus = new DataFilesStatus();
			dataFilesStatus.setFeedFileName(file.getName());
			dataFilesStatus.setFeedID(dataFeed.getDataFeedID());
			dataFilesStatus.setStatus("duplicate");
			dataFilesStatus.setErrorRecordId("4102");
			dataFilesStatus.setRecordCount(0);
			initFeedManager.saveFeedFiles(dataFilesStatus);
			
			try
			{
			FeedHandlerUtils.fileMove(file.getAbsolutePath(),file.getName(), "duplicate");
			this.log.info(" Duplicete  File moved to dupliacte  folder"+file.getName());
			}
			catch (Exception ex)
			{
				this.log.info("Duplicate File move error "+ex.getMessage()+"for file "+file.getName());
			}
				
			   }
				
			}
			// Mobile data process before load
			if ((dataFeed.getDataFeedID() == 89) || (dataFeed.getDataFeedID() == 90) || (dataFeed.getDataFeedID() == 92)) {
				Statement stmt = null;
				try {

					stmt = conn.createStatement();
					mobileProcessed = runWireLessData(processFile, stmt); // File is processed in the local MFM Server for Wireless
					String strFileName = file.getName();
					tbl = "TBL_" + strFileName.substring(12, 16) + "_"+ strFileName.substring(8, 10) + "_"+ strFileName.substring(10, 12);
					database = dataFeed.getDatabaseName() + "_"+ strFileName.substring(12, 16) + "_"+ strFileName.substring(8, 10);
					if(!mobileProcessed) {
					
						this.log.info("### Feed File Data Load Failed Status ###");
						this.log.info("### Feed File " + file.getName().toString() + " ###");
						this.log.info("### No. of Records " + getRecords() + " loaded ###");
						this.log.info("### Feed File " + file.getName().toString() + " moved to error directory " + this.dataFeed.getPath() + "//err_file ###");
						
						processedFileList.put(file.getName().toString(),"error");
						dataFilesStatus = new DataFilesStatus();
						dataFilesStatus.setFeedFileName(file.getName());
						dataFilesStatus.setFeedID(this.dataFeed.getDataFeedID());
						dataFilesStatus.setStatus("error");
						dataFilesStatus.setErrorRecordId("4103");
						dataFilesStatus.setRecordCount(Integer.parseInt(getErrorRecords() + "")); // need to add logic
						initFeedManager.saveFeedFiles(dataFilesStatus);
//						try{
//							FeedHandlerUtils.fileMove(file.getAbsolutePath(),file.getName(), "err_file");
//							this.log.info(" Error File moved to error folder"+file.getName());
//							}
//							catch (Exception e)
//							{
//								this.log.info("Mobile Error File  move error "+e.getMessage()+"for file "+file.getName());
//							}
//
//						File err_parent = new File(processFile.getParentFile().getAbsolutePath() + "\\err_file\\");
//						err_parent.mkdirs();
//						processFile.renameTo(new File(UsageFileTool.getRollFileName(err_parent.getAbsolutePath()+ "\\" + processFile.getName())));
			

						return false;
					} 

				} catch (Exception e) {
					log.error(" Error in runwirelessdata call main method "
							+ e.toString());
				}
				finally {
					try{stmt.close();}catch(Exception e){};
				}
			}
			
			
			if (tbl.toLowerCase().indexOf("tbl_nodate") == -1
					|| (dataFeed.getTableName() != null && dataFeed.getTableName().indexOf("") != -1)) {
				
				
				log.info(" File load script start for file :: "+file.getName());
/*				String qry = "USP_USAGE_FILE_LOAD @FILE='"
						+ file.getAbsolutePath() + "', @DATA_FEED_ID='"
						+ dataFeed.getDataFeedID() + "', @DATABASE_NAME='"
						+ database + "', @TABLE_NAME='" + tbl + "'";*/
				if(dataFeed.getDataFeedID()==93 || dataFeed.getDataFeedID()==94)
				{
				 qry = "CALL USP_USAGE_FILE_LOAD ('"
					+ database + "', '"
					+ tbl + "',"
					+ dataFeed.getDataFeedID() + ", '"
					+ uncfilepath+ "' "; }
				else
				{
					 qry = "CALL USP_USAGE_FILE_LOAD ('"
							+ database + "', '"
							+ tbl + "',"
							+ dataFeed.getDataFeedID() + ", '"
							+ uncfilepath+ "' "; }
				}
					
				log.info("Database Query :::::::::"+qry);
				/*Statement stmt = null;
				try {
					stmt = conn.createStatement();
					stmt.executeQuery("SELECT TOP 0 DATA_FEED_ID FROM TBL_DATA_FEED");
				} catch (Exception error) {
					log.error(" Error: " + error.toString());
					stmt = null;
					try {
						stmt = conn.createStatement();
						stmt.executeQuery("SELECT TOP 0 DATA_FEED_ID FROM TBL_DATA_FEED");
						stmt.close();
					} catch (Exception error2) {
						stmt = null;
						log.error(" Error: " + error2.toString());
					}
				} finally {
					try{stmt.close();}catch(Exception e){};
				}*/
				/*if (stmt == null) {
					return false;
				}*/
				
				
				try {
					/*int iLoadStatus = stmt.executeUpdate(qry);
					stmt.close();*/
					int result =-1;					
					for(int retry = 0; retry <3; retry++) {
						
						 log.info ("Executing File load Script  "+retry+" time ");
						CallableStatement proc = null;
					    result = -1;
						//rtn = true;
					
						try
						{
						proc = conn.prepareCall("{ " + qry + ",?) }");
						proc.setInt(2,0);
		                proc.registerOutParameter(1, Types.INTEGER);
		                proc.execute();
		                result = proc.getInt(1);
		                log.info(" Query Executed with Result  ::" +result);
						}
						catch(SQLServerException e)
						{
							// Parameter is not setting .Thus moving to error folders 
							log.error("Parameter set error for file  "+file.getName()+" Error Mesasge is ::"+e.getLocalizedMessage());
							
							
							feedfilelist=initFeedManager.getFeedFilesListbyfilename(file);
							
							if( feedfilelist!=null && feedfilelist.size()>0)
							{
								String status =feedfilelist.get(0).toString();
								if(status!=null){				
								
									status=status.trim();
								    //log.info("Feed file status in table for file "+file.getName()+" is "  +status);
									if(status.equalsIgnoreCase("completed"))
									{
										result=0;
									}
									else
									{
										result=-1;
									}
								}
							}
							else
							{
								result=-1;
							}
						} 
						catch(Exception e)
						{
							log.error("Exception in status " +e.getLocalizedMessage());
							result=-1;
						}
						finally {
							try {
								if(proc != null) {
									proc.close();
									proc = null;
								}
							}catch (Exception e) {}
						}

						if(result != -1) {
							break;
						}
					}
					
                   // log.info(" query Executed ");
                  
					log.info(" File load Script result for file"+file.getName()+" is ::" +result);
	                  
					if (result == -1)
					{
						
						this.log.info("### Feed File Data Load Failed Status ###");
						this.log.info("### Feed File " + file.getName().toString() + " ###");
						this.log.info("### No. of Records " + getRecords() + " loaded ###");
						this.log.info("### Feed File " + file.getName().toString() + " moved to error directory " + this.dataFeed.getPath() + "//err_file ###");
						processedFileList.put(file.getName().toString(),"error");
						dataFilesStatus = new DataFilesStatus();
						dataFilesStatus.setFeedFileName(file.getName());
				        dataFilesStatus.setFeedID(this.dataFeed.getDataFeedID());
						dataFilesStatus.setStatus("error");
						dataFilesStatus.setErrorRecordId("4103");
						dataFilesStatus.setRecordCount(Integer.parseInt(getRecords() + "")); // need to add logic
						initFeedManager.saveFeedFiles(dataFilesStatus);
						
                   //     file.delete();
						try
						{
						FeedHandlerUtils.fileMove(file.getAbsolutePath(),file.getName(), "err_file");
						this.log.info(" Error File moved to error folder"+file.getName());
						}
						catch (Exception e)
						{
							this.log.info("Error File  move error "+e.getMessage()+"for file "+file.getName());
						}
						File err_parent = new File (processFile.getParentFile().getAbsolutePath() + "\\err_file\\");
						err_parent.mkdirs();
						processFile.renameTo(new File(UsageFileTool.getRollFileName(err_parent.getAbsolutePath()+ "\\" + processFile.getName())));

						rtn = false;

					
					} else {
						this.log.info("### Bulk insert Success file"+file.getName());
						this.log.info("### Feed File Data Load Success Status ###");
						this.log.info("### Feed Name " + this.dataFeed.getDataFeedName() + " ###");
						this.log.info("### Feed File " + file.getName().toString() + " ###");
						this.log.info("### No. of Records" + getRecords() + " loaded ###");
						
						processedFileList.put(file.getName().toString(),"completed");
						dataFilesStatus = new DataFilesStatus();
						dataFilesStatus.setFeedFileName(file.getName().toString());
						dataFilesStatus.setFeedID(this.dataFeed.getDataFeedID());
						dataFilesStatus.setStatus("completed");
						dataFilesStatus.setErrorRecordId("4102");
						dataFilesStatus.setRecordCount(Integer.parseInt(getRecords() + ""));
						initFeedManager.updateFeedFiles(dataFilesStatus);
						file.delete();
//						try
//						{
//						FeedHandlerUtils.fileMove(file.getAbsolutePath(),file.getName(), "processed");
//						this.log.info(" Processed  File moved to processed folder"+file.getName());
//						}
//						catch (Exception e)
//						{
//							this.log.info(" Processed File  move error "+e.getMessage()+"for file "+file.getName());
//						}
//						

						rtn = true;
					}
					}

					 catch (Exception error) {
					log.error(" bulk insert " + error.toString());
				} 
			}
		catch (Exception e) {
			log.error("Exception"+e.toString());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
			}
		}
		return rtn;
	}

	/**
	 * 
	 * runWireLessData() method process mobile data files. It creates sql
	 * statements and adds batch process to insert into respective data base.
	 * 
	 */
	
	  public boolean runWireLessData(File fileName, Statement st)
	  {
		  log.info("Running Wireles data for file:"+fileName.getName());
		  
	    FileInputStream fstream = null;
	    DataInputStream in = null;
	    StringBuffer StrSQL03 = null;
	    StringBuffer StrSQL04 = null;
	    StringBuffer StrSQL05 = null;
	    try
	    {
	      fstream = new FileInputStream(fileName);

	      in = new DataInputStream(fstream);
	      BufferedReader br = new BufferedReader(new InputStreamReader(in));

	      StringTokenizer recordToken = null;
	      String strRecordType = null;
	      int countErrorRecords = 0;

	      StrSQL03 = new StringBuffer("insert into ucore.dbo.tbl_tmp_wireless_03 (RECORD_ID,NET_ELEM_NO,CALL_DATA_RCD_DT,SWCH_TYPE_IND,AUTO_STRCTR_CD,SWCH_NO,MID,MIN,DLD_DGT_NO,OPLSD_DGT_NO,EQPMT_SRL_NO_MEID,CALL_DIRN_IND,ROMR_STAT_IND,SZR_DT_TM,SZR_DURTN_CNT,ANSW_DT_TM,ANSW_DURTN_CNT,INIT_CELL_NO,FINL_CELL_NO,TRK_MBR_ID,CCI_IND,MOTO_CXR_ID,MOTO_CALL_TYPE_CD,MOTO_MIDN_ROLL_IND,AUTO_CALL_TYPE_CD,AUTO_CPN_NO,AUTO_OVS_IND,AUTO_SVC_FEAT_CD,AUTO_CXR_PRFX_CD,ANSW_STAT_IND,SVC_FEAT_CD,NORT_SVC_FEAT_CD,SID_NO,TERM_CD,CALL_DLVRY_IND,FEAT_SETUP_IND,THREE_WAY_CALL_IND,CALL_WAIT_IND,BUSY_XFER_IND,NO_ANSW_XFER_IND,CALL_FWD_IND,WORLD_NO,BID) values(");

	      StrSQL04 = new StringBuffer("insert into ucore.dbo.tbl_tmp_wireless_04 (RECORD_ID,RECORD_TYPE,MTN_MDN,MIN,EVENT_DATE,EVENT_TYPE,EVENT_TIME,FILLER,EVDO_INDICATOR,Filler_1,FEATURE_ID,ESN,EVENT_UNITS,SYSTEM_ID_SID,ORIGINATING_CELL_SITE,MSC_ID,WAP_INDICATOR,TOTAL_SOU,ROUNDED_TOTAL_KBU,ROUNDED_TOTAL_KBU_5_PLACES,EVENT_START_DATE,MEID,EVENT_ID,BILLING_SEQUENCE_NUMBER,CATEGORY_DESCRIPTION) values(");

	      StrSQL05 = new StringBuffer("insert into  ucore.dbo.tbl_tmp_wireless_05 values(");
	      boolean flag = true;
	      String strField = null;
	      int rec03DateCounter = 0;
	      int rec05DateCounter = 0;

	      int rec03Count = 0;
	      int rec04Count = 0;
	      int rec05Count = 0;
	      String strLine;
	      
	      while (((strLine = br.readLine()) != null) && (strLine != "\n"))
	      {
	    	  

        	 // log.info("Inside while 1 ");
	        if (getErrorRecords(strLine)) {
	          countErrorRecords++;
	        }
	        else
	        {
	          recordToken = new StringTokenizer(strLine, ",");
	          strRecordType = recordToken.nextToken();

	          while (recordToken.hasMoreTokens())
	          {
	        	//  log.info("Inside while 2 ");
	            strField = recordToken.nextToken();

	            if (strRecordType.equals("03"))
	            {
	              strField = strField.trim();
	              if (rec03DateCounter == 2) strField.length();

	              rec03DateCounter++;

	              if (flag) {
	                StrSQL03.append("'").append(strRecordType).append("',");
	              }
	              if (strField != "\n")
	                StrSQL03.append("'").append(strField).append("',");
	              else
	                StrSQL03.append("'").append(strField).append("'");
	            }
	            else if (strRecordType.equals("04")) {
	              strField = strField.trim();
	              if (flag) {
	                StrSQL04.append("'").append(strRecordType).append("',");
	              }
	              if (strField != "\n")
	                StrSQL04.append("'").append(strField).append("',");
	              else {
	                StrSQL04.append("'").append(strField).append("'");
	              }
	            }
	            else
	            {
	              if (!strRecordType.equals("05"))
	                break;
	              strField = strField.trim();

	              rec05DateCounter++;

	              if (flag) {
	                StrSQL05.append("'").append(strRecordType).append("',");
	              }
	              if (strField != "\n")
	                StrSQL05.append("'").append(strField).append("',");
	              else {
	                StrSQL05.append("'").append(strField).append("'");
	              }

	            }

	            flag = false;
	          }

	          flag = true;
	          if (strRecordType.equals("03"))
	          {
	            StrSQL03.append(")");

	            st.addBatch(StrSQL03.toString().replace(",)", ")"));
	         //log.info("Adding batch  for  03 type " + StrSQL03);
	          //  rec03Count++;

	            StrSQL03 = new StringBuffer("insert into ucore.dbo.tbl_tmp_wireless_03 (RECORD_ID,NET_ELEM_NO,CALL_DATA_RCD_DT,SWCH_TYPE_IND,AUTO_STRCTR_CD,SWCH_NO,MID,MIN,DLD_DGT_NO,OPLSD_DGT_NO,EQPMT_SRL_NO_MEID,CALL_DIRN_IND,ROMR_STAT_IND,SZR_DT_TM,SZR_DURTN_CNT,ANSW_DT_TM,ANSW_DURTN_CNT,INIT_CELL_NO,FINL_CELL_NO,TRK_MBR_ID,CCI_IND,MOTO_CXR_ID,MOTO_CALL_TYPE_CD,MOTO_MIDN_ROLL_IND,AUTO_CALL_TYPE_CD,AUTO_CPN_NO,AUTO_OVS_IND,AUTO_SVC_FEAT_CD,AUTO_CXR_PRFX_CD,ANSW_STAT_IND,SVC_FEAT_CD,NORT_SVC_FEAT_CD,SID_NO,TERM_CD,CALL_DLVRY_IND,FEAT_SETUP_IND,THREE_WAY_CALL_IND,CALL_WAIT_IND,BUSY_XFER_IND,NO_ANSW_XFER_IND,CALL_FWD_IND,WORLD_NO,BID) values(");
	          }
	          else if (strRecordType.equals("04"))
	          {
	            StrSQL04.append(")");

	            st.addBatch(StrSQL04.toString().replace(",)", ")"));

	           //log.info("Adding batch  for  04 type " +   StrSQL04);
	           // rec04Count++;

	            StrSQL04 = new StringBuffer("insert into ucore.dbo.tbl_tmp_wireless_04 (RECORD_ID,RECORD_TYPE,MTN_MDN,MIN,EVENT_DATE,EVENT_TYPE,EVENT_TIME,FILLER,EVDO_INDICATOR,Filler_1,FEATURE_ID,ESN,EVENT_UNITS,SYSTEM_ID_SID,ORIGINATING_CELL_SITE,MSC_ID,WAP_INDICATOR,TOTAL_SOU,ROUNDED_TOTAL_KBU,ROUNDED_TOTAL_KBU_5_PLACES,EVENT_START_DATE,MEID,EVENT_ID,BILLING_SEQUENCE_NUMBER,CATEGORY_DESCRIPTION) values(");
	          }
	          else if (strRecordType.equals("05"))
	          {
	            StrSQL05.append(")");

	            st.addBatch(StrSQL05.toString().replace(",)", ")"));
	          //  log.info("Adding batch  for  05 type " +   StrSQL05);

	           // rec05Count++;

	            StrSQL05 = new StringBuffer("insert into  ucore.dbo.tbl_tmp_wireless_05 values(");
	          }
	          strRecordType = null;
	          recordToken = null;

	          rec03DateCounter = 0;
	          rec05DateCounter = 0;
	        }
	      }
	      int[] successRecordsCount = st.executeBatch();

	      setErrorRecords(countErrorRecords);
	      setRecords((long)rec03Count + rec04Count + rec05Count);

	      this.log.info(" Mobile Data Feed Loading - No of error records " + 
	        countErrorRecords);
	      this.log.info(" Mobile Data Feed Loading - No of records " + 
	        successRecordsCount.length + " loaded");
	      this.log.info(" Record status update started.");
	      this.log.info(" ### Mobile Data DUR Files - Data Records inserted statics update ###  from file " + 
	        fileName.getName());

	      this.log.info(" ### Mobile Data DUR Files - No of Voice Record(s) (03 type)" + 
	        rec03Count + "inserted. ");
	      this.log.info(" ### Mobile Data DUR Files - No of Data Record(s)  (04 type)" + 
	        rec04Count + " inserted. ");
	      this.log.info(" ### Mobile Data DUR Files - No of SMS Record(s)  (05 type)" + 
	        rec05Count + " inserted.  ");

	      log.info(" Record status update completed.");
	      log.info(" Wireless Record Process completed file Mobile File ::: "+fileName.getName());
	      
	    }
	    catch (Exception error)
	    {
	      this.log.error(" runWireLessData " + error.toString());
	      return false;
	    }
	   
	    finally {
	      StrSQL03 = null;
	      StrSQL04 = null;
	      StrSQL05 = null;
	      try {
	        in.close();
	        fstream.close();
	      } catch (Exception e) {
	        this.log.error("File close error " + e);
	      }
	    }
	    return true;
	  }


	  public boolean getErrorRecords(String strLine)
	  {
	    StringTokenizer strReords = new StringTokenizer(strLine, ",");
	    int iColumnCount = 0;
	    String recordType = strReords.nextToken();
	    iColumnCount++;

	    while (strReords.hasMoreTokens()) {
	      strReords.nextToken();
	      iColumnCount++;
	    }

	    if ((recordType == "03") || (recordType.equals("03")))
	    {
	      return iColumnCount != 43;
	    }

	    if ((recordType == "04") || (recordType.equals("04")))
	    {
	      return iColumnCount != 25;
	    }

	    if ((recordType == "05") || (recordType.equals("05")))
	    {
	      if (iColumnCount == 22) {
	        return false;
	      }

	      return (recordType.contains("@")) ||(recordType.contains(".com")) || (recordType.length() >= 35);
	    }

	    return false;
	  }


	/**
	 * runCopy()method copies SS7 files
	 */
	public void runCopy() {
		log.info(" Run Copy ::::::::");

		File inpath;
		FilenameFilter filter;
		String path = FeedHandlerUtils.getMFMPath(dataFeed.getPath());

		File droppath = new File(path);
		droppath.mkdirs();
		File logFile = new File(droppath.getAbsolutePath() + "\\collect.log");

		inpath = new File(dataFeed.getInputJDBC());
		filter = new GeneralFileFilter(dataFeed.getInputDbDriver());
		// log.info(" copying files started."); 
		PrintWriter errorLogWriter = null;

		try {

			errorLogWriter = new PrintWriter(new FileWriter(logFile, true));
		} catch (Exception error) {
			error.printStackTrace();
			log.error(" Error: " + error.toString());
		}

		if (inpath.isDirectory()) {
			for (File file : inpath.listFiles(filter)) {
				if (file.isFile() && !FileHelper.isFileOpen(file)
						&& file.exists()
						&& !UsageFileTool.isDuplicateFileInLog(file, logFile)) {
					try {
						UsageFileTool.copyFile(
								file,
								new File(UsageFileTool.getRollFileName(droppath
										.getAbsolutePath()
										+ "\\"
										+ file.getName())));
						errorLogWriter.write(file.getName() + "\r\n");
						SystemManager.getInstance().println(
								"<u>File</u>:" + file.getName() + " - Copied");
						log.info(" file copied " + file.getName());
					} catch (Exception error) {

						log.error(error.toString());
					}
				}
				if (!doRun) {
					break;
				}
			}
		}

		try {
			errorLogWriter.close();
		} catch (Exception error) {
			error.printStackTrace();
			log.error(" Error : " + error.toString());
		}
	}

	/**
	 * runDataPoll() method polls SS7 data from database
	 * 
	 */
	private void runDataPoll(final DataFeed dataFeed) {

		long pollint = 0;
		switch (dataFeed.getSourceTypeID()) {
		case 1:
			if (dataFeed.getInputJDBC() != null
					&& dataFeed.getInputJDBC().length() > 0) {
				try {
					if (dataFeed.getInputTable() != null) {
						pollint = Long.parseLong(dataFeed.getInputTable());
					}
					if (pollint > 0) {
						log.info("Checking for new files..."
								+ dataFeed.getDataFeedName());
						runCopy();
						log.info("Checking for new files..."
								+ dataFeed.getDataFeedName() + "...done");
					}
				} catch (Exception error) {
					error.printStackTrace();
					log.error(" Error in Run Data Poll Case 1 : " + error.toString() + " : " + dataFeed.getDataFeedID());
				}
			}
			break;
		case 2:
			   try{

					log.info(" creating new   theread for feed "+dataFeed.getDataFeedName());

				if(!isSS7ThreadCreated){
					
					isSS7ThreadCreated=true;
					Thread thread = (new Thread() {
					public void run() {
						
						log.info(" creating sub  theread for feed "+dataFeed.getDataFeedName());
						while(doRun) {
							try {
								
								Thread.sleep(dataFeed.getPollInterval());
							} catch (InterruptedException e) {
								log.error(" Error in Creating sub theread for feed"+dataFeed.getDataFeedName()+ "  : " + e.toString());
							}
							buildFileFromDatabase(dataFeed);
							
					}
						
					} 
				});  
				thread.start(); }
				}catch(OutOfMemoryError d) {
					log.error(" Thread Error in Creating sub theread for feed"+dataFeed.getDataFeedName()+ "  : " + d.toString());
					}
				break;
			}
	}

	/**
	 * runBatch() method used to load data from file to warehouse table
	 */
	private void runBatch() {
		
//	log.info(" Running Batch for started for datafeed " +dataFeed.getDataFeedName());
		File inpath = null;
		FilenameFilter filter;
		String path = FeedHandlerUtils.getMFMPath(dataFeed.getPath());
		String oriPath = dataFeed.getPath();

		inpath = new File(path);
          
		filter = new GeneralFileFilter(dataFeed.getFileMask());
		File[] infiles;

		try {
			// it is checking folder existed or not. If not existed, the method
			// will create a folder
			FeedHandlerUtils.isFolderExist(path);
			// files are picking from feeddirectory
			//System.out.println("Testing " + path + "  " + Thread.currentThread().getName());
			if (inpath.isDirectory()) {
				
				log.info( "Path directory "+inpath.getAbsolutePath());

				infiles = inpath.listFiles(filter);
				log.info( " File count for feed  "+dataFeed.getDataFeedName()+" is "+infiles.length);
				
				Arrays.sort(infiles, new Comparator<File>() 
						{
					@Override
					public int compare(File o1, File o2) {
						return ((File) o1).getName().compareTo(
								((File) o2).getName());
					}
				});
				
				filesInQueue = 0;
				
				//log.info( " File length after sort for feed  "+dataFeed.getDataFeedName()+" is "+infiles.length);
				
				
				for (File file : infiles) {				
					if (!file.isDirectory())
						filesInQueue++;
					
					
				} //log.info(" File Queue size "+filesInQueue);
				
				//log.info("Files in Queue for data feed "+dataFeed.getDataFeedName()+" is"   +filesInQueue);
				// filesInQueue = infiles.length - 1;

				// one time loading files list for duplicate check
				if (filesListLoadFlag) {
					
					//log.info("Getting list");
					
					initFeedManager = new MERRTFeedManagerDAO();
					//log.info("Getting list 2 ");
					List<String> filesList = initFeedManager.getFeedFilesList(dataFeed.getDataFeedID());
                         
					log.info("filelist size  "+filesList.size());
					for (int l = 0; l < filesList.size(); l++) {
						
						processedFileList.put(filesList.get(l).toString(),"completed");
					}
					//log.info("prcess filelist size  "+processedFileList.size());
					filesListLoadFlag = false;
				}
                log.info("Ready to process files for feed "+dataFeed.getDataFeedName());
				
                for (File file : infiles) {
				
					log.info("Started processing  file for feed "+dataFeed.getDataFeedName());
					if (file.isDirectory())
						continue;

					if (dataFeedNotification != null) {
						dataFeedNotification.setQueued(new Long(filesInQueue));
						dataFeedNotificationManager.setDataFeedNotification(dataFeedNotification);
					}

					if (file.exists()) {

						log.info(" File open ..." + file.getName());

						// getting files from directory and adding to processed
						// file list to check duplicate

						this.processFile(file, oriPath);
						this.deleteOldDBoutfiles(oriPath);
						//this.deleteOldProcessedfiles(oriPath);
						filesInQueue = filesInQueue - 1;
						this.status = STATUS_IDLE;
						if (dataFeedNotification != null) {
							dataFeedNotification.setQueued(new Long(filesInQueue));
							dataFeedNotification.setStatus(new Integer(STATUS_IDLE));
							dataFeedNotificationManager.setDataFeedNotification(dataFeedNotification);
						}
					}
					// log.info(" Files in queue : "+filesInQueue);
					if (!doRun) {
						break;
					}
					file = null;
				}
			} else {
				if (inpath.exists()) {
					if (!FileHelper.isFileOpen(inpath)) 
					{
						this.processFile(inpath, oriPath);
						this.deleteOldDBoutfiles(oriPath);
					//	this.deleteOldProcessedfiles(oriPath);
						this.status = STATUS_IDLE;
						if (dataFeedNotification != null) {
							dataFeedNotification.setStatus(new Integer(
									STATUS_IDLE));
							dataFeedNotificationManager
									.setDataFeedNotification(dataFeedNotification);
						}
					}
				} else {
					SystemManager.getInstance().println(
							"File does not exist [" + inpath.getAbsolutePath()
									+ "]");
					//log.info("File does not exist [" + inpath.getAbsolutePath()
						//	+ "]");
				}
			}
			//log.info("  Batch Process completed for  datafeed "+dataFeed.getDataFeedName());
		} catch (Exception e) {
			log.error("Error in run Batch " +e.toString());
			
		}
	}

	/**
	 * keepAlive() method is used to keep thread active with database if there
	 * are no feed files.
	 * @throws SQLException 
	 * 
	 */
	
	/* public void keepAlive(final DataFeed dataFeed) throws SQLException {
		 
	//	 log.info("Keeping Alive Datafeed "+dataFeed.getDataFeedName());
		 
		 Connection conn = DriverManager.getConnection(UDashProps.getInstance().getJDBC());
	 try {
	 
	
	  Statement stmt = conn.createStatement();
	  stmt.executeQuery("SELECT TOP 0 * FROM TBL_DATA_FEED"); stmt.close();
	  
	  } 
	 catch (Exception error) 
	 { 
		 log.error(" Error in keepalive "+error.toString()); }
	 
	  finally { 
		  try {
			  if(conn !=null) 
				  conn.close();
			  }
		  catch (Exception e)
		  
	  {
			  log.error(e.toString());
			  } }
	  }
	 */

	/**
	 * It is data processor thread entry point.
	 */
	public void run() 
	{
		doRun = true;
		this.status = STATUS_IDLE;
		lastStatusDate = new Date();
		running = true;
		log.info("Thread  started for "+dataFeed.getDataFeedName());
		try {
			if (dataFeed.isContinuous()) {
				if (!UDashProps.getInstance().isRemote()) {
					try {

						// conn =
						// DriverManager.getConnection(UDashProps.getInstance().getJDBC());

					} catch (Exception error) {
						log.error(" run() Error1 " + error.toString());
					}
				}

				if (dataFeedNotification != null) {
					dataFeedNotification.setStatus(new Integer(STATUS_IDLE));
					dataFeedNotificationManager.setDataFeedNotification(dataFeedNotification);
				}
				while (doRun) {					
					this.runDataPoll(dataFeed);
				//	this.keepAlive(dataFeed);
					this.runBatch();
					try {
						//log.info("DataProcessor Thread "+dataFeed.getDataFeedName()+"sleeping for "+ dataFeed.getPollInterval());
						Thread.sleep(dataFeed.getPollInterval());
				//		dataFeed.getFile_interval();
						//log.info("DataProcessor Thread "+dataFeed.getDataFeedName()+" Sleep over");
					} catch (Exception error) {
						log.error(" run() Error2 " + error.toString()); 
					}
				}
			}
			else 
			{
				log.info("Thread "+dataFeed.getDataFeedName()+"sleeping for "+ dataFeed.getPollInterval());
				this.runBatch();
				log.info("Thread "+dataFeed.getDataFeedName()+" Sleep over");
			}
		}
catch (Exception error) {		

			log.error(" Batch run() Error for  "+dataFeed.getDataFeedName()+" ::"  + error.toString());
		}
		this.status = STATUS_STOPPED;
		if (dataFeedNotification != null) {
			dataFeedNotification.setStatus(new Integer(STATUS_STOPPED));
			dataFeedNotificationManager
					.setDataFeedNotification(dataFeedNotification);
		}
		lastStatusDate = new Date();
		running = false;
	}

	/**
	 * stopProcess() method stop the thread
	 */
	public void stopProcess()
	{
		try {
			this.status = STATUS_STOPPING;
			if (dataFeedNotification != null) {
				dataFeedNotification.setStatus(new Integer(STATUS_STOPPING));
				dataFeedNotificationManager
						.setDataFeedNotification(dataFeedNotification);
			}
			lastStatusDate = new Date();
			doRun = false;
			// this.interrupt();
			doRun = false;
		} catch (Exception error) {
			log.info(" stop() error " + error.toString());
		}
	}

	public DataFeed getDataFeed() {
		return dataFeed;
	}

	public int getStatus() {
		return status;
	}

	public boolean isRunning() {
		return running;
	}

	public File getFile() {
		return file;
	}

	public Date getLastStatusDate() {
		return lastStatusDate;
	}

	public long getErrorRecords() {
		return errorRecords;
	}

	public void setErrorRecords(long lerrorRecords) {
		this.errorRecords = lerrorRecords;
	}

	public long getRecords() {
		return records;
	}

	public void setRecords(long lRecords) {
		this.records = lRecords;
	}

	public long getDatabaseRecordAt() {
		return databaseRecordAt;
	}

	public long getDatabaseRecordWrite() {
		return databaseRecordWrite;
	}

	public int getFilesInQueue() {
		return filesInQueue;
	}

	public static FeedProcessJMXMBean getFeedProcessJMXBean() {
		return feedProcessJMXBean;
	}

	public static void setFeedProcessJMXBean(
			FeedProcessJMXMBean feedProcessJMXBean) {
		DataProcessorThread.feedProcessJMXBean = feedProcessJMXBean;
	}

	

	
	
}