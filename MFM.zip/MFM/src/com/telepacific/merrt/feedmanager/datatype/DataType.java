/**
 * <p>Title: DataType</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype;

public class DataType {
    public static final int DURATION_TYPE_MI_SS_ML = 1;
    public static final int DURATION_TYPE_SECONDS = 2;
    public static final int DURATION_TYPE_MILLISECONDS = 3;

    private int dataTypeID;
    private String dataTypeName;
    private int headerLength;
    private int trailerLength;
    private int fixedRecordLength;
    private int keyStart;
    private int keyLength;
    private int modKeyStart;
    private int modKeyLength;
    private boolean bcd;
    private boolean multiline;
    private int yyyyStart;
    private int yyyyLength;
    private int yyyyIncrement;
    private int mmStart;
    private int mmLength;
    private int ddStart;
    private int ddLength;
    private int hhStart;
    private int hhLength;
    private int miStart;
    private int miLength;
    private int ssStart;
    private int ssLength;
    private int mlStart;
    private int mlLength;
    private int durationTypeID;

    private int durMiStart;
    private int durMiLength;
    private int durSsStart;
    private int durSsLength;
    private int durMlStart;
    private int durMlLength;

    public DataType() {

    }

    public int getHeaderLength() {
        return headerLength;
    }

    public void setHeaderLength(int headerLength) {
        this.headerLength = headerLength;
    }

    public int getTrailerLength() {
        return trailerLength;
    }

    public void setTrailerLength(int trailerLength) {
        this.trailerLength = trailerLength;
    }

    public int getFixedRecordLength() {
        return fixedRecordLength;
    }

    public void setFixedRecordLength(int fixedRecordLength) {
        this.fixedRecordLength = fixedRecordLength;
    }

    public boolean isBcd() {
        return bcd;
    }

    public void setBcd(boolean bcd) {
        this.bcd = bcd;
    }

    public int getDataTypeID() {
        return dataTypeID;
    }

    public void setDataTypeID(int dataTypeID) {
        this.dataTypeID = dataTypeID;
    }

    public String getDataTypeName() {
        return dataTypeName;
    }

    public void setDataTypeName(String dataTypeName) {
        this.dataTypeName = dataTypeName;
    }

    public int getDdLength() {
        return ddLength;
    }

    public void setDdLength(int ddLength) {
        this.ddLength = ddLength;
    }

    public int getDdStart() {
        return ddStart;
    }

    public void setDdStart(int ddStart) {
        this.ddStart = ddStart;
    }

    public int getDurationTypeID() {
        return durationTypeID;
    }

    public void setDurationTypeID(int durationTypeID) {
        this.durationTypeID = durationTypeID;
    }

    public int getHhLength() {
        return hhLength;
    }

    public void setHhLength(int hhLength) {
        this.hhLength = hhLength;
    }

    public int getHhStart() {
        return hhStart;
    }

    public void setHhStart(int hhStart) {
        this.hhStart = hhStart;
    }

    public int getKeyLength() {
        return keyLength;
    }

    public void setKeyLength(int keyLength) {
        this.keyLength = keyLength;
    }

    public int getKeyStart() {
        return keyStart;
    }

    public void setKeyStart(int keyStart) {
        this.keyStart = keyStart;
    }

    public int getMiLength() {
        return miLength;
    }

    public void setMiLength(int miLength) {
        this.miLength = miLength;
    }

    public int getMiStart() {
        return miStart;
    }

    public void setMiStart(int miStart) {
        this.miStart = miStart;
    }

    public int getMlLength() {
        return mlLength;
    }

    public void setMlLength(int mlLength) {
        this.mlLength = mlLength;
    }

    public int getMlStart() {
        return mlStart;
    }

    public void setMlStart(int mlStart) {
        this.mlStart = mlStart;
    }

    public int getMmLength() {
        return mmLength;
    }

    public void setMmLength(int mmLength) {
        this.mmLength = mmLength;
    }

    public int getMmStart() {
        return mmStart;
    }

    public void setMmStart(int mmStart) {
        this.mmStart = mmStart;
    }

    public int getModKeyLength() {
        return modKeyLength;
    }

    public void setModKeyLength(int modKeyLength) {
        this.modKeyLength = modKeyLength;
    }

    public int getModKeyStart() {
        return modKeyStart;
    }

    public void setModKeyStart(int modKeyStart) {
        this.modKeyStart = modKeyStart;
    }

    public boolean isMultiline() {
        return multiline;
    }

    public void setMultiline(boolean multiline) {
        this.multiline = multiline;
    }

    public int getSsLength() {
        return ssLength;
    }

    public void setSsLength(int ssLength) {
        this.ssLength = ssLength;
    }

    public int getSsStart() {
        return ssStart;
    }

    public void setSsStart(int ssStart) {
        this.ssStart = ssStart;
    }

    public int getYyyyIncrement() {
        return yyyyIncrement;
    }

    public void setYyyyIncrement(int yyyyIncrement) {
        this.yyyyIncrement = yyyyIncrement;
    }

    public int getYyyyLength() {
        return yyyyLength;
    }

    public void setYyyyLength(int yyyyLength) {
        this.yyyyLength = yyyyLength;
    }

    public int getYyyyStart() {
        return yyyyStart;
    }

    public void setYyyyStart(int yyyyStart) {
        this.yyyyStart = yyyyStart;
    }


    public int getDurMiLength() {
        return durMiLength;
    }

    public void setDurMiLength(int durMiLength) {
        this.durMiLength = durMiLength;
    }

    public int getDurMiStart() {
        return durMiStart;
    }

    public void setDurMiStart(int durMiStart) {
        this.durMiStart = durMiStart;
    }

    public int getDurMlLength() {
        return durMlLength;
    }

    public void setDurMlLength(int durMlLength) {
        this.durMlLength = durMlLength;
    }

    public int getDurMlStart() {
        return durMlStart;
    }

    public void setDurMlStart(int durMlStart) {
        this.durMlStart = durMlStart;
    }

    public int getDurSsLength() {
        return durSsLength;
    }

    public void setDurSsLength(int durSsLength) {
        this.durSsLength = durSsLength;
    }

    public int getDurSsStart() {
        return durSsStart;
    }

    public void setDurSsStart(int durSsStart) {
        this.durSsStart = durSsStart;
    }
}
