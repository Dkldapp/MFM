/**
 * <p>Title: DataTypeManager</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype;

import com.telepacific.merrt.feedmanager.datatype.DataType;

public interface DataTypeManager {
    public DataType[] getDataType();
    public DataType getDataType(int dataTypeID);
    public DataType setDataType(DataType dataType);
    public void reload();
    public void delete(DataType dataType);

}
