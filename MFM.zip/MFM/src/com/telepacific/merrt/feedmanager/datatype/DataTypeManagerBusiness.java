/**
 * <p>Title: DataTypeManagerBusiness</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype;

import com.telepacific.merrt.feedmanager.datatype.DataType;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManager;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManagerCache;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManagerDAO;

public class DataTypeManagerBusiness implements DataTypeManager {
    private DataTypeManager dao;
    private DataTypeManager cache;

    private static DataTypeManager instance = null;

    public static DataTypeManager getInstance() {
        if (instance==null) {
            instance = new DataTypeManagerBusiness();
        }
        return instance;
    }

    private DataTypeManagerBusiness() {
        this.reload();
    }

    @Override
	public DataType[] getDataType() {
        return cache.getDataType();
    }

    @Override
	public DataType getDataType(int dataTypeID) {
        return cache.getDataType(dataTypeID);
    }

    @Override
	public void reload() {
        cache = new DataTypeManagerCache();
        dao = new DataTypeManagerDAO();
        for (DataType dataType : dao.getDataType()) {
            cache.setDataType(dataType);
        }
    }

    @Override
	public DataType setDataType(DataType dataType) {
        dataType = dao.setDataType(dataType);
        cache.setDataType(dataType);
        return dataType;
    }


    @Override
	public void delete(DataType dataType) {
        dao.delete(dataType);
        cache.delete(dataType);

    }
}
