/**
 * <p>Title: DataTypeManagerCache</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype;

import java.util.Hashtable;
import java.util.Arrays;
import java.util.Comparator;

import com.telepacific.merrt.feedmanager.datatype.DataType;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManager;

public class DataTypeManagerCache implements DataTypeManager {
    private Hashtable<Integer, DataType> dataTypes;

    public DataTypeManagerCache() {
        this.reload();
    }

    @Override
	public DataType[] getDataType() {
        DataType[] rtn = dataTypes.values().toArray(new DataType[dataTypes.size()]);
        Arrays.sort(rtn, new Comparator<DataType>() {
            @Override
			public int compare(DataType o1, DataType o2) {
                return o1.getDataTypeName().compareTo(o2.getDataTypeName());
            }
        });

        return rtn;
    }

    @Override
	public DataType getDataType(int dataTypeID) {
        return dataTypes.get(dataTypeID);
    }

    @Override
	public void reload() {
        dataTypes = new Hashtable<Integer, DataType>();
    }

    @Override
	public DataType setDataType(DataType dataType) {
        dataTypes.put(dataType.getDataTypeID(), dataType);
        return dataType;
    }


    @Override
	public void delete(DataType dataType) {
        dataTypes.remove(dataType.getDataTypeID());

    }
}
