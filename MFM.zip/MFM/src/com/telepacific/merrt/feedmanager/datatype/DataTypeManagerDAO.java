/**
 * <p>Title: DataTypeManagerDAO</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype;

import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.feedmanager.datatype.DataType;
import com.telepacific.merrt.feedmanager.datatype.DataTypeManager;

import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

public class DataTypeManagerDAO implements DataTypeManager {
    public DataTypeManagerDAO() {

    }

    @Override
	public DataType[] getDataType() {
        //System.out.println("########DataTypeManagerDAO.getDataType()########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from DataType as u").list();
        tx.commit();
        DataType[] rtn = (DataType[]) data.toArray(new DataType[data.size()]);
        Arrays.sort(rtn, new Comparator<DataType>() {
            @Override
			public int compare(DataType o1, DataType o2) {
                return o2.getDataTypeName().compareTo(o1.getDataTypeName());
            }
        });
        return rtn;
    }

    @Override
	public DataType getDataType(int dataTypeID) {
        return null;
    }

    @Override
	public void reload() {

    }

    @Override
	public DataType setDataType(DataType dataType) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (dataType.getDataTypeID() <= 0) {
                session.save(dataType);
            } else {
                session.update(dataType);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return dataType;
    }

    @Override
	public void delete(DataType dataType) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(dataType);
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }
}
