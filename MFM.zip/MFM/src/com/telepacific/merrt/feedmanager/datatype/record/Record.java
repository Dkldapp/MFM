/**
 * <p>Title: Record</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record;

public class Record {
    private int recordID;
    private int dataTypeID;
    private String recordName;
    private int formatTypeID;
    private String delimination;
    private boolean dataModule;
    private String description;

    public Record() {

    }

    public boolean isDataModule() {
        return dataModule;
    }

    public void setDataModule(boolean dataModule) {
        this.dataModule = dataModule;
    }

    public int getDataTypeID() {
        return dataTypeID;
    }

    public void setDataTypeID(int dataTypeID) {
        this.dataTypeID = dataTypeID;
    }

    public String getDelimination() {
        return delimination;
    }

    public void setDelimination(String delimination) {
        this.delimination = delimination;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getFormatTypeID() {
        return formatTypeID;
    }

    public void setFormatTypeID(int formatTypeID) {
        this.formatTypeID = formatTypeID;
    }

    public int getRecordID() {
        return recordID;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

    public String getRecordName() {
        return recordName;
    }

    public void setRecordName(String recordName) {
        this.recordName = recordName;
    }
}
