/**
 * <p>Title: RecordManager</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record;

import com.telepacific.merrt.feedmanager.datatype.record.Record;

public interface RecordManager {
    public Record[] getRecord();

    public Record getRecord(int recordID);

    public Record setRecord(Record record);

    public void reload();

    public void delete(Record record);

    public Record[] getRecordByDataTypeID(int dataTypeID);

    public Record getRecordByRecordName(String recordName);
}
