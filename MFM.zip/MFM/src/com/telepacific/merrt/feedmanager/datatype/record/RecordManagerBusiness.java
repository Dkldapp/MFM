/**
 * <p>Title: RecordManagerBusiness</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record;

import com.telepacific.merrt.feedmanager.datatype.record.Record;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManager;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManagerCache;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManagerDAO;

public class RecordManagerBusiness implements RecordManager {
    private RecordManager dao;
    private RecordManager cache;

    private static RecordManager instance = null;

    public static RecordManager getInstance() {
        if (instance==null) {
            instance = new RecordManagerBusiness();
        }
        return instance;
    }
    private RecordManagerBusiness() {
        this.reload();
    }

    @Override
	public void delete(Record record) {
        dao.delete(record);
        cache.delete(record);
    }

    @Override
	public Record[] getRecord() {
        return cache.getRecord();
    }

    @Override
	public Record getRecord(int recordID) {
        return cache.getRecord(recordID);
    }

    @Override
	public void reload() {
        cache = new RecordManagerCache();
        dao = new RecordManagerDAO();
        for (Record record : dao.getRecord()) {
            cache.setRecord(record);
        }
    }

    @Override
	public Record setRecord(Record record) {
        record = dao.setRecord(record);
        cache.setRecord(record);
        return record;
    }

    @Override
	public Record[] getRecordByDataTypeID(int dataTypeID) {
        return cache.getRecordByDataTypeID(dataTypeID);
    }


    @Override
	public Record getRecordByRecordName(String recordName) {
        return cache.getRecordByRecordName(recordName);
    }
}
