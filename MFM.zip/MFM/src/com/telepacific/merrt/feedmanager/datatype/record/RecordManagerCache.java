/**
 * <p>Title: RecordManagerCache</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.ArrayList;

import com.telepacific.merrt.feedmanager.datatype.record.Record;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManager;

public class RecordManagerCache implements RecordManager {
    private Hashtable<Integer, Record> records;
    private Hashtable<String, Record> recordsByRecordName;

    private Hashtable<Integer, ArrayList<Record>> recordsByDataTypeID;

    public RecordManagerCache() {
        this.reload();
    }

    @Override
	public void delete(Record record) {
        records.remove(record.getRecordID());
    }

    @Override
	public Record[] getRecord() {
        Record[] rtn = records.values().toArray(new Record[records.size()]);
        Arrays.sort(rtn, new Comparator<Record>() {
            @Override
			public int compare(Record o1, Record o2) {
                return o1.getRecordName().compareTo(o2.getRecordName());
            }
        });

        return rtn;
    }

    @Override
	public Record getRecord(int recordID) {
        return records.get(recordID);
    }

    @Override
	public void reload() {
        records = new Hashtable<Integer, Record>();
        recordsByRecordName = new Hashtable<String, Record>();
        recordsByDataTypeID = new Hashtable<Integer, ArrayList<Record>>();
    }

    @Override
	public Record setRecord(Record record) {
        records.put(record.getRecordID(), record);
        recordsByRecordName.put(record.getRecordName(), record);
        ArrayList<Record> list;
        if (recordsByDataTypeID.containsKey(record.getDataTypeID())) {
            list = recordsByDataTypeID.get(record.getDataTypeID());
        } else {
            list = new ArrayList<Record>();
        }
        list.add(record);
        recordsByDataTypeID.put(record.getDataTypeID(), list);

        return record;
    }

    @Override
	public Record[] getRecordByDataTypeID(int dataTypeID) {
        Record[] rtn;
        rtn = recordsByDataTypeID.get(dataTypeID).toArray(new Record[recordsByDataTypeID.get(dataTypeID).size()]);
        return rtn;
    }

    @Override
	public Record getRecordByRecordName(String recordName) {
        return recordsByRecordName.get(recordName);
    }
}
