/**
 * <p>Title: RecordManagerDAO</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record;

import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.feedmanager.datatype.record.Record;
import com.telepacific.merrt.feedmanager.datatype.record.RecordManager;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManagerDAO;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

public class RecordManagerDAO implements RecordManager {
    public RecordManagerDAO() {

    }
    Logger log = Logger.getLogger(RecordFieldManagerDAO.class);
    @Override
	public void delete(Record record) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(record);
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }

    @Override
	public Record[] getRecord() {
        log.info("########RecordManagerDAO.getRecord()########");
        List<?> data = new Vector<Object>();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from Record as u").list();
        tx.commit();
        Record[] rtn = (Record[]) data.toArray(new Record[data.size()]);
        Arrays.sort(rtn, new Comparator<Record>() {
            @Override
			public int compare(Record o1, Record o2) {
                return o2.getRecordName().compareTo(o1.getRecordName());
            }
        });
        return rtn;
    }

    @Override
	public Record getRecord(int recordID) {
        return null;
    }

    @Override
	public void reload() {

    }

    @Override
	public Record setRecord(Record record) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (record.getRecordID() <= 0) {
                session.save(record);
            } else {
                session.update(record);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return record;
    }


    @Override
	public Record[] getRecordByDataTypeID(int dataTypeID) {
        return new Record[0];
    }


    @Override
	public Record getRecordByRecordName(String recordName) {
        return null;
    }
}
