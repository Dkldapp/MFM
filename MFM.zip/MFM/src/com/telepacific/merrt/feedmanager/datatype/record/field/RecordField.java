/**
 * <p>Title: RecordField</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record.field;

public class RecordField {
    private int recordFieldID;
    private int recordID;
    private String fieldName;
    private int start;
    private int length;
    private String mapFieldName;
    private int dataType;
    private String selectFieldName;

    public static final int DATA_TYPE_NUMBER = 1;
    public static final int DATA_TYPE_STRING = 2;
    public static final int DATA_TYPE_DATETIME = 3;

    public RecordField() {

    }


    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getMapFieldName() {
        return mapFieldName;
    }

    public void setMapFieldName(String mapFieldName) {
        this.mapFieldName = mapFieldName;
    }

    public int getRecordFieldID() {
        return recordFieldID;
    }

    public void setRecordFieldID(int recordFieldID) {
        this.recordFieldID = recordFieldID;
    }

    public int getRecordID() {
        return recordID;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }


    public int getDataType() {
        return dataType;
    }

    public void setDataType(int dataType) {
        this.dataType = dataType;
    }


    public String getSelectFieldName() {
        return selectFieldName;
    }

    public void setSelectFieldName(String selectFieldName) {
        this.selectFieldName = selectFieldName;
    }
}
