/**
 * <p>Title: RecordFieldManager</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record.field;

import com.telepacific.merrt.feedmanager.datatype.record.field.RecordField;

public interface RecordFieldManager {
    public RecordField[] getRecordField();

    public RecordField getRecordField(int recordFieldID);

    public RecordField setRecordField(RecordField recordField);

    public void reload();

    public void delete(RecordField recordField);

    public RecordField[] getRecordFieldByRecordID(int recordID);

}
