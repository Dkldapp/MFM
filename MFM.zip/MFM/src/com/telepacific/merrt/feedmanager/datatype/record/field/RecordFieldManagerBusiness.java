/**
 * <p>Title: RecordFieldManagerBusiness</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record.field;

import com.telepacific.merrt.feedmanager.datatype.record.field.RecordField;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManager;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManagerBusiness;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManagerCache;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManagerDAO;

public class RecordFieldManagerBusiness implements RecordFieldManager {
    private RecordFieldManager dao;
    private RecordFieldManager cache;

    private static RecordFieldManager instance = null;

    public static RecordFieldManager getInstance() {
        if (instance==null) {
            instance = new RecordFieldManagerBusiness();
        }
        return instance;
    }

    private RecordFieldManagerBusiness() {
        this.reload();
    }


    @Override
	public void delete(RecordField recordField) {
        dao.delete(recordField);
        cache.delete(recordField);
    }

    @Override
	public RecordField[] getRecordField() {
        return cache.getRecordField();
    }

    @Override
	public RecordField getRecordField(int recordFieldID) {
        return cache.getRecordField(recordFieldID);
    }

    @Override
	public void reload() {
        cache = new RecordFieldManagerCache();
        dao = new RecordFieldManagerDAO();
        for (RecordField recordField : dao.getRecordField()) {
            cache.setRecordField(recordField);
        }
    }

    @Override
	public RecordField setRecordField(RecordField recordField) {
        recordField = dao.setRecordField(recordField);
        cache.setRecordField(recordField);
        return recordField;
    }


    @Override
	public RecordField[] getRecordFieldByRecordID(int recordID) {
        return cache.getRecordFieldByRecordID(recordID);
    }
}
