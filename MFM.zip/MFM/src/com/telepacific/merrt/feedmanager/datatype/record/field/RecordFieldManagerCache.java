/**
 * <p>Title: RecordFieldManagerCache</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record.field;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;

import com.telepacific.merrt.feedmanager.datatype.record.field.RecordField;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManager;

public class RecordFieldManagerCache implements RecordFieldManager {
    private Hashtable<Integer, RecordField> recordFields;
    private Hashtable<Integer, ArrayList<RecordField>> recordFieldsByRecordID;

    public RecordFieldManagerCache() {
        this.reload();
    }

    @Override
	public void delete(RecordField recordField) {
        recordFields.remove(recordField.getRecordFieldID());
    }

    @Override
	public RecordField[] getRecordField() {
        RecordField[] rtn = recordFields.values().toArray(new RecordField[recordFields.size()]);
        Arrays.sort(rtn, new Comparator<RecordField>() {
            @Override
			public int compare(RecordField o1, RecordField o2) {
                return new Integer(o1.getStart()).compareTo(o2.getStart());
            }
        });

        return rtn;
    }

    @Override
	public RecordField getRecordField(int recordFieldID) {
        return recordFields.get(recordFieldID);
    }

    @Override
	public void reload() {
        recordFields = new Hashtable<Integer, RecordField>();
        recordFieldsByRecordID = new Hashtable<Integer, ArrayList<RecordField>>();
    }

    @Override
	public RecordField setRecordField(RecordField recordField) {
        recordFields.put(recordField.getRecordFieldID(), recordField);
        ArrayList<RecordField> list;
        if (recordFieldsByRecordID.containsKey(recordField.getRecordID())) {
            list = recordFieldsByRecordID.get(recordField.getRecordID());
        } else {
            list = new ArrayList<RecordField>();
        }
        list.add(recordField);
        recordFieldsByRecordID.put(recordField.getRecordID(), list);

        return recordField;
    }

    private Hashtable<Integer, RecordField[]> cached = new Hashtable<Integer, RecordField[]>();

    @Override
	public RecordField[] getRecordFieldByRecordID(int recordID) {
        RecordField[] rtn;
        if (cached.containsKey(recordID)) {
            rtn = cached.get(recordID);
        } else {
            rtn = recordFieldsByRecordID.get(recordID).toArray(new RecordField[recordFieldsByRecordID.get(recordID).size()]);
            Arrays.sort(rtn, new Comparator<RecordField>() {
                @Override
				public int compare(RecordField o1, RecordField o2) {
                    return new Integer(o1.getStart()).compareTo(o2.getStart());
                }
            });
            cached.put(recordID, rtn);
        }
        return rtn;
    }
}
