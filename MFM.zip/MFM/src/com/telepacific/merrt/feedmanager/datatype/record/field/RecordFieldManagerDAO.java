/**
 * <p>Title: RecordFieldManagerDAO</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.datatype.record.field;

import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordField;
import com.telepacific.merrt.feedmanager.datatype.record.field.RecordFieldManager;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

public class RecordFieldManagerDAO implements RecordFieldManager {
    public RecordFieldManagerDAO() {

    }
    Logger log = Logger.getLogger(RecordFieldManagerDAO.class);
    @Override
	public void delete(RecordField recordField) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(recordField);
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }

    @Override
	public RecordField[] getRecordField() {
        log.info("########RecordFieldManagerDAO.getRecordField()########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from RecordField as u").list();
        tx.commit();
        RecordField[] rtn = (RecordField[]) data.toArray(new RecordField[data.size()]);
        Arrays.sort(rtn, new Comparator<RecordField>() {
            @Override
			public int compare(RecordField o1, RecordField o2) {
                return new Integer(o2.getStart()).compareTo(o1.getStart());
            }
        });
        return rtn;
    }

    @Override
	public RecordField getRecordField(int recordFieldID) {
        return null;
    }

    @Override
	public void reload() {

    }

    @Override
	public RecordField setRecordField(RecordField recordField) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (recordField.getRecordFieldID() <= 0) {
                session.save(recordField);
            } else {
                session.update(recordField);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return recordField;
    }


    @Override
	public RecordField[] getRecordFieldByRecordID(int recordID) {
        return new RecordField[0];
    }
}
