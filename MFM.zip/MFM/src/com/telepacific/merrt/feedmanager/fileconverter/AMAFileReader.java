/**
 * <p>Title: AMAFileReader</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.fileconverter;

import com.telepacific.merrt.feedmanager.usagefile.UsageFile;

import java.io.File;
import java.util.Date;

public class AMAFileReader {

    public static File ConvertToTPEMI(File inFile, File outFile) {
        if (!inFile.exists()) {
            return null;
        }
        Date processStart;
        Date processEnd;
        processStart = new Date();


        UsageFile usageFile;
//        usageFile = new UsageFile(inFile, outFile, AMAProperties.getInstance().getAMA());

        return outFile;
    }

    public static void main(String[] args) {

    }
}
