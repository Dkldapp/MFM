/**
 * <p>Title: AppComponent</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.fileconverter;

public interface AppComponent {

}
