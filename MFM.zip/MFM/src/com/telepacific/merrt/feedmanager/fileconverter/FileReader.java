/**
 * <p>Title: FileReader</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.fileconverter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.telepacific.merrt.feedmanager.usagefile.ConvertedRecord;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;
import com.telepacific.merrt.feedmanager.usagefile.UsageModule;
import com.telepacific.merrt.feedmanager.usagefile.UsageRecord;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureField;

public class FileReader {
    private UsageFileProperties properties;
    private ArrayList records;
    private File file;
    private File outFile;
    Logger log = Logger.getLogger(FileReader.class);
    public FileReader(File file, File outFile, UsageFileProperties properties) {
        this.file = file;
        this.outFile = outFile;
        this.properties = properties;
        init();
    }

    public ArrayList getConvertedRecord() {
        return this.records;
    }

    private void init() {


    }

    public static ConvertedRecord getRecordConverted(UsageRecord record, UsageFileProperties properties) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS");

        //System.out.println();
        String strOrigTGN;
        String strTermTGN;
        boolean modSwitch = false;

        long origNumber = 0;
        long termNumber = 0;
        String recordTypeID;
        Integer callType;
        Date connectDateTime = null;
        Date carrierDateTime = null;
        long connectDuration = 0;
        long carrierDuration;
        int origTGN;
        int termTGN;
        int companyCode;
        int callDirection;
        boolean termPartyOffHook;
        String recordText;

        String connectTime;
        StringBuffer strRecord;


        strOrigTGN = null;
        strTermTGN = null;
        modSwitch = false;
//        System.out.println(usageFile.getRecords()[i].getRecordText());

        //strConnectDate = usageFile.getRecords()[i].getFieldValue("CONNECT_DATE");
        //strConnectTime = usageFile.getRecords()[i].getFieldValue("CONNECT_TIME");
        UsageModule[] usageModules = record.getUsageModule();
        UsageModule usageModule;
        UsageFileStructureField field;

//            System.out.println(usageModules);
        int modCount = 0;
        for (int ii = 0; ii < usageModules.length; ii++) {
            usageModule = usageModules[ii];
            if (usageModule.getModuleKey().equals("104")) {
                for (int iii = 0; iii < usageModule.getField().length; iii++) {
                    field = usageModule.getField()[iii];
                    //System.out.println(field.getFieldName() + " - " + field.getFieldValue());
                }
                if (!modSwitch) {
                    strOrigTGN = usageModule.getField()[0].getFieldValue();
                    strOrigTGN = strOrigTGN.substring(1, 5);
                    modSwitch = true;
                    modCount ++;
                } else {
                    strTermTGN = usageModule.getField()[0].getFieldValue();
                    strTermTGN = strTermTGN.substring(1, 5);
                    modCount ++;
                }
            }
        }
//        if (properties.getFileStructureID()==1) {
//            String tmpTermTGN = strTermTGN;
//            String tmpOrigTGN = strOrigTGN;
//            if (modCount>1) {
//               strTermTGN = tmpOrigTGN;
//               strOrigTGN = tmpTermTGN;
//            }
//        }
        String data;
        strRecord = new StringBuffer();
//                System.out.println(usageFile.getRecords()[i].getRecordText());

        if (record.getFieldValue("ORIG_NPA") != null || record.getFieldValue("ORIG_NUMBER") != null) {
            try {
                if (record.getFieldValue("ORIG_NPA") != null) {
                    origNumber = Long.parseLong(record.getFieldValue("ORIG_NPA").replaceAll("c", "") + record.getFieldValue("ORIG_NUMBER").replaceAll("c", ""));
                } else {
                    origNumber = Long.parseLong(record.getFieldValue("ORIG_NUMBER").replaceAll("c", ""));
                }
                strRecord.append(origNumber).append(",");
            } catch (Exception error) {
                strRecord.append("").append(",");
            }
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("CHARGE_NUMBER") != null) {
            data = record.getFieldValue("CHARGE_NUMBER").replaceAll("c", "");
            long ldata;
            try {
                ldata = Long.parseLong(data);
            } catch (Exception error) {
                ldata = 0;
            }
            strRecord.append(ldata).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("DIALED_NUMBER") != null) {
            data = record.getFieldValue("DIALED_NUMBER").replaceAll("c", "");
            long ldata;
            try {
                ldata = Long.parseLong(data);
            } catch (Exception error) {
                ldata = 0;
            }
            strRecord.append(ldata).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("TERM_NPA") != null||record.getFieldValue("TERM_NUMBER")!=null) {
            try {
                if (record.getFieldValue("TERM_NPA") != null) {
                    termNumber = Long.parseLong(record.getFieldValue("TERM_NPA").replaceAll("c", "") + record.getFieldValue("TERM_NUMBER").replaceAll("c", ""));
                } else {
                    termNumber = Long.parseLong(record.getFieldValue("TERM_NUMBER").replaceAll("c", ""));
                }
                strRecord.append(termNumber).append(",");
            } catch (Exception error) {
                strRecord.append("").append(",");
            }
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("RECORD_TYPE") != null) {
            recordTypeID = record.getFieldValue("RECORD_TYPE").replaceAll("c", "");
            int iRecordTypeID;
            try {
                iRecordTypeID = Integer.parseInt(recordTypeID);
            } catch (Exception error) {
                iRecordTypeID = 1;
            }
            strRecord.append(iRecordTypeID).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("CALL_TYPE") != null) {
            callType = Integer.parseInt(record.getFieldValue("CALL_TYPE").replaceAll("c", ""));
            strRecord.append(callType.intValue()).append(",");
        } else {
            callType = null;
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("CONNECT_DATE") != null) {
            if (record.getFieldValue("CONNECT_TIME") != null) {
                connectTime = record.getFieldValue("CONNECT_TIME").replaceAll("c", "");
            } else {
                connectTime = "0000000";
            }

            connectDateTime = convertUsageDate(record.getFieldValue("CONNECT_DATE").replaceAll("c", ""), connectTime, properties);
            strRecord.append(format.format(connectDateTime)).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("CARRIER_CONNECT_DATE") != null) {
            if (record.getFieldValue("CARRIER_CONNECT_TIME") != null) {
                connectTime = record.getFieldValue("CARRIER_CONNECT_TIME").replaceAll("c", "");
            } else {
                connectTime = "0000000";
            }
            carrierDateTime = convertUsageDate(record.getFieldValue("CARRIER_CONNECT_DATE").replaceAll("c", ""), connectTime, properties);
            strRecord.append(format.format(carrierDateTime)).append(",");
        } else {
            if (record.getFieldValue("CONNECT_DATE") != null) {
                if (record.getFieldValue("CONNECT_TIME") != null) {
                    connectTime = record.getFieldValue("CONNECT_TIME").replaceAll("c", "");
                } else {
                    connectTime = "0000000";
                }

                connectDateTime = convertUsageDate(record.getFieldValue("CONNECT_DATE").replaceAll("c", ""), connectTime, properties);
                strRecord.append(format.format(connectDateTime)).append(",");
            } else {
                strRecord.append("").append(",");
            }
        }

        if (record.getFieldValue("DURATION") != null) {
            connectDuration = convertUsageMilliseconds(record.getFieldValue("DURATION").replaceAll("c", ""), properties);
            strRecord.append(connectDuration).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("CARRIER_DURATION") != null) {
            carrierDuration = convertUsageMilliseconds(record.getFieldValue("CARRIER_DURATION").replaceAll("c", ""), properties);
            strRecord.append(carrierDuration).append(",");
        } else {
            if (connectDuration!=0) {
                strRecord.append(connectDuration).append(",");
            } else {
                strRecord.append("").append(",");
            }
        }

        Hashtable<Integer, Boolean> swapTGNCallType = new Hashtable<Integer, Boolean>();
        swapTGNCallType.put(new Integer(1), true);
        swapTGNCallType.put(new Integer(6), true);
        swapTGNCallType.put(new Integer(9), true);
        swapTGNCallType.put(new Integer(33), true);
        swapTGNCallType.put(new Integer(47), true);
        swapTGNCallType.put(new Integer(60), true);
        swapTGNCallType.put(new Integer(74), true);
        swapTGNCallType.put(new Integer(90), true);
        swapTGNCallType.put(new Integer(110), true);
        swapTGNCallType.put(new Integer(141), true);
        swapTGNCallType.put(new Integer(142), true);
        swapTGNCallType.put(new Integer(263), true);
        swapTGNCallType.put(new Integer(320), true);
        swapTGNCallType.put(new Integer(714), true);

        if (strOrigTGN!=null && strTermTGN==null) {
            if (swapTGNCallType.containsKey(callType)) {
                strTermTGN = strOrigTGN;
                strOrigTGN = null;
            }
        }

        if (strOrigTGN != null) {
            origTGN = Integer.parseInt(strOrigTGN.replaceAll("c", ""));
            strRecord.append(origTGN).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (strTermTGN != null) {
            termTGN = Integer.parseInt(strTermTGN.replaceAll("c", ""));
            strRecord.append(termTGN).append(",");
        } else {
            strRecord.append("").append(",");
        }

        if (record.getFieldValue("COMPANY_CODE") != null) {
            companyCode = Integer.parseInt(record.getFieldValue("COMPANY_CODE").replaceAll("c", ""));
            strRecord.append(companyCode).append(",");
        } else {
            strRecord.append("").append(",");
        }

        callDirection = 0;
        strRecord.append(callDirection).append(",");

        if (record.getFieldValue("CALL_COMPLETION") != null) {
            termPartyOffHook = Boolean.getBoolean(record.getFieldValue("CALL_COMPLETION").replaceAll("c", ""));
            if (termPartyOffHook) {
                strRecord.append("1").append(",");
            } else {
                strRecord.append("0").append(",");
            }
        } else {
            strRecord.append("").append(",");
        }
        strRecord.append(","); // Orig Point Code
        strRecord.append(","); //Term Point Code
        recordText = record.getRecordText().toString();

        strRecord.append("").append(","); //JIP
        strRecord.append("").append(","); //LRN
        strRecord.append("").append(","); //Circuit ID Code
        strRecord.append("").append(","); //CABS RATE
        strRecord.append("").append(","); //BILLING RATE
        strRecord.append("").append(","); //RESERVED_1
        strRecord.append("").append(","); //RESERVED_2
        strRecord.append(recordText);
        ConvertedRecord convertedRecord = new ConvertedRecord();
        convertedRecord.setConvertedRecord(strRecord.toString());
        convertedRecord.setRecordDate(carrierDateTime!=null ? carrierDateTime : connectDateTime);
        return convertedRecord;
    }
    private static long convertUsageMilliseconds(String duration, UsageFileProperties properties) {
        long l = 0;
        int mi;
        int ss;
        int ts;


        switch (properties.getDurationType()) {
            case UsageFileProperties.DURATION_TYPE_IN_MI_SS_ML :
                String smi = duration.substring(0, 6);
                String sss = duration.substring(6, 8);
                String sts = duration.substring(8, 9);

                mi = Integer.parseInt(smi) * 60000;
                ss = Integer.parseInt(sss) * 1000;
                ts = Integer.parseInt(sts) * 100;
                l = mi + ss + ts;
                break;
            case UsageFileProperties.DURATION_TYPE_IN_SECONDS :
                ss = Integer.parseInt(duration) * 1000;
                l = ss;
                break;
        }
        return l;
    }

    private static Date convertUsageDate(String date, String time, UsageFileProperties properties) {
        String syy = date.substring(properties.getYYYYStart(), properties.getYYYYStart() + properties.getYYYYLength());
        String smm = date.substring(properties.getMMStart(), properties.getMMStart() + properties.getMMLength());
        String sdd = date.substring(properties.getDDStart(), properties.getDDStart() + properties.getDDLength());

        String shh = time.substring(properties.getHHStart(), properties.getHHStart() + properties.getHHLength());
        String smi = time.substring(properties.getMIStart(), properties.getMIStart() + properties.getMILength());
        String sss = time.substring(properties.getSSStart(), properties.getSSStart() + properties.getSSLength());
        String sml = "";
        if (properties.getMlStart() != 0) {
            sml = time.substring(properties.getMlStart(), properties.getMlStart() + properties.getMlLength());
        }
        int yy = Integer.parseInt(syy) + properties.getYYYYPlus();
        int mm = Integer.parseInt(smm) - 1;
        int dd = Integer.parseInt(sdd);
        int hh = Integer.parseInt(shh);
        int mi = Integer.parseInt(smi);
        int ss = Integer.parseInt(sss);
        int ml = 0;
        if (properties.getMlStart() != 0) {
            ml = Integer.parseInt(sml);
        }
        Calendar cal = Calendar.getInstance();
        cal.set(yy, mm, dd, hh, mi, ss);
        if (properties.getMlStart()!=0) {
            cal.set(Calendar.MILLISECOND, ml * 100);
        } else {
            cal.set(Calendar.MILLISECOND, 0);
        }

        return new Date(cal.getTimeInMillis());
    }

    public File createUsageFile2(File file) {

        BufferedWriter fileWriter = null;

        try {
            fileWriter = new BufferedWriter(new FileWriter(file, false));
            for (int i = 0; i < records.size(); i++) {
                fileWriter.write((String) records.get(i));
                fileWriter.newLine();
            }
            fileWriter.flush();
            fileWriter.close();
        } catch(Exception error) {
            log.error(error);
        }
        return file;
    }

    public static void main(String[] args) {
    }
}
