/**
 * <p>Title: FixedLengthFileReader</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.fileconverter;

import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;

import java.io.File;
import java.util.Date;

public class FixedLengthFileReader {
    public static File ConvertToTPEMI(File inFile, File outFile, UsageFileProperties properties) {
        if (!inFile.exists()) {
            return null;
        }
        Date processStart;
        Date processEnd;
        processStart = new Date();


        //UsageFile usageFile = new UsageFile(inFile, outFile, properties);

        return outFile;
    }
}
