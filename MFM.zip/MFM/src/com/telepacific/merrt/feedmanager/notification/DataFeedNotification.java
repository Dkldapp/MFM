/**
 * <p>Title: DataFeedNotification</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.notification;

import java.util.Date;

public class DataFeedNotification {
    private Integer dataFeedNotificationID;
    private Integer dataFeedID;
    private Date dateLastFileReceived;
    private Date dateLatestUsage;
    private String email;
    private long thresholdMinutes;
    private String lastFileName;
    private Date dateLastFileCompleted;
    private Long queued;
    private Integer status;

    public DataFeedNotification() {

    }

    public Integer getDataFeedID() {
        return dataFeedID;
    }

    public void setDataFeedID(Integer dataFeedID) {
        this.dataFeedID = dataFeedID;
    }

    public Integer getDataFeedNotificationID() {
        return dataFeedNotificationID;
    }

    public void setDataFeedNotificationID(int dataFeedNotificationID) {
        this.dataFeedNotificationID = dataFeedNotificationID;
    }

    public Date getDateLastFileReceived() {
        return dateLastFileReceived;
    }

    public void setDateLastFileReceived(Date dateLastFileReceived) {
        this.dateLastFileReceived = dateLastFileReceived;
    }

    public Date getDateLatestUsage() {
        return dateLatestUsage;
    }

    public void setDateLatestUsage(Date dateLatestUsage) {
        this.dateLatestUsage = dateLatestUsage;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getThresholdMinutes() {
        return thresholdMinutes;
    }

    public void setThresholdMinutes(long thresholdMinutes) {
        this.thresholdMinutes = thresholdMinutes;
    }

    public String getLastFileName() {
        return lastFileName;
    }

    public void setLastFileName(String lastFileName) {
        this.lastFileName = lastFileName;
    }


    public Date getDateLastFileCompleted() {
        return dateLastFileCompleted;
    }

    public void setDateLastFileCompleted(Date dateLastFileCompleted) {
        this.dateLastFileCompleted = dateLastFileCompleted;
    }

    public Long getQueued() {
        return queued;
    }

    public void setQueued(Long queued) {
        this.queued = queued;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        if (status!=null) {
            this.status = new Integer(status);
        }
    }
}
