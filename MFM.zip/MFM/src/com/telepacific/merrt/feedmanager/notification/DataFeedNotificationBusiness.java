/**
 * <p>Title: DataFeedNotificationBusiness</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.notification;

import com.telepacific.merrt.feedmanager.notification.DataFeedNotification;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationBusiness;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationCache;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationDAO;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationManager;

public class DataFeedNotificationBusiness implements DataFeedNotificationManager {
    private DataFeedNotificationManager dao;
    private DataFeedNotificationManager cache;

    private static DataFeedNotificationManager instance = null;

    public synchronized static DataFeedNotificationManager getInstance() {
        if (instance == null) {
            instance = new DataFeedNotificationBusiness();
        }
        return instance;
    }

    private DataFeedNotificationBusiness() {
        this.reload();
    }

    @Override
	public DataFeedNotification getDataFeedNotificationByDataFeedID(int dataFeedID) {
        return cache.getDataFeedNotificationByDataFeedID(dataFeedID);
    }

    @Override
	public DataFeedNotification[] getDataFeedNotification() {
        return cache.getDataFeedNotification();
    }

    @Override
	public DataFeedNotification getDataFeedNotification(int dataFeedNotificationID) {
        return dao.getDataFeedNotification(dataFeedNotificationID);
    }


    @Override
	public void reload() {
        cache = new DataFeedNotificationCache();
        dao = new DataFeedNotificationDAO();
//                SystemManager.getInstance().println("Reloading Data Feed Notification...");
        for (DataFeedNotification dataFeedNotification : dao.getDataFeedNotification()) {
            cache.setDataFeedNotification(dataFeedNotification);
        }
//                SystemManager.getInstance().println("Reloading Data Feed Notification...done");
    }

    private boolean updating = false;

    @Override
	public void update() {
        if (updating) {
            return;
        }
        updating = true;
        Thread thread = (new Thread() {
            @Override
			public void run() {
//                SystemManager.getInstance().println("Updating Data Feed Notification...");
                //DataFeedNotificationCache tmpCache = new DataFeedNotificationCache();
                for (DataFeedNotification dataFeedNotification : dao.getDataFeedNotification()) {
                    cache.setDataFeedNotification(dataFeedNotification);
                }
                //cache = tmpCache;
//                SystemManager.getInstance().println("Updating Data Feed Notification...done");
                updating = false;
            }
        });
        thread.start();

//        for (DataFeedNotification dataFeedNotification : dao.getDataFeedNotification()) {
//            tmpCache.setDataFeedNotification(dataFeedNotification);
//        }
    }

    @Override
	public DataFeedNotification setDataFeedNotification(DataFeedNotification dataFeedNotification) {

        dataFeedNotification = dao.setDataFeedNotification(dataFeedNotification);
        cache.setDataFeedNotification(dataFeedNotification);
        return dataFeedNotification;
    }

    @Override
	public void delete(DataFeedNotification dataFeedNotification) {
        dao.delete(dataFeedNotification);
        cache.delete(dataFeedNotification);
    }
}
