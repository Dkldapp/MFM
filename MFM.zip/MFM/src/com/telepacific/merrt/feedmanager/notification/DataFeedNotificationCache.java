/**
 * <p>Title: DataFeedNotificationCache</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.notification;

import com.telepacific.merrt.feedmanager.datafeed.DataFeedManager;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotification;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationManager;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;

public class DataFeedNotificationCache implements DataFeedNotificationManager {
    private Hashtable<Integer, DataFeedNotification> dataFeedNotifications;
    private Hashtable<Integer, DataFeedNotification> dataFeedNotificationByDataFeedIDs;
    DataFeedManager dataFeedManager;

    public DataFeedNotificationCache() {
        this.reload();
        dataFeedManager = DataFeedManager.getInstance();
    }

    @Override
	public DataFeedNotification[] getDataFeedNotification() {

        DataFeedNotification[] rtn = dataFeedNotifications.values().toArray(new DataFeedNotification[dataFeedNotifications.size()]);
        Arrays.sort(rtn, new Comparator<DataFeedNotification>() {
            @Override
			public int compare(DataFeedNotification o1, DataFeedNotification o2) {
                if (o1 == null || o1.getDataFeedID() == null || dataFeedManager.getDataFeed(o1.getDataFeedID()) == null) {
                    return 1;
                }
                if (o2 == null || o2.getDataFeedID() == null || dataFeedManager.getDataFeed(o2.getDataFeedID())==null) {
                    return 0;
                }
                return dataFeedManager.getDataFeed(o1.getDataFeedID()).getDisplayName().compareTo(dataFeedManager.getDataFeed(o2.getDataFeedID()).getDisplayName());
            }
        });
        return rtn;
    }

    @Override
	public DataFeedNotification getDataFeedNotificationByDataFeedID(int dataFeedID) {
        synchronized (dataFeedNotificationByDataFeedIDs) {
            return dataFeedNotificationByDataFeedIDs.get(dataFeedID);
        }
    }

    @Override
	public DataFeedNotification getDataFeedNotification(int dataFeedNotificationID) {
        return dataFeedNotifications.get(dataFeedNotificationID);
    }

    @Override
	public void reload() {
        dataFeedNotifications = new Hashtable<Integer, DataFeedNotification>();
        dataFeedNotificationByDataFeedIDs = new Hashtable<Integer, DataFeedNotification>();
    }

    @Override
	public void update() {

    }

    @Override
	public synchronized DataFeedNotification setDataFeedNotification(DataFeedNotification dataFeedNotification) {
        if (dataFeedNotifications.containsKey(dataFeedNotification.getDataFeedNotificationID())) {
            synchronized (dataFeedNotifications) {
                dataFeedNotifications.remove(dataFeedNotification.getDataFeedNotificationID());
                dataFeedNotificationByDataFeedIDs.remove(dataFeedNotification.getDataFeedID());
            }
        }
        synchronized (dataFeedNotifications) {
            dataFeedNotifications.put(dataFeedNotification.getDataFeedNotificationID(), dataFeedNotification);
            dataFeedNotificationByDataFeedIDs.put(dataFeedNotification.getDataFeedID(), dataFeedNotification);
        }


        return dataFeedNotification;
    }


    @Override
	public void delete(DataFeedNotification dataFeedNotification) {
        dataFeedNotifications.remove(dataFeedNotification.getDataFeedNotificationID());
        dataFeedNotifications.remove(dataFeedNotification.getDataFeedID());

    }
}
