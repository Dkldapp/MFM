/**
 * <p>Title: DataFeedNotificationDAO</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.notification;

import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotification;
import com.telepacific.merrt.feedmanager.notification.DataFeedNotificationManager;

import org.apache.log4j.Logger;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.*;

public class DataFeedNotificationDAO implements DataFeedNotificationManager {
	
	Logger log = Logger.getLogger("DataFeedNotificationDAO");
	
	public DataFeedNotificationDAO() {

    }

    
	public DataFeedNotification[] getDataFeedNotification() {
    	
    	DataFeedNotification[] rtn = null;
    	try{
	        List <DataFeedNotification> data = new Vector<DataFeedNotification>();
	        Transaction tx = null;
	        Session session = InitSessionFactory.getInstance().getCurrentSession();
	        tx = session.beginTransaction();
	
	        data = session.createQuery("select u from DataFeedNotification as u").list();
	        tx.commit();
	        rtn = (DataFeedNotification[]) data.toArray(new DataFeedNotification[data.size()]);
	        Arrays.sort(rtn, new Comparator<DataFeedNotification>() {
	            @Override
				public int compare(DataFeedNotification o1, DataFeedNotification o2) {
	                return new Integer(o2.getDataFeedID()).compareTo(o1.getDataFeedID());
	            }
	        });
    	}catch(Exception e){
    		log.error(e.toString());
    	}
    	
        return rtn;
    }

    
	public DataFeedNotification getDataFeedNotificationByDataFeedID(int dataFeedID) {
		
		DataFeedNotification[] rtn = null;
		try {
	        
	        List <DataFeedNotification> data = new Vector<DataFeedNotification>();
	        Transaction tx = null;
	        Session session = InitSessionFactory.getInstance().getCurrentSession();
	        tx = session.beginTransaction();
	        data = session.createQuery("select u from DataFeedNotification as u where dataFeedID='" + dataFeedID + "'").list();
	        tx.commit();
	        rtn = (DataFeedNotification[]) data.toArray(new DataFeedNotification[data.size()]);
	        Arrays.sort(rtn, new Comparator<DataFeedNotification>() {
	            @Override
				public int compare(DataFeedNotification o1, DataFeedNotification o2) {
	                return new Integer(o2.getDataFeedID()).compareTo(o1.getDataFeedID());
	            }
	        });
		}catch(Exception e){
			log.error(e.toString());
		}
        return rtn[0];
    }

    
	public DataFeedNotification getDataFeedNotification(int dataFeedNotificationID) {

		DataFeedNotification[] rtn = null;
		try{
	        List<DataFeedNotification> data = new Vector<DataFeedNotification>();
	        Transaction tx = null;
	        Session session = InitSessionFactory.getInstance().getCurrentSession();
	        tx = session.beginTransaction();
	        data = session.createQuery("select u from DataFeedNotification as u where dataFeedNotificationID='" + dataFeedNotificationID + "'").list();
	        tx.commit();
	        rtn = (DataFeedNotification[]) data.toArray(new DataFeedNotification[data.size()]);
	        Arrays.sort(rtn, new Comparator<DataFeedNotification>() {
	            @Override
				public int compare(DataFeedNotification o1, DataFeedNotification o2) {
	                return new Integer(o2.getDataFeedID()).compareTo(o1.getDataFeedID());
	            }
	        });
		}catch(Exception e){
			log.error(e.toString());
		}
        return rtn[0];
    }
    
	public DataFeedNotification setDataFeedNotification(DataFeedNotification dataFeedNotification) {
    	
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (dataFeedNotification.getDataFeedNotificationID() <= 0) {

                session.save(dataFeedNotification);
            } else {
                session.update(dataFeedNotification);
            }
            tx.commit();
        } catch (Exception error) {
            log.error(error.toString());
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return dataFeedNotification;
    }
    
	public void delete(DataFeedNotification dataFeedNotification) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(dataFeedNotification);
            tx.commit();
        } catch (Exception error) {
        	log.error(error.toString());
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }
	
	public void reload(){
		
	}

    public void update(){
    	
    }

}


