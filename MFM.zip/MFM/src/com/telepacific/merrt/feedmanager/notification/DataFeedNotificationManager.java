/**
 * <p>Title: DataFeedNotificationManager</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.notification;

import com.telepacific.merrt.feedmanager.notification.DataFeedNotification;

public interface DataFeedNotificationManager {
    public DataFeedNotification[] getDataFeedNotification();

    public DataFeedNotification getDataFeedNotification(int dataFeedNotificationID);

    public DataFeedNotification getDataFeedNotificationByDataFeedID(int dataFeedID);

    public DataFeedNotification setDataFeedNotification(DataFeedNotification dataFeedNotification);

    public void reload();

    public void update();

    public void delete(DataFeedNotification dataFeedNotification);

}
