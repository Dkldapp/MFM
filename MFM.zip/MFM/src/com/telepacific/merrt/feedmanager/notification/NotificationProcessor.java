/**
 * <p>Title: NotificationProcessor</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.notification;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;



import com.telepacific.merrt.config.EmailSender;
import com.telepacific.merrt.config.SystemManager;
import com.telepacific.merrt.feedmanager.datafeed.DataFeed;
import com.telepacific.merrt.feedmanager.datafeed.DataFeedManager;
import com.telepacific.merrt.feedmanager.dataprocessor.DataProcessorThread;
import com.telepacific.merrt.querymanager.query.Query;



public class NotificationProcessor {
    private static NotificationProcessor instance = null;

    public static NotificationProcessor getInstance() {
        if (instance == null) {
            instance = new NotificationProcessor();
        }
        return instance;
    }

    public static final int STATUS_STOPPED = 0;
    public static final int STATUS_IDLE = 1;
    public static final int STATUS_PROCESSING = 2;
    public static final int STATUS_STOPPING = 3;

    private Thread thread;
    private boolean doRun = false;
    private boolean running = false;
    private int status = STATUS_STOPPED;

    private DataFeedNotificationManager dataFeedNotificationManager;
    private DataFeedManager dataFeedManager;

    public NotificationProcessor() {
        thread = null;
        dataFeedNotificationManager = DataFeedNotificationBusiness.getInstance();
        dataFeedManager = DataFeedManager.getInstance();

    }


    public void startProcess() {
        if (running) {
            return;
        }
        status = STATUS_IDLE;
        doRun = true;
        Date dateStart;
        Date dateEnd;

        thread = (new Thread() {
            @Override
			public void run() {
                SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aaa");
                running = true;
                Query query = null;
                String qry;
                Statement stmt;
                ResultSet rs;
                boolean reindex = false;
                boolean tableExists = false;
                DataProcessorThread thread;
                boolean bypassreindex = false;
                DataFeedNotification[] dataFeedNotifications;
                Calendar cal = Calendar.getInstance();
                long date_last_received;
                long date_threshold;
                DataFeed dataFeed;
                String msg_dataFeeds;
                Hashtable<String, ArrayList<String>> emailed;
                String[] emailaddrs;
                ArrayList<String> msgs;
                String email_msg;
                long delay_duration;
                long delay_duration_days;
                long delay_duration_hh;
                long delay_duration_mi;
                long delay_duration_ss;
                String delay_msg;

                while (doRun) {
                    status = STATUS_IDLE;
                    dataFeedNotificationManager.reload();
                    dataFeedNotifications = dataFeedNotificationManager.getDataFeedNotification();
//                    SystemManager.getInstance().println("not size: " + dataFeedNotifications.length );
                    msg_dataFeeds = "";
                    emailed = new Hashtable<String, ArrayList<String>>();
                    for (DataFeedNotification dataFeedNotification : dataFeedNotifications) {
                        if (dataFeedNotification.getEmail()!=null&&dataFeedNotification.getThresholdMinutes()>0) {
                            cal.setTimeInMillis(new Date().getTime());
                            date_threshold = cal.getTimeInMillis();
                            date_threshold = date_threshold - ((dataFeedNotification.getThresholdMinutes() * 60) * 1000);

                            cal.setTimeInMillis(dataFeedNotification.getDateLastFileReceived().getTime());
                            date_last_received = cal.getTimeInMillis();
                            delay_duration = new Date().getTime() - date_last_received;
                            delay_duration_ss = delay_duration / 1000; //seconds
                            delay_duration_mi = (delay_duration / 1000) / 60; //minutes
                            delay_duration_hh = ((delay_duration / 1000) / 60) / 60; //hours
                            delay_duration_days = (((delay_duration / 1000) / 60) / 60) / 24; //days

                            //                        SystemManager.getInstance().println(new Date(date_last_received) + " - " + new Date(date_threshold));
                            if (date_last_received<date_threshold) {
                                emailaddrs = dataFeedNotification.getEmail().split(";");
                                dataFeed = dataFeedManager.getDataFeed(dataFeedNotification.getDataFeedID());
                                for (String email : emailaddrs) {
                                    if (emailed.containsKey(email)) {
                                        msgs = emailed.get(email);
                                    } else {
                                        msgs = new ArrayList<String>();
                                    }
                                    if (delay_duration_mi<120) {
                                        delay_msg = delay_duration_mi + " minutes ago";
                                    } else {
                                        if (delay_duration_hh<48) {
                                            if (delay_duration_hh > 1) {
                                                delay_msg = delay_duration_hh + " hours ago";
                                            } else {
                                                delay_msg = delay_duration_hh + " hour ago";
                                            }
                                        } else {
                                            if (delay_duration_days > 1) {
                                                delay_msg = delay_duration_days + " days ago";
                                            } else {
                                                delay_msg = delay_duration_days + " day ago";
                                            }
                                        }
                                    }
                                    msgs.add(dataFeed.getDisplayName() + ", no file received since " + format.format(dataFeedNotification.getDateLastFileReceived()) + ", " + delay_msg + ".");
                                    emailed.put(email, msgs);
                                }
  //                              SystemManager.getInstance().println("Notify " + dataFeedNotification.getDataFeedID() + " - " + dataFeedNotification.getDateLastFileReceived());
//                                msg_dataFeeds = dataFeed.getDataFeedName();
                            }
                        }
                    }

                    for (String email : emailed.keySet()) {
                        msgs = emailed.get(email);
                        msg_dataFeeds = "";
                        email_msg = "";
                        for (String item : msgs) {
                            msg_dataFeeds += "<li>" + item + "</li>\r\n<br>";
                        }
                        email_msg += "<font face=arial size=2>";
                        email_msg += "<b>Notification Summary:</b><br>";
                        email_msg += msg_dataFeeds;
                        email_msg += "<br><br>";
                        email_msg += "<a href=http://udash/>http://udash/</a>";
                        email_msg += "";
                        email_msg += "</font>";
                        SystemManager.getInstance().println("<u>Notification</u>: " + email);
                        EmailSender.sendMail(email, "UDash Outage Notification", email_msg);

                    }
                    try {
                        Thread.sleep(60000 * 30);
                    } catch (Exception error) {

                    }
                }
                running = false;
                status = STATUS_STOPPED;
            }
        });
        thread.start();
    }

    public void stopProcess() {
        if (!running) {
            return;
        }
        doRun = false;
        status = STATUS_STOPPING;

        try {
            thread.interrupt();
        } catch (Exception error) {

        }
    }


    public int getStatus() {
        return status;
    }


    public boolean isRunning() {
        return running;
    }

}
