/**
 * <p>Title: TableIndex</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.tableindex;

import java.util.Date;

public class TableIndex {
    private long tableIndexID;
    private int dataFeedID;
    private int queryID;
    private Date usageDate;
    private String databaseName;
    private String tableName;
    private String absoluteName;
    private String owner;
    private long records;
    private long billingMilliseconds;
    private long networkMilliseconds;
    private Date dateCreated;
    private Date dateLastAnalyzed;
    private Date dateDataLastAdded;
    private boolean pendingAnalysis;
    private Date deleteDate;
    private boolean tableExists;

    public TableIndex() {

    }


    public String getAbsoluteName() {
        return absoluteName;
    }

    public void setAbsoluteName(String absoluteName) {
        this.absoluteName = absoluteName;
    }

    public long getBillingMilliseconds() {
        return billingMilliseconds;
    }

    public void setBillingMilliseconds(long billingMilliseconds) {
        this.billingMilliseconds = billingMilliseconds;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public int getDataFeedID() {
        return dataFeedID;
    }

    public void setDataFeedID(int dataFeedID) {
        this.dataFeedID = dataFeedID;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateLastAnalyzed() {
        return dateLastAnalyzed;
    }

    public void setDateLastAnalyzed(Date dateLastAnalyzed) {
        this.dateLastAnalyzed = dateLastAnalyzed;
    }

    public Date getDeleteDate() {
        return deleteDate;
    }

    public void setDeleteDate(Date deleteDate) {
        this.deleteDate = deleteDate;
    }

    public long getNetworkMilliseconds() {
        return networkMilliseconds;
    }

    public void setNetworkMilliseconds(long networkMilliseconds) {
        this.networkMilliseconds = networkMilliseconds;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public boolean isPendingAnalysis() {
        return pendingAnalysis;
    }

    public void setPendingAnalysis(boolean pendingAnalysis) {
        this.pendingAnalysis = pendingAnalysis;
    }

    public int getQueryID() {
        return queryID;
    }

    public void setQueryID(int queryID) {
        this.queryID = queryID;
    }

    public long getRecords() {
        return records;
    }

    public void setRecords(long records) {
        this.records = records;
    }

    public boolean isTableExists() {
        return tableExists;
    }

    public void setTableExists(boolean tableExists) {
        this.tableExists = tableExists;
    }

    public long getTableIndexID() {
        return tableIndexID;
    }

    public void setTableIndexID(long tableIndexID) {
        this.tableIndexID = tableIndexID;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Date getUsageDate() {
        return usageDate;
    }

    public void setUsageDate(Date usageDate) {
        this.usageDate = usageDate;
    }


    public Date getDateDataLastAdded() {
        return dateDataLastAdded;
    }

    public void setDateDataLastAdded(Date dateDataLastAdded) {
        this.dateDataLastAdded = dateDataLastAdded;
    }
}
