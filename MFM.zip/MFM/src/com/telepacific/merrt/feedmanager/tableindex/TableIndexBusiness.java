/**
 * <p>Title: TableIndexBusiness</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.tableindex;

import java.util.Date;

import com.telepacific.merrt.feedmanager.tableindex.TableIndex;
import com.telepacific.merrt.feedmanager.tableindex.TableIndexBusiness;
import com.telepacific.merrt.feedmanager.tableindex.TableIndexCache;
import com.telepacific.merrt.feedmanager.tableindex.TableIndexDAO;
import com.telepacific.merrt.feedmanager.tableindex.TableIndexManager;

public class TableIndexBusiness implements TableIndexManager {
    private TableIndexManager dao;
    private TableIndexManager cache;

    private boolean init = false;
    private static TableIndexManager instance = null;
    private boolean running = false;

    public synchronized static TableIndexManager getInstance() {
        if (instance == null) {
            instance = new TableIndexBusiness();
        }
        return instance;
    }

    private TableIndexBusiness() {
        cache = new TableIndexCache();
        this.reload();


    }

    @Override
	public TableIndex getTableIndex(int dataFeedID, Date usageDate) {
        return cache.getTableIndex(dataFeedID, usageDate);
    }

    @Override
	public TableIndex[] getTableIndex() {
        return cache.getTableIndex();
    }

    @Override
	public TableIndex getTableIndex(long tableIndexID) {
        return dao.getTableIndex(tableIndexID);
    }


    @Override
	public TableIndex[] getTableIndexByOwner(String owner) {
        return cache.getTableIndexByOwner(owner);
    }

    @Override
	public void reload() {
        if (running) {
            return;
        }
        running = true;
        dao = new TableIndexDAO();
        final TableIndexCache cachetmp = new TableIndexCache();
        Thread thread = (new Thread() {
            @Override
			public void run() {
                System.out.println("Reloading Table Index...");
                for (TableIndex tableIndex : dao.getTableIndex()) {
                    cachetmp.setTableIndex(tableIndex);
                    if (!init) {
                        cache.setTableIndex(tableIndex);
                    }
                }
                init = true;
                cache = cachetmp;
                System.out.println("Reloading Table Index...done");
                running = false;
            }
        });
        thread.start();
    }

    private boolean updating = false;
    @Override
	public void update() {
        if (updating) {
            return;
        }
        updating = true;
        Thread thread = (new Thread() {
            @Override
			public void run() {
                System.out.println("Updating Table Index...");
                //TableIndexCache tmpCache = new TableIndexCache();
                for (TableIndex tableIndex : dao.getTableIndex()) {
                    cache.setTableIndex(tableIndex);
                }
                //cache = tmpCache;
                System.out.println("Updating Table Index...done");
                updating = false;
            }
        });
        thread.start();

//        for (TableIndex tableIndex : dao.getTableIndex()) {
//            tmpCache.setTableIndex(tableIndex);
//        }
    }

    @Override
	public TableIndex[] getTableIndexPendingAnalysis() {
        return dao.getTableIndexPendingAnalysis();
    }


    @Override
	public TableIndex[] getTableIndexByQueryID(int queryID) {
        return cache.getTableIndexByQueryID(queryID);
    }

    @Override
	public TableIndex[] getTableIndexByQueryID(int[] queryIDs) {
        return cache.getTableIndexByQueryID(queryIDs);
    }

    @Override
	public TableIndex setTableIndex(TableIndex tableIndex) {
        tableIndex = dao.setTableIndex(tableIndex);
        cache.setTableIndex(tableIndex);
        return tableIndex;
    }

    @Override
	public void delete(TableIndex tableIndex) {
        dao.delete(tableIndex);
        cache.delete(tableIndex);
    }
}
