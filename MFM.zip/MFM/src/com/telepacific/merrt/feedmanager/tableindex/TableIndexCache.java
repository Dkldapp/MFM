/**
 * <p>Title: TableIndexCache</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.tableindex;

import java.util.*;

import com.telepacific.merrt.feedmanager.tableindex.TableIndex;
import com.telepacific.merrt.feedmanager.tableindex.TableIndexManager;

public class TableIndexCache implements TableIndexManager {
    private Hashtable<Long, TableIndex> tableIndexs;
    private Hashtable<String, ArrayList<TableIndex>> tableIndexsByOwner;
    private Hashtable<Integer, ArrayList<TableIndex>> tableIndexsByQueryID;
    private Hashtable<Integer, Hashtable<String, TableIndex>> tableIndexsByUsageDate;

    public TableIndexCache() {
        this.reload();
    }

    @Override
	public TableIndex[] getTableIndex() {
        TableIndex[] rtn = tableIndexs.values().toArray(new TableIndex[tableIndexs.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o1.getUsageDate().compareTo(o2.getUsageDate());
            }
        });
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return new Integer(o1.getDataFeedID()).compareTo(new Integer(o2.getDataFeedID()));
            }
        });

        return rtn;
    }


    @Override
	public TableIndex getTableIndex(int dataFeedID, Date usageDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(usageDate.getTime());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        usageDate = new Date(cal.getTimeInMillis());

        Hashtable<String, TableIndex> list;
        if (tableIndexsByUsageDate.containsKey(dataFeedID)) {
            list = tableIndexsByUsageDate.get(dataFeedID);
        } else {
            list = new Hashtable<String, TableIndex>();
        }
        TableIndex rtn;
//        System.out.println("List Size is: " + list.size() + " - " + usageDate.toString());
        for (String value : list.keySet()) {
//            System.out.println(value);
        }
        rtn = list.get(usageDate.toString());

        return rtn;
    }

    @Override
	public TableIndex getTableIndex(long tableIndexID) {
        return tableIndexs.get(tableIndexID);
    }


    @Override
	public TableIndex[] getTableIndexPendingAnalysis() {
        return new TableIndex[0];
    }

    @Override
	public TableIndex[] getTableIndexByOwner(String owner) {
        ArrayList<TableIndex> list;
        if (tableIndexsByOwner.containsKey(owner)) {
            list = tableIndexsByOwner.get(owner);
        } else {
            list = new ArrayList<TableIndex>();
        }
        TableIndex[] rtn = list.toArray(new TableIndex[list.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getUsageDate().compareTo(o1.getUsageDate());
            }
        });
        return rtn;
    }


    @Override
	public TableIndex[] getTableIndexByQueryID(int queryID) {
        ArrayList<TableIndex> list;
        if (tableIndexsByQueryID.containsKey(queryID)) {
            list = tableIndexsByQueryID.get(queryID);
        } else {
            list = new ArrayList<TableIndex>();
        }
        TableIndex[] rtn = list.toArray(new TableIndex[list.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getUsageDate().compareTo(o1.getUsageDate());
            }
        });
        return rtn;
    }

    @Override
	public TableIndex[] getTableIndexByQueryID(int[] queryIDs) {
        ArrayList<TableIndex> list;
        ArrayList<TableIndex> outindex = new ArrayList<TableIndex>();
        for (int queryID : queryIDs) {
            if (tableIndexsByQueryID.containsKey(queryID)) {
                list = tableIndexsByQueryID.get(queryID);
            } else {
                list = new ArrayList<TableIndex>();
            }

            for (TableIndex ti : list) {
                outindex.add(ti);
            }
        }
        TableIndex[] rtn = outindex.toArray(new TableIndex[outindex.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getUsageDate().compareTo(o1.getUsageDate());
            }
        });

        return rtn;
    }

    @Override
	public void reload() {
        tableIndexs = new Hashtable<Long, TableIndex>();
        tableIndexsByOwner = new Hashtable<String, ArrayList<TableIndex>>();
        tableIndexsByQueryID = new Hashtable<Integer, ArrayList<TableIndex>>();
        tableIndexsByUsageDate = new Hashtable<Integer, Hashtable<String, TableIndex>>();
    }

    @Override
	public void update() {

    }

    @Override
	public synchronized TableIndex setTableIndex(TableIndex tableIndex) {
        if (tableIndexs.containsKey(tableIndex.getTableIndexID())) {
            synchronized (tableIndexs) {
                tableIndexs.remove(tableIndex.getTableIndexID());
            }
        }
        synchronized (tableIndexs) {
            tableIndexs.put(tableIndex.getTableIndexID(), tableIndex);
        }
        ArrayList<TableIndex> tableIndexOwnerList;
        if (tableIndexsByOwner.containsKey(tableIndex.getOwner())) {
            tableIndexOwnerList = tableIndexsByOwner.get(tableIndex.getOwner());
        } else {
            tableIndexOwnerList = new ArrayList<TableIndex>();
        }
        int i = 0;

        for (TableIndex a : tableIndexOwnerList) {
            synchronized (tableIndexOwnerList) {
                if (a.getTableIndexID() == tableIndex.getTableIndexID()) {
                    tableIndexOwnerList.remove(i);
                    break;
                }
            }
            i ++;
        }
        synchronized (tableIndexOwnerList) {
            tableIndexOwnerList.add(tableIndex);
        }
        i = 0;

        tableIndexsByOwner.put(tableIndex.getOwner(), tableIndexOwnerList);

        ArrayList<TableIndex> tableIndexQueryIDList;
        if (tableIndexsByQueryID.containsKey(tableIndex.getQueryID())) {
            tableIndexQueryIDList = tableIndexsByQueryID.get(tableIndex.getQueryID());
        } else {
            tableIndexQueryIDList = new ArrayList<TableIndex>();
        }
        for (TableIndex a : tableIndexQueryIDList) {
            if (a.getQueryID()!=0&&tableIndex.getQueryID() == a.getQueryID()) {
                if (tableIndex.getTableIndexID() > a.getTableIndexID()) {
                    synchronized (tableIndexQueryIDList) {
                        tableIndexQueryIDList.remove(i);
                        break;
                    }
                }
            }
            i++;
        }
        i = 0;
        for (TableIndex a : tableIndexQueryIDList) {
            if (a.getTableIndexID() == tableIndex.getTableIndexID()) {
                synchronized (tableIndexQueryIDList) {
                    tableIndexQueryIDList.remove(i);
                }
                break;
            }
            i++;
        }

        synchronized (tableIndexQueryIDList) {
            tableIndexQueryIDList.add(tableIndex);
        }
        tableIndexsByQueryID.put(tableIndex.getQueryID(), tableIndexQueryIDList);




        /*ffda*/
        Hashtable<String, TableIndex> tableIndexUsageDateList;
        if (tableIndexsByUsageDate.containsKey(tableIndex.getDataFeedID())) {
            tableIndexUsageDateList = tableIndexsByUsageDate.get(tableIndex.getDataFeedID());
        } else {
            tableIndexUsageDateList = new Hashtable<String, TableIndex>();
            tableIndexsByUsageDate.put(tableIndex.getDataFeedID(), tableIndexUsageDateList);
        }
        i = 0;

        for (TableIndex a : tableIndexUsageDateList.values()) {
            synchronized (tableIndexUsageDateList) {
                if (a.getTableIndexID() == tableIndex.getTableIndexID()) {
                    tableIndexUsageDateList.remove(tableIndex.getUsageDate().toString());
                    break;
                }
            }
            i++;
        }
        Date usageDate = tableIndex.getUsageDate();
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(usageDate.getTime());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        usageDate = new Date(cal.getTimeInMillis());

        synchronized (tableIndexUsageDateList) {
            tableIndexUsageDateList.put(usageDate.toString(), tableIndex);
        }


        return tableIndex;
    }


    @Override
	public void delete(TableIndex tableIndex) {
        tableIndexs.remove(tableIndex.getTableIndexID());

    }
}
