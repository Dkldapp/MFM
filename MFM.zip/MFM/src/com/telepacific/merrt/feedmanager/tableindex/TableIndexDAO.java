/**
 * <p>Title: TableIndexDAO</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.tableindex;

import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.feedmanager.tableindex.TableIndex;
import com.telepacific.merrt.feedmanager.tableindex.TableIndexManager;

import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.*;

public class TableIndexDAO implements TableIndexManager {
    public TableIndexDAO() {

    }

    @Override
	public TableIndex[] getTableIndex() {
        //System.out.println("########TableIndexManagerDAO.getTableIndex()########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();

        data = session.createQuery("select u from TableIndex as u").list();
        tx.commit();
        TableIndex[] rtn = (TableIndex[]) data.toArray(new TableIndex[data.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getUsageDate().compareTo(o1.getUsageDate());
            }
        });
        return rtn;
    }

    @Override
	public TableIndex getTableIndex(int dataFeedID, Date usageDate) {
        //System.out.println("########TableIndexManagerDAO.getTableIndex(" + tableIndexID + ")########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from TableIndex as u where dataFeedID='" + dataFeedID + "' and usageDate = '"+usageDate+"'").list();
        tx.commit();
        TableIndex[] rtn = (TableIndex[]) data.toArray(new TableIndex[data.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getTableName().compareTo(o1.getTableName());
            }
        });
        return rtn[0];
    }

    @Override
	public TableIndex getTableIndex(long tableIndexID) {
        //System.out.println("########TableIndexManagerDAO.getTableIndex(" + tableIndexID + ")########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from TableIndex as u where tableIndexID='"+tableIndexID+"'").list();
        tx.commit();
        TableIndex[] rtn = (TableIndex[]) data.toArray(new TableIndex[data.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getTableName().compareTo(o1.getTableName());
            }
        });
        return rtn[0];
    }


    @Override
	public TableIndex[] getTableIndexByOwner(String owner) {
        return new TableIndex[0];
    }

    public TableIndex[] getTableIndexByTableIndexTypeID(int tableIndexTypeID) {
        return new TableIndex[0];
    }

    @Override
	public TableIndex[] getTableIndexByQueryID(int queryID) {
        return new TableIndex[0];
    }


    @Override
	public TableIndex[] getTableIndexByQueryID(int[] queryIDs) {
        return new TableIndex[0];
    }

    @Override
	public void reload() {

    }

    @Override
	public void update() {

    }

    @Override
	public TableIndex setTableIndex(TableIndex tableIndex) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (tableIndex.getTableIndexID() <= 0) {
//                System.out.println("################Saving Table Index: " + tableIndex.getTableIndexID());
                session.save(tableIndex);
            } else {
//                System.out.println("################Updating Table Index: " + tableIndex.getTableIndexID());
                session.update(tableIndex);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return tableIndex;
    }


    @Override
	public TableIndex[] getTableIndexPendingAnalysis() {
        //System.out.println("########TableIndexManagerDAO.getTableIndexPendingAnalysis()########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from TableIndex as u where pendingAnalysis=1").list();
        tx.commit();
        TableIndex[] rtn = (TableIndex[]) data.toArray(new TableIndex[data.size()]);
        Arrays.sort(rtn, new Comparator<TableIndex>() {
            @Override
			public int compare(TableIndex o1, TableIndex o2) {
                return o2.getTableName().compareTo(o1.getTableName());
            }
        });
        return rtn;
    }

    @Override
	public void delete(TableIndex tableIndex) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(tableIndex);
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }
}
