/**
 * <p>Title: TableIndexManager</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.tableindex;

import java.util.Date;

import com.telepacific.merrt.feedmanager.tableindex.TableIndex;

public interface TableIndexManager {
    public TableIndex[] getTableIndex();

    public TableIndex[] getTableIndexPendingAnalysis();

    public TableIndex[] getTableIndexByOwner(String owner);

    public TableIndex[] getTableIndexByQueryID(int queryID);

    public TableIndex[] getTableIndexByQueryID(int[] queryIDs);

    public TableIndex getTableIndex(int dataFeedID, Date usageDate);

    public TableIndex getTableIndex(long tableIndexID);

    public TableIndex setTableIndex(TableIndex tableIndex);

    public void reload();

    public void update();

    public void delete(TableIndex tableIndex);

}
