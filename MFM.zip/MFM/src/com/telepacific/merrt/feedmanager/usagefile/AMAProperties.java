/**
 * <p>Title: AMAProperties</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructure;
import com.telepacific.merrt.feedmanager.usagefile.AMAProperties;
import com.telepacific.merrt.feedmanager.usagefile.UsageFile;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;

public class AMAProperties {
    private static AMAProperties instance = null;
    public static AMAProperties getInstance() {
        if (instance==null) {
            instance = new AMAProperties();
        }
        return instance;
    }

    private UsageFileProperties ama = null;

    public UsageFileProperties getAMA() {
        return ama;
    }

    private AMAProperties() {

        UsageFileStructure usageFileStructure = null;
        usageFileStructure = UsageFileStructure.getInstance(1, null);

        UsageFileProperties properties = new UsageFileProperties();

        properties = new UsageFileProperties();
        properties.setFileStructure(usageFileStructure);
        properties.setDelimination("-");
        properties.setUsageFileStructureID(1);
        properties.setUsageFileType(UsageFile.FILE_TYPE_AMA);
        properties.setModuleSupport(true);
        properties.setYYYYStart(0);
        properties.setYYYYLength(1);
        properties.setYYYYPlus(2000);
        properties.setMMStart(1);
        properties.setMMLength(2);
        properties.setDDStart(3);
        properties.setDDLength(2);

        properties.setHHStart(0);
        properties.setHHLength(2);

        properties.setMIStart(2);
        properties.setMILength(2);

        properties.setSSStart(4);
        properties.setSSLength(2);

        properties.setMlStart(6);
        properties.setMlLength(1);
        properties.setDurationType(UsageFileProperties.DURATION_TYPE_IN_MI_SS_ML);
        ama = properties;
    }
}
