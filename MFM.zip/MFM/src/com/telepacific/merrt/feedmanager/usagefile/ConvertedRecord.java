/**
 * <p>Title: ConvertedRecord</p>
 * <p>Description:</p>
 * @author bgude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import java.util.Date;

public class ConvertedRecord {

    private String convertedRecord;
    private Date recordDate;

    public ConvertedRecord() {

    }

    public String getConvertedRecord() {
        return convertedRecord;
    }

    public void setConvertedRecord(String convertedRecord) {
        this.convertedRecord = convertedRecord;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }
}
