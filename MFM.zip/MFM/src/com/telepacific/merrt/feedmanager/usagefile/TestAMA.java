/**
 * <p>Title: TestAMA</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructure;
import com.telepacific.merrt.feedmanager.usagefile.UsageFile;

import java.io.File;

public class TestAMA {
    public TestAMA() {

    }
    public static void main(String[] args) {
        UsageFileStructure usageFileStructure = null;
        usageFileStructure = UsageFileStructure.getInstance(1, null);
        File inFile = new File(args[0]);
        UsageFile usageFile;
//        usageFile = new UsageFile(inFile, new File("e:\\eva\\file.out"), AMAProperties.getInstance().getAMA());
    }
}
