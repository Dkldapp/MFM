/**
 * <p>Title: TestBD1</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

public class TestBD1 {
    public TestBD1() {

    }

    public static void main(String[] args) {
/*
        UsageFileStructure usageFileStructure = null;
            usageFileStructure = UsageFileStructure.getInstance(12, null);
        File inFile = new File(args[0]);

        UsageFileProperties properties = new UsageFileProperties();
        properties.setFileStructure(usageFileStructure);
        properties.setDelimination("-");
        properties.setUsageFileStructureID(12);
        properties.setUsageFileType(UsageFile.FILE_TYPE_STRUCTURE);
        properties.setModuleSupport(false);
        properties.setYYYYStart(0);
        properties.setYYYYLength(4);
        properties.setMMStart(4);
        properties.setMMLength(2);
        properties.setDDStart(6);
        properties.setDDLength(2);

        properties.setHHStart(0);
        properties.setHHLength(2);

        properties.setMIStart(2);
        properties.setMILength(2);

        properties.setSSStart(4);
        properties.setSSLength(2);
        properties.setDurationType(UsageFileProperties.DURATION_TYPE_IN_SECONDS);

        UsageFile usageFile = new UsageFile(inFile, new File("d:\\test.txt"), properties);
*/
//         com.telepacific.fileutils.FileCompressor.GUnZipFile(new File("E:\\eva\\010214.030215.04625.01.2_decoded.gz"), true);
    }
}
