/**
 * <p>Title: TestX5</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructure;
import com.telepacific.merrt.feedmanager.usagefile.UsageFile;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;

import javax.sql.DataSource;
import javax.naming.Context;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.io.File;

public class TestX5 {
    public TestX5() {

    }

    public static void main(String[] args) {

        Connection conn = null;
        DataSource ds;
        Context jndiContext;

        try {
            try {
                Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
            } catch (ClassNotFoundException e) {

            }
            conn = DriverManager.getConnection("jdbc:microsoft:sqlserver://TITAN;databaseName=tpMediate;user=tpMediate;password=tpMediate");
        } catch (Exception error) {
            System.out.println(error);
        }
        ResultSet rs = null;
        StringBuffer qry = new StringBuffer();
        qry.append("usp_test");

        String query = qry.toString();//"USP_ONLINE_FILE_LOAD @FEED_ID='" + feed.getFeedID() + "', @FILE_NAME='" + file.getAbsolutePath() + "'";
        UsageFileStructure usageFileStructure = null;
        try {

            usageFileStructure = UsageFileStructure.getInstance(4, null);

            conn.close();
        } catch (Exception error) {
            System.out.println(error);
        }
        File inFile = new File(args[0]);
        //inFile = AMAFileReader.ConvertAMAtoTPEMI(inFile, new File(inFile.getAbsolutePath().replaceAll(".gz", "") + ".tpEMI"));

//        UsageFileStructure usageFileStructure = UsageFileStructure.getInstance(2, null);

        UsageFileProperties properties = new UsageFileProperties();
        properties.setFileStructure(usageFileStructure);
        properties.setDelimination("-");
        properties.setUsageFileStructureID(4);
        properties.setUsageFileType(UsageFile.FILE_TYPE_STRUCTURE);
        properties.setModuleSupport(false);
        properties.setYYYYStart(0);
        properties.setYYYYLength(4);
        properties.setMMStart(4);
        properties.setMMLength(2);
        properties.setDDStart(6);
        properties.setDDLength(2);

        properties.setHHStart(0);
        properties.setHHLength(2);

        properties.setMIStart(2);
        properties.setMILength(2);

        properties.setSSStart(4);
        properties.setSSLength(2);
        properties.setDurationType(UsageFileProperties.DURATION_TYPE_IN_SECONDS);

//        UsageFile usageFile = new UsageFile(inFile, new File("d:\\test.txt"), properties);
    }
}
