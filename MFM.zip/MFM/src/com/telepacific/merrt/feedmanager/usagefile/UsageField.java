/**
 * <p>Title: UsageField</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;

public class UsageField {
    UsageFileProperties properties;

    public UsageField(String strRecord, UsageFileProperties properties) {
    }

    public static void main(String[] args) {

    }
}
