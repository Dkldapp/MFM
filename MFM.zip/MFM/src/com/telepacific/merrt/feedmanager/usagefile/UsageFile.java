/**
 * <p>Title: UsageFile</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.type.*;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;
import com.telepacific.merrt.feedmanager.usagefile.UsageRecord;
import com.telepacific.merrt.feedmanager.usagefile.type.AMAUsageFileData;
import com.telepacific.merrt.feedmanager.usagefile.type.DelimitedFileData;
import com.telepacific.merrt.feedmanager.usagefile.type.FileData;
import com.telepacific.merrt.feedmanager.usagefile.type.FixedLengthFileData;
import com.telepacific.merrt.feedmanager.usagefile.type.StructureFileData;

import java.io.File;
import java.util.Date;

public class UsageFile {

    public static final int FILE_TYPE_DELIMITED = 0;
    public static final int FILE_TYPE_STRUCTURE = 1;
    public static final int FILE_TYPE_AMA = 2;
    public static final int FILE_TYPE_FIXED = 3;

    private File file;
    private UsageRecord[] usageRecords;

    private long[] lUsageDates;
    private Date dtStart;
    private Date dtEnd;
    private UsageFileProperties properties;
    private String[] files = new String[0];

    public UsageFile(File file, UsageFileProperties properties) {
        this.file = file;
        this.properties = properties;
        this.read();
    }

    private void read() {

        FileData fileData = null;

        dtStart = new Date();
        dtEnd = null;

        switch (this.properties.getUsageFileType()) {
            case FILE_TYPE_DELIMITED :
                fileData = new DelimitedFileData(this.file);
                fileData.setDelimination(this.properties.getDelimination());
                break;
            case FILE_TYPE_AMA :
                fileData = new AMAUsageFileData(this.file, this.properties);
                break;
            case FILE_TYPE_STRUCTURE:
                fileData = new StructureFileData(this.file, this.properties);
                fileData.setFileStructureID(this.properties.getFileStructureID());
                break;
            case FILE_TYPE_FIXED:
                fileData = new FixedLengthFileData(this.file, this.properties);
                fileData.setFileStructureID(this.properties.getFileStructureID());
                break;
            default:
                fileData = null;
                break;
        }
        files = fileData.getFiles();
        usageRecords = fileData.getRecords();
        dtEnd = new Date();
    }

    public UsageRecord[] getRecords() {
        return usageRecords;
    }

    public long[] getUsageDate() {
        return null;
    }

    public File getUsageFile() {
        return this.file;
    }

    public long getProcessStartTime() {
        return dtStart.getTime();
    }

    public long getProcessEndTime() {
        return dtEnd.getTime();
    }

    public String[] getFiles() {
        return files;
    }

}
