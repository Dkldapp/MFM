/**
 * <p>Title: UsageFileProperties</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructure;
import com.telepacific.merrt.feedmanager.usagefile.UsageFile;

public class UsageFileProperties {

    public final static int DURATION_TYPE_IN_MI_SS_ML = 0;
    public final static int DURATION_TYPE_IN_SECONDS = 1;

    private int iUsageFileType = UsageFile.FILE_TYPE_DELIMITED;
    private String strDelimination = null;
    private int iFileStructureID;
    private UsageFileStructure usageFileStructure;
    private boolean bModuleSupport = false;

    private int iYYYYStart;
    private int iYYYYLength;

    private int iYYYYPlus = 0;

    private int iMMStart;
    private int iMMLength;

    private int iDDStart;
    private int iDDLength;

    private int iHHStart;
    private int iHHLength;

    private int iMIStart;
    private int iMILength;

    private int iSSStart;
    private int iSSLength;

    private int mlStart = 0;
    private int mlLength = 0;
    private int durationType = DURATION_TYPE_IN_MI_SS_ML;
    private int durationMultiply = 0;

    public UsageFileProperties() {

    }

    public int getDurationMultiply() {
        return durationMultiply;
    }

    public void setDurationMultiply(int durationMultiply) {
        this.durationMultiply = durationMultiply;
    }

    public void setFileStructure(UsageFileStructure usageFileStructure) {
        this.usageFileStructure = usageFileStructure;
    }

    public void setDelimination(String delimination) {
        this.strDelimination = delimination;
    }

    public void setUsageFileStructureID(int usageFileStructureID) {
        this.iFileStructureID = usageFileStructureID;
    }

    public void setFileStructureID(int iFileStructureID) {
        this.iFileStructureID = iFileStructureID;
    }

    public void setUsageFileStructure(UsageFileStructure usageFileStructure) {
        this.usageFileStructure = usageFileStructure;
    }

    public void setUsageFileType(int iUsageFileType) {
        this.iUsageFileType = iUsageFileType;
    }


    public UsageFileStructure getFileStructure() {
        return this.usageFileStructure;
    }

    public String getDelimination() {
        return this.strDelimination;
    }

    public int getUsageFileStructureID() {
        return this.iFileStructureID;
    }

    public int getFileStructureID() {
        return this.iFileStructureID;
    }

    public UsageFileStructure getUsageFileStructure() {
        return this.usageFileStructure;
    }

    public int getUsageFileType() {
        return this.iUsageFileType;
    }

    public void setModuleSupport(boolean bModuleSupport) {
        this.bModuleSupport = bModuleSupport;
    }

    public boolean getModuleSupport() {
        return this.bModuleSupport;
    }

    public int getDDLength() {
        return iDDLength;
    }

    public void setDDLength(int iDDLength) {
        this.iDDLength = iDDLength;
    }

    public int getDDStart() {
        return iDDStart;
    }

    public void setDDStart(int iDDStart) {
        this.iDDStart = iDDStart;
    }

    public int getYYYYLength() {
        return iYYYYLength;
    }

    public void setYYYYLength(int iYYYYLength) {
        this.iYYYYLength = iYYYYLength;
    }

    public int getYYYYStart() {
        return iYYYYStart;
    }

    public void setYYYYStart(int iYYYYStart) {
        this.iYYYYStart = iYYYYStart;
    }

    public int getMMStart() {
        return iMMStart;
    }

    public void setMMStart(int iMMStart) {
        this.iMMStart = iMMStart;
    }

    public int getMMLength() {
        return iMMLength;
    }

    public void setMMLength(int iMMLength) {
        this.iMMLength = iMMLength;
    }


    public int getHHStart() {
        return iHHStart;
    }

    public void setHHStart(int iHHStart) {
        this.iHHStart = iHHStart;
    }

    public int getHHLength() {
        return iHHLength;
    }

    public void setHHLength(int iHHLength) {
        this.iHHLength = iHHLength;
    }

    public int getMIStart() {
        return iMIStart;
    }

    public void setMIStart(int iMIStart) {
        this.iMIStart = iMIStart;
    }

    public int getMILength() {
        return iMILength;
    }

    public void setMILength(int iMILength) {
        this.iMILength = iMILength;
    }

    public int getSSStart() {
        return iSSStart;
    }

    public void setSSStart(int iSSStart) {
        this.iSSStart = iSSStart;
    }

    public int getSSLength() {
        return iSSLength;
    }

    public void setSSLength(int iSSLength) {
        this.iSSLength = iSSLength;
    }

    public int getYYYYPlus() {
        return iYYYYPlus;
    }

    public void setYYYYPlus(int iYYYYPlus) {
        this.iYYYYPlus = iYYYYPlus;
    }

    public int getMlLength() {
        return mlLength;
    }

    public void setMlLength(int mlLength) {
        this.mlLength = mlLength;
    }

    public int getMlStart() {
        return mlStart;
    }

    public void setMlStart(int mlStart) {
        this.mlStart = mlStart;
    }

    public int getDurationType() {
        return durationType;
    }

    public void setDurationType(int durationType) {
        this.durationType = durationType;
    }
}
