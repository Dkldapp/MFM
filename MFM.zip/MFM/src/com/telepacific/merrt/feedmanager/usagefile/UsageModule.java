/**
 * <p>Title: UsageModule</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureField;

import java.util.ArrayList;

public class UsageModule {

    private ArrayList fields = new ArrayList();
    private String moduleID;
    public UsageModule(String moduleID) {
        this.moduleID = moduleID;
    }
    public String getModuleKey() {
        return this.moduleID;
    }
    public void addField(UsageFileStructureField field) {
        fields.add(field);
    }
    public UsageFileStructureField[] getField() {
        UsageFileStructureField[] rtn = new UsageFileStructureField[fields.size()];
        UsageFileStructureField fld;
        for (int i=0;i<rtn.length;i++) {
            fld = (UsageFileStructureField)fields.get(i);
            rtn[i] = fld;
        }
        return rtn;
    }
}
