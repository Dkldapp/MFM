/**
 * <p>Title: UsageRecord</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureField;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureModule;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureRecord;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;
import com.telepacific.merrt.feedmanager.usagefile.UsageModule;

import java.sql.Timestamp;
import java.util.Hashtable;
import java.util.ArrayList;

public class UsageRecord {
    private UsageFileProperties properties;

    private Hashtable fieldIndex;

    private String strSiteName;
    private String strOriginatingNumber;
    private String strTerminatingNumber;
    private String strCallType;
    private String strRecordType;
    private String strCallDirection;
    private String strCallCompletion;
    private Timestamp tsCallDate;
    private String strOriginatingTGN;
    private String strTerminatingTGN;
    private String strCompanyCode;
    private String iSeconds;
    private String iCarrierSeconds;
    private String strAccountNumber;
    private String strInvoiceNumber;
    private StringBuffer strRecordText;
    private int iRecordLength;

    private UsageModule[] usageModule = new UsageModule[0];

    public int getRecordLength() {
        return iRecordLength;
    }

    public void setRecordLength(int iRecordLength) {
        this.iRecordLength = iRecordLength;
    }

    public int getStructureLength() {
        return iStructureLength;
    }

    public void setStructureLength(int iStructureLength) {
        this.iStructureLength = iStructureLength;
    }

    int iStructureLength;

    public String getCarrierSeconds() {
        return iCarrierSeconds;
    }

    public void setCarrierSeconds(String iCarrierSeconds) {
        this.iCarrierSeconds = iCarrierSeconds;
    }

    public String getSeconds() {
        return iSeconds;
    }

    public void setSeconds(String iSeconds) {
        this.iSeconds = iSeconds;
    }

    public String getAccountNumber() {
        return strAccountNumber;
    }

    public void setAccountNumber(String strAccountNumber) {
        this.strAccountNumber = strAccountNumber;
    }

    public String getCallCompletion() {
        return strCallCompletion;
    }

    public void setCallCompletion(String strCallCompletion) {
        this.strCallCompletion = strCallCompletion;
    }

    public String getCallDirection() {
        return strCallDirection;
    }

    public void setCallDirection(String strCallDirection) {
        this.strCallDirection = strCallDirection;
    }

    public String getCallType() {
        return strCallType;
    }

    public void setCallType(String strCallType) {
        this.strCallType = strCallType;
    }

    public String getCompanyCode() {
        return strCompanyCode;
    }

    public void setCompanyCode(String strCompanyCode) {
        this.strCompanyCode = strCompanyCode;
    }

    public String getInvoiceNumber() {
        return strInvoiceNumber;
    }

    public void setInvoiceNumber(String strInvoiceNumber) {
        this.strInvoiceNumber = strInvoiceNumber;
    }

    public String getOriginatingNumber() {
        return strOriginatingNumber;
    }

    public void setOriginatingNumber(String strOriginatingNumber) {
        this.strOriginatingNumber = strOriginatingNumber;
    }

    public String getOriginatingTGN() {
        return strOriginatingTGN;
    }

    public void setOriginatingTGN(String strOriginatingTGN) {
        this.strOriginatingTGN = strOriginatingTGN;
    }

    public String getRecordType() {
        return strRecordType;
    }

    public void setRecordType(String strRecordType) {
        this.strRecordType = strRecordType;
    }

    public String getSiteName() {
        return strSiteName;
    }

    public void setSiteName(String strSiteName) {
        this.strSiteName = strSiteName;
    }

    public String getTerminatingNumber() {
        return strTerminatingNumber;
    }

    public void setTerminatingNumber(String strTerminatingNumber) {
        this.strTerminatingNumber = strTerminatingNumber;
    }

    public String getTerminatingTGN() {
        return strTerminatingTGN;
    }

    public void setTerminatingTGN(String strTerminatingTGN) {
        this.strTerminatingTGN = strTerminatingTGN;
    }

    public Timestamp getCallDate() {
        return tsCallDate;
    }

    public void setCallDate(Timestamp tsCallDate) {
        this.tsCallDate = tsCallDate;
    }

    public void setRecordText(StringBuffer strRecordText) {
        this.strRecordText = strRecordText;
    }

    public StringBuffer getRecordText() {
        return this.strRecordText;
    }

    private void read() {
        fieldIndex = new Hashtable();

        String strRecord = strRecordText.toString();

        String strKey;
        UsageFileStructureRecord ufsr;
        UsageFileStructureField[] ufsf;
        UsageFileStructureField fld;

        String strFieldData;
        String strRecordModule;
        //UsageModule usageModule;

        int iKeyStart = this.properties.getUsageFileStructure().getKeyStart();
        int iKeyLength = this.properties.getUsageFileStructure().getKeyLength();

        if ((iKeyStart + iKeyLength) <= strRecord.length()) {
            strKey = strRecord.substring(iKeyStart, iKeyStart + iKeyLength);
        } else {
            strKey = "";
        }

        ufsr = this.properties.getUsageFileStructure().getRecordStructure(strKey);

        if (ufsr.getLength() != 0) {
            ufsf = ufsr.getField();
            for (int ii = 0; ii < ufsf.length; ii++) {
                fld = ufsf[ii];
                if (strKey.equals("9037")) {
                    fld.setFieldStart(fld.getFieldStart() + 10);
                }
                strFieldData = strRecord.substring(fld.getFieldStart(), fld.getFieldStart() + fld.getFieldLength());
                    if (fld.getUsageFieldMap()!=null) {
                        fieldIndex.put(fld.getUsageFieldMap(), strFieldData.trim());
//                        System.out.println(fld.getFieldName() + "(" + fld.getUsageFieldMap() + "): " + strFieldData);
                    }
            }

            if (this.properties.getModuleSupport()) {
                strRecordModule = strRecord.substring(ufsr.getLength(), strRecord.length());
                //usageModule = new UsageModule(strRecordModule, this.properties);
                usageModule = this.processModule(strRecordModule);
//                System.ou.println("Mod Length: " + usageModule.length);
            }

//                System.out.println("Structure Length: " + ufsr.getLength());

        }


    }

    public String getFieldValue(String key) {
        String value;
        if (fieldIndex.containsKey(key)) {
            value = (String) fieldIndex.get(key);
        } else {
            value = null;
        }

        return value;
    }

    public UsageModule[] getUsageModule() {
        return usageModule;
    }

    public UsageRecord(StringBuffer strRecordText, UsageFileProperties properties) {
        this.properties = properties;
        this.strRecordText = strRecordText;
        this.read();
    }

    private UsageModule[] processModule(String strRecordModule) {

        int iModuleLength = 0;
        int iTotalModuleLength = 0;
        int iTmpModKeyStart;
        String strTmpModKey;
        String strModKey;
        UsageFileStructureModule ufsm;
        String strFieldData;
        UsageFileStructureField[] ufsf;
        UsageFileStructureField fld;
        UsageFileStructureField field;


        int iModKeyStart = this.properties.getUsageFileStructure().getModKeyStart();
        int iModKeyLength = this.properties.getUsageFileStructure().getModKeyLength();

        iTotalModuleLength = 0;
        iTmpModKeyStart = 0;

        ArrayList modules = new ArrayList();
        UsageModule usageModule;
        while (iTotalModuleLength < strRecordModule.length()) {
            if (strRecordModule.length() == 0) {
                break;
            }

            iTmpModKeyStart = iTotalModuleLength;
            if ((iTmpModKeyStart + iModKeyLength) <= strRecordModule.length()) {
                strModKey = strRecordModule.substring(iTmpModKeyStart, iTmpModKeyStart + iModKeyLength);
                try {
                    strTmpModKey = strRecordModule.substring(iTmpModKeyStart + iTmpModKeyStart + iModKeyLength, iTmpModKeyStart + (iModKeyLength + 1));
                    if (!strTmpModKey.equals("c")) {
                        strModKey = "";
                    }
                } catch (Exception error) {
                }
            } else {
                strModKey = "";
            }

            ufsm = this.properties.getUsageFileStructure().getModuleStructure(strModKey);
            ufsf = ufsm.getField();
            iModuleLength = ufsm.getLength();
            if (iModuleLength == 0) {
                iModuleLength = 8;
            }
            iTotalModuleLength += iModuleLength;
//                    System.out.println("Module:" + strModKey);
            usageModule = new UsageModule(strModKey);
            modules.add(usageModule);
            for (int ii = 0; ii < ufsf.length; ii++) {
                fld = ufsf[ii];
                field = new UsageFileStructureField();
                field.setFieldLength(fld.getFieldLength());
                field.setFieldName(fld.getFieldName());
                field.setFieldStart(fld.getFieldStart());
                field.setUsageFieldMap(fld.getUsageFieldMap());
                field.setUsageFieldMapID(fld.getUsageFieldMapID());

                if ((iTmpModKeyStart + fld.getFieldStart() + fld.getFieldLength()) < strRecordModule.length()) {
                    strFieldData = strRecordModule.substring(iTmpModKeyStart + fld.getFieldStart(), iTmpModKeyStart + fld.getFieldStart() + fld.getFieldLength());
                    field.setFieldValue(strFieldData);
                    usageModule.addField(field);
//                    System.out.println(" ----" + fld.getFieldName() + "(" + fld.getUsageFieldMap() + "): " + strFieldData);
                }
            }

//                    System.out.println("Length:" + iModuleLength);

        }
        UsageModule[] rtn = new UsageModule[modules.size()];
        for (int i=0;i<rtn.length;i++) {
            rtn[i] = (UsageModule)modules.get(i);

        }

        return rtn;

    }
}
