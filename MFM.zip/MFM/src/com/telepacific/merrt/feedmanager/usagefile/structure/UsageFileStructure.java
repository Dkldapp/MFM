/**
 * <p>Title: UsageFileStructure</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.structure;

import com.telepacific.merrt.config.UDashProps;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructure;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureField;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureModule;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureRecord;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.Hashtable;

public class UsageFileStructure {
    int iStructureID;
    Hashtable record;
    Hashtable module;

    private int iKeyStart;
    private int iKeyLength;

    private int iModKeyStart;
    private int iModKeyLength;

    //Database
    private StringBuffer strQuery;
    private Statement stmt;
    private ResultSet rs;
//    private Connection conn = null;
    private static boolean NEED_CONN = false;

    //private static UsageFileStructure instance = null;
    private static Hashtable<Integer, UsageFileStructure> instances = new Hashtable<Integer, UsageFileStructure>();

    public static UsageFileStructure getInstance(int structureID, Connection conn) {
        UsageFileStructure instance;
        if (!instances.containsKey(new Integer(structureID))) {
            instance = new UsageFileStructure(structureID, conn);
            instances.put(new Integer(structureID), instance);
        } else {
            instance = instances.get(new Integer(structureID));
        }
        return instance;
    }

    private UsageFileStructure(int structureID, Connection conn) {
        System.out.println("Initializing UsageFileStructure(" + structureID + ")");
        boolean closeConn = false;
        if (conn != null) {
//            this.conn = conn;
            closeConn = false;
        } else {
        }
        iStructureID = structureID;
        record = new Hashtable();
        module = new Hashtable();

/*        try {

        } catch (Exception error) {
            System.out.println(error);
        }
*/
        if (conn == null) {
            InitialContext jndiContext = null;
            DataSource ds = null;
            try {
                jndiContext = new InitialContext();
                ds = (DataSource) jndiContext.lookup("java:/dsTPMediate");
                conn = ds.getConnection();
            } catch (Exception error) {
                System.out.println(error + "\n\nConnecting to fixed ds...");
                try {
                    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
                    conn = DriverManager.getConnection(UDashProps.getInstance().getJDBC());
                } catch (Exception e) {

                }
            }
            closeConn = true;
        }

        int iUsageFileSructureID;
        String strUsageFileStructure;
        int iRecordID;
        int iPrevRecordID = -1;
        String strRecord;

        int iModuleID;
        int iPrevModuleID = -1;
        String strModule;

        int iFieldID;
        String strField;
        int iRecordFieldID;
        int iModuleFieldID;
        int iStartPosition;
        int iLength;
        int iUsageFieldMapID;
        String strUsageFieldMap;

        UsageFileStructureRecord ufsr = null;
        UsageFileStructureModule ufsm = null;
        UsageFileStructureField ufsf = null;

        String strQuery = "";
        strQuery += "[tpUsage2.0].dbo.USP_GET_USAGE_FILE_STRUCTURE_RECORD_FIELD @USAGE_FILE_STRUCTURE_ID='" + iStructureID + "'";

        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(strQuery);
            while (rs.next()) {

                iUsageFileSructureID = rs.getInt("USAGE_FILE_STRUCTURE_ID");
                strUsageFileStructure = rs.getString("USAGE_FILE_STRUCTURE");
                iRecordID = rs.getInt("USAGE_FILE_STRUCTURE_RECORD_ID");
                strRecord = rs.getString("USAGE_FILE_STRUCTURE_RECORD");
                iFieldID = rs.getInt("USAGE_FILE_STRUCTURE_FIELD_ID");
                strField = rs.getString("USAGE_FILE_STRUCTURE_FIELD");
                iRecordFieldID = rs.getInt("USAGE_FILE_STRUCTURE_RECORD_FIELD_ID");
                iStartPosition = rs.getInt("START_POSITION");
                iLength = rs.getInt("LENGTH");
                iUsageFieldMapID = rs.getInt("USAGE_FIELD_MAP_ID");
                strUsageFieldMap = rs.getString("USAGE_FIELD_MAP");

                if (iRecordID != iPrevRecordID) {
                    //Create a new record;
                    ufsr = new UsageFileStructureRecord(strRecord);
                    record.put(strRecord, ufsr);
                }

                ufsf = new UsageFileStructureField();
                ufsf.setFieldLength(iLength);
                ufsf.setFieldStart(iStartPosition);
                ufsf.setFieldName(strField);
                ufsf.setUsageFieldMapID(iUsageFieldMapID);
                ufsf.setUsageFieldMap(strUsageFieldMap);
                ufsr.addField(strField, ufsf);

                iPrevRecordID = iRecordID;
            }
        } catch (Exception error) {
            System.out.println("UsageFileStructure() - " + error);
        }

        strQuery = "";
        strQuery += "[tpUsage2.0].dbo.USP_GET_USAGE_FILE_STRUCTURE_MODULE_FIELD @USAGE_FILE_STRUCTURE_ID='" + iStructureID + "'";

        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(strQuery);
            while (rs.next()) {
                iUsageFileSructureID = rs.getInt("USAGE_FILE_STRUCTURE_ID");
                strUsageFileStructure = rs.getString("USAGE_FILE_STRUCTURE");
                iModuleID = rs.getInt("USAGE_FILE_STRUCTURE_MODULE_ID");
                strModule = rs.getString("USAGE_FILE_STRUCTURE_MODULE");
                iFieldID = rs.getInt("USAGE_FILE_STRUCTURE_FIELD_MODULE_ID");
                strField = rs.getString("USAGE_FILE_STRUCTURE_FIELD_MODULE");
                iModuleFieldID = rs.getInt("USAGE_FILE_STRUCTURE_MODULE_FIELD_ID");
                iStartPosition = rs.getInt("START_POSITION");
                iLength = rs.getInt("LENGTH");
                iUsageFieldMapID = rs.getInt("USAGE_FIELD_MAP_ID");
                strUsageFieldMap = rs.getString("USAGE_FIELD_MAP");

                if (iModuleID != iPrevModuleID) {
                    //Create a new Module;
                    ufsm = new UsageFileStructureModule(strModule);
                    module.put(strModule, ufsm);
                }

                ufsf = new UsageFileStructureField();
                ufsf.setFieldLength(iLength);
                ufsf.setFieldStart(iStartPosition);
                ufsf.setFieldName(strField);
                ufsf.setUsageFieldMapID(iUsageFieldMapID);
                ufsf.setUsageFieldMap(strUsageFieldMap);
                ufsm.addField(strField, ufsf);

                iPrevModuleID = iModuleID;
            }
        } catch (Exception error) {
            System.out.println("AA:" + error);
        }

        strQuery = "";
        strQuery += "[tpUsage2.0].dbo.USP_GET_USAGE_FILE_STRUCTURE @USAGE_FILE_STRUCTURE_ID='" + iStructureID + "'";

        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(strQuery);
            while (rs.next()) {
                iKeyStart = rs.getInt("KEY_START");
                iKeyLength = rs.getInt("KEY_LENGTH");
                iModKeyStart = rs.getInt("MOD_KEY_START");
                iModKeyLength = rs.getInt("MOD_KEY_LENGTH");
            }
        } catch (Exception error) {
            System.out.println("B: " + error);
        }

        try {
            if (closeConn) {
//                conn.close();
            }
//            this.onn = null;
        } catch (Exception error) {
        }


    }

    public int getKeyStart() {
        return iKeyStart;
    }

    public int getKeyLength() {
        return iKeyLength;
    }

    public int getModKeyStart() {
        return iModKeyStart;
    }

    public int getModKeyLength() {
        return iModKeyLength;
    }

    public UsageFileStructureRecord getRecordStructure(String key) {
        UsageFileStructureRecord ur;
        if (record.containsKey(key)) {
            ur = (UsageFileStructureRecord) record.get(key);
        } else {
            ur = new UsageFileStructureRecord(null);
        }

        return ur;
    }

    public UsageFileStructureModule getModuleStructure(String key) {
        UsageFileStructureModule um;
        if (module.containsKey(key)) {
            um = (UsageFileStructureModule) module.get(key);
        } else {
            um = new UsageFileStructureModule(null);
        }

        return um;
    }
}
