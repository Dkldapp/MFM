/**
 * <p>Title: UsageFileStructureField</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.structure;

public class UsageFileStructureField {
    private String strFieldName;
    private int iFieldLength;
    private int iFieldStart;
    private int iUsageFieldMapID;
    private String strUsageFieldMap;
    private String fieldValue;

    public UsageFileStructureField() {

    }

    public int getUsageFieldMapID() {
        return iUsageFieldMapID;
    }

    public void setUsageFieldMapID(int iUsageFieldMapID) {
        this.iUsageFieldMapID = iUsageFieldMapID;
    }

    public String getUsageFieldMap() {
        return strUsageFieldMap;
    }

    public void setUsageFieldMap(String strUsageFieldMap) {
        this.strUsageFieldMap = strUsageFieldMap;
    }

    public int getFieldStart() {
        return iFieldStart;
    }

    public void setFieldStart(int iFieldStart) {
        this.iFieldStart = iFieldStart;
    }

    public int getFieldLength() {
        return iFieldLength;
    }

    public void setFieldLength(int iFieldLength) {
        this.iFieldLength = iFieldLength;
    }

    public void setFieldName(String fieldName) {
        strFieldName = fieldName;
    }

    public String getFieldName() {
        return strFieldName;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

}
