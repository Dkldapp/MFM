/**
 * <p>Title: UsageFileStructureModule</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.structure;

import java.util.Hashtable;
import java.util.Iterator;

import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructureField;

public class UsageFileStructureModule {
    private int iLength;
    private String strKey;
    private String strModuleName;
    private Hashtable field;

    public UsageFileStructureModule(String key) {
        strKey = key;
        field = new Hashtable();
    }

    public void addField(String fieldName, UsageFileStructureField fld) {
        field.put(fieldName, fld);
        iLength = iLength + fld.getFieldLength();
    }

    public UsageFileStructureField[] getField() {
        UsageFileStructureField fld;
        UsageFileStructureField[] flds;
        int count = 0;
        String str;
        for (Iterator i = field.keySet().iterator(); i.hasNext();) {
            str = (String) i.next();
            count ++;
        }

        flds = new UsageFileStructureField[count];
        count = 0;
        for (Iterator i = field.keySet().iterator(); i.hasNext();) {
            str = (String) i.next();
            flds[count] = (UsageFileStructureField) field.get(str);
            count ++;
        }
        return flds;
    }

    public int getLength() {
        return iLength;
    }
}
