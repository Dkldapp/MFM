/**
 * <p>Title: AMAUsageFileData</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.type;

import com.telepacific.merrt.feedmanager.fileconverter.FileReader;
import com.telepacific.merrt.feedmanager.usagefile.ConvertedRecord;
import com.telepacific.merrt.feedmanager.usagefile.UsageField;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;
import com.telepacific.merrt.feedmanager.usagefile.UsageRecord;
import com.telepacific.merrt.feedmanager.usagefile.utils.BCD;
import com.telepacific.merrt.feedmanager.usagefile.type.FileData;

import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Hashtable;
import java.text.SimpleDateFormat;

public class AMAUsageFileData implements FileData {
    private UsageFileProperties properties;
    private File file;

    private UsageRecord[] usageRecords;
    private Hashtable<String, BufferedWriter> fileWriters = new Hashtable<String, BufferedWriter>();
    private ArrayList<String> files = new ArrayList<String>();
    public AMAUsageFileData(File file, UsageFileProperties properties) {
        this.file = file;
        this.properties = properties;

        try {
            this.read();
        } catch (Exception error) {
            //System.out.println("Error on file: " + file.getName() + "\n" + error);
            error.printStackTrace();
        }

        try {
            for (BufferedWriter fileWriter : fileWriters.values()) {
                fileWriter.flush();
                fileWriter.close();
            }
        } catch (Exception error) {
            System.out.println(error);
        }

    }

    @Override
	public void setDelimination(String str) {
    }

    @Override
	public void setFileStructureID(int fileStructureID) {
    }

    public void read() throws Exception {
        ArrayList<String> aryRecords = new ArrayList<String>();
        SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd");

        UsageField usageField;

//        int[] buffer = null;

        StringBuffer strAMARecord = null;
        String byteLow, byteHigh;

        FileInputStream fis = null;
        FileChannel channel = null;
        ByteBuffer bb = null;
        ConvertedRecord convertedRecord;
        BufferedWriter fileWriter;

        try {
            fis = new FileInputStream(file);

            channel = fis.getChannel();
            int fileLength = (int) channel.size();
            bb = ByteBuffer.allocate(fileLength);
            channel.read(bb);
//            buffer = new int[bb.capacity()];
            bb.rewind();
        } catch (Exception error) {
            System.out.println("A" + error);
        }
        int iBuffer;

        strAMARecord = new StringBuffer();

        String datekey;
        StringBuffer strRecordLength = new StringBuffer();
        int iRecordLength = 0;
        long iNewRecordIndex = 0;
        int iRecordCount = 0;
        File fileout;
        for (int i = 0; i < bb.capacity(); i++) {
            iBuffer = bb.get();

            if (iBuffer < 0) {
                iBuffer += 256;
            }

            byteHigh = BCD.formatByte(BCD.getHighOrder(iBuffer));
            byteLow = BCD.formatByte(BCD.getLowOrder(iBuffer));

            if (i == iNewRecordIndex) {
                iRecordCount ++;
                if (iRecordCount != 1) {
                        try {
                            if (strAMARecord.toString().indexOf("002d000000290000aa") != -1) {
                                strAMARecord = new StringBuffer(strAMARecord.toString().replace("002d000000290000aa", "00290000aa"));
                            }
                            if (strAMARecord.toString().indexOf("00ad000000a90000aa") != -1) {
                                strAMARecord = new StringBuffer(strAMARecord.toString().replace("00ad000000a90000aa", "00a90000aa"));
                            }
                            if (strAMARecord.toString().indexOf("005d000000590000aa") != -1) {
                                strAMARecord = new StringBuffer(strAMARecord.toString().replace("005d000000590000aa", "00590000aa"));
                            }
                            convertedRecord = FileReader.getRecordConverted(new UsageRecord(strAMARecord, properties), properties);
                            try {
                                if (convertedRecord.getRecordDate()!=null) {
                                    datekey = format.format(convertedRecord.getRecordDate());
                                } else {
                                    datekey = "nodate";
                                }

                                if (fileWriters.containsKey(datekey)) {
                                    fileWriter = fileWriters.get(datekey);
                                } else {
                                    fileout = new File(file.getAbsolutePath() + "." + datekey + ".dbout");
                                    fileWriter = new BufferedWriter(new FileWriter(fileout, false));
                                    files.add(fileout.getAbsolutePath());
                                    fileWriters.put(datekey, fileWriter);
                                }
                                fileWriter.write(convertedRecord.getConvertedRecord());
                                fileWriter.newLine();
                            } catch (Exception error) {
                                System.out.println("aa" + error);
                            }

                        } catch(Exception error) {
                            System.out.println("Record Error: " + this.file.getName() + "(" + iRecordCount + ") - " + strAMARecord);
                        }
                    } else {
                        aryRecords.add(strAMARecord.toString());
                    }
                    strAMARecord = new StringBuffer();
                }
            strAMARecord.append(byteHigh).append(byteLow);
            System.err.print(byteHigh + byteLow);

            if (i >= (iNewRecordIndex)) {
                strRecordLength.append(byteHigh).append(byteLow);
            }

            if (strRecordLength.length() == 4) {
                try {
                    iRecordLength = Integer.valueOf(strRecordLength.toString(), 16).intValue();
                } catch (Exception error) {
                    System.out.println(error);
                }

                if (iRecordLength > 200) {
                    iRecordLength = 4;
                }

                iNewRecordIndex += iRecordLength;
                strRecordLength = new StringBuffer();
            }
        }

        strAMARecord = new StringBuffer();

        try {
            channel.close();
            fis.close();
        } catch (Exception error) {
            System.out.println(error);
        }

        usageRecords = new UsageRecord[aryRecords.size()];
        int ii = 0;
        String sb;
        for (Iterator i = aryRecords.iterator(); i.hasNext();) {
            sb = (String) i.next();
            usageRecords[ii] = new UsageRecord(new StringBuffer(sb), this.properties);
            ii ++;
        }
        aryRecords.clear();
    }

    @Override
	public UsageRecord[] getRecords() {
        return this.usageRecords;
    }

    @Override
	public String[] getFiles() {
        return files.toArray(new String[files.size()]);
    }

    public static void main(String[] args) {

    }
}
