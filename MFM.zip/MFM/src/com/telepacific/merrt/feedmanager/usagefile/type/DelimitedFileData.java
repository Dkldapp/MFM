/**
 * <p>Title: DelimitedFileData</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.type;

import com.telepacific.merrt.feedmanager.usagefile.UsageRecord;
import com.telepacific.merrt.feedmanager.usagefile.structure.UsageFileStructure;
import com.telepacific.merrt.feedmanager.usagefile.type.FileData;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Iterator;

public class DelimitedFileData implements FileData {
    private File file;
    private String strDelimination = null;
    private int iRecordLength;
    private int iFileStructureID;
    private UsageFileStructure usageFileStructure;

    public DelimitedFileData(File InputFile) {
        file = InputFile;
        this.usageFileStructure = usageFileStructure;
    }

    public void setRecordLength(int len) {

    }

    @Override
	public void setDelimination(String str) {
        strDelimination = str;
    }

    @Override
	public void setFileStructureID(int fileStructureID) {
        iFileStructureID = fileStructureID;
    }

    @Override
	public UsageRecord[] getRecords() {
        UsageRecord[] usageRecords;
        ArrayList aryRecords = new ArrayList();

        int count;
        int[] buffer = null;

        StringBuffer strAMARecord = null;
        String byteLow, byteHigh;

        FileInputStream fis = null;
        BufferedReader br = null;
        FileChannel channel = null;
        ByteBuffer bb = null;

        try {
            fis = new FileInputStream(file);
            br = new BufferedReader(new InputStreamReader(fis));
        } catch (Exception error) {
            System.out.println("A" + error);
        }

        String strBuffer;
        count = 0;
        strAMARecord = new StringBuffer();
        String[] strTmpRecord;

        try {
            while (br.ready()) {
                strBuffer = br.readLine();
                if (this.strDelimination!=null) {
                    strTmpRecord = strBuffer.split(this.strDelimination);
                    for (int i=0;i<strTmpRecord.length;i++) {
//                        System.out.println(i + " - " + strTmpRecord[i]);
                        strAMARecord = new StringBuffer();
                        strAMARecord.append(strTmpRecord[i]);
                        count ++;
                        aryRecords.add(strAMARecord);
                    }
                } else {
                    strAMARecord = new StringBuffer();
                    strAMARecord.append(strBuffer);
                    count ++;
                    aryRecords.add(strAMARecord);
                }
//                System.out.println(strBuffer);

            }
        } catch (Exception error) {
            System.out.println("While: " + error);
        }
        try {
            fis.close();
        } catch (Exception error) {
            System.out.println(error);
        }

        usageRecords = new UsageRecord[count];
        int ii = 0;
        for (Iterator i = aryRecords.iterator(); i.hasNext();) {
            usageRecords[ii].setRecordText((StringBuffer) i.next());
            ii ++;
        }
        return usageRecords;
    }
    public static void main(String[] args) {

    }

    @Override
	public String[] getFiles() {
        return new String[0];
    }
}
