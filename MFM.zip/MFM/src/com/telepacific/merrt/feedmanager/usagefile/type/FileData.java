/**
 * <p>Title: FileData</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.type;

import com.telepacific.merrt.feedmanager.usagefile.UsageRecord;

public interface FileData {
    public UsageRecord[] getRecords();
    public void setDelimination(String str);
    public void setFileStructureID(int FileStructureID);
    public String[] getFiles();
}
