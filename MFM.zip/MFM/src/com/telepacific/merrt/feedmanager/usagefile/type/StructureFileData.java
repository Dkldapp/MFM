/**
 * <p>Title: StructureFileData</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.type;

import com.telepacific.merrt.feedmanager.fileconverter.FileReader;
import com.telepacific.merrt.feedmanager.usagefile.UsageFileProperties;
import com.telepacific.merrt.feedmanager.usagefile.UsageRecord;
import com.telepacific.merrt.feedmanager.usagefile.type.FileData;

import java.io.*;
import java.util.ArrayList;

public class StructureFileData implements FileData {
    private UsageFileProperties properties;
    private File file;
    private File outFile;

    private UsageRecord[] usageRecords;
    BufferedWriter fileWriter = null;

    public StructureFileData(File file,  UsageFileProperties properties) {
        this.file = file;
        this.outFile = outFile;
        this.properties = properties;

        if (this.outFile != null) {
            try {
                fileWriter = new BufferedWriter(new FileWriter(outFile, false));
            } catch (Exception error) {
                System.out.println(error);
            }
        }
        this.read();

        if (this.outFile != null) {
            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (Exception error) {
                System.out.println(error);
            }
        }

    }

    @Override
	public void setDelimination(String str) {
    }

    @Override
	public void setFileStructureID(int fileStructureID) {

    }

    @Override
	public UsageRecord[] getRecords() {
        return null;
    }

    public void read() {
        UsageRecord[] usageRecords;
        ArrayList aryRecords = new ArrayList();

        int count;
        StringBuffer strAMARecord = null;

        FileInputStream fis = null;
        BufferedReader br = null;


        try {
            fis = new FileInputStream(file);
            br = new BufferedReader(new InputStreamReader(fis));
        } catch (Exception error) {
            System.out.println("A" + error);
        }

        String strBuffer;
        count = 0;
        strAMARecord = new StringBuffer();
//        UsageFileStructure usageFileStructure = UsageFileStructure.getInstance(this.iFileStructureID, null);
        int iKeyStart = properties.getUsageFileStructure().getKeyStart();
        int iKeyLength = properties.getUsageFileStructure().getKeyLength();

        String strKey = "";
        int iRecordLength;
        int iRecordPosition = 0;
        StringBuffer strRecord;
        String convertedRecord;
        int iRecordCount = 0;
        UsageRecord usageRecord;
        try {
            while (br.ready()) {
                strBuffer = br.readLine();
                iRecordPosition = 0;
                while (iRecordPosition<strBuffer.length()) {
                    if (iKeyLength==0) {
                        strKey = "1";
                    } else {
                        strKey = strBuffer.substring(iRecordPosition + iKeyStart, iRecordPosition + iKeyStart + iKeyLength);
                    }
                    iRecordLength = properties.getUsageFileStructure().getRecordStructure(strKey).getLength();
                    if (iRecordLength==0) {
                        strKey = null;
                        break;
                    }
                    strRecord = new StringBuffer(strBuffer.substring(iRecordPosition, iRecordPosition + iRecordLength));

                    iRecordPosition += iRecordLength;

                    strAMARecord = new StringBuffer();
                    strAMARecord.append(strRecord);
                    usageRecord = new UsageRecord(strAMARecord, properties);

                    count ++;
                    //aryRecords.add(strAMARecord);
//                    System.out.println(FileReader.getRecordConverted(usageRecord, properties));
                    if (this.outFile != null) {
                        try {
                            convertedRecord = FileReader.getRecordConverted(usageRecord, properties).toString();
                            fileWriter.write(convertedRecord);
                            fileWriter.newLine();
                        } catch (Exception error) {
                            //System.out.println("Error on record: " + iRecordCount + " - " + usageRecord);
                            error.printStackTrace();
                        }
                    } else {
                        aryRecords.add(strAMARecord.toString());
                    }
                    strAMARecord = new StringBuffer();
                    iRecordCount++;

                }

            }
        } catch (Exception error) {
            System.out.println("While: " + error);
            error.printStackTrace();
        }

        try {
            fis.close();
        } catch (Exception error) {
            System.out.println(error);
        }

        usageRecords = new UsageRecord[0];

    }

    @Override
	public String[] getFiles() {
        return new String[0];
    }

}
