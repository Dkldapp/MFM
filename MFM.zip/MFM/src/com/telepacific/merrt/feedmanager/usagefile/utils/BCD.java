/**
 * <p>Title: BCD</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.usagefile.utils;

import com.telepacific.merrt.feedmanager.usagefile.utils.BCD;

public class BCD {
    private int b1, b2;

    public BCD(int b1, int b2) {
        this.b1 = b1;
        this.b2 = b2;
    }

    public BCD(int b) {
        this.b1 = (0xf0 & b) >> 4;
        this.b2 = (0x0f & b);
    }

    static public BCD splitBytes(int word) {
        return new BCD((0xf0 & word) >> 4, (0x0f & word));
    }


    public int getLowOrder() {
        return this.b2;
    }

    public int getHighOrder() {
        return this.b1;
    }

    public int getValue() {
        return (b1 << 4) | b2;
    }

    @Override
	public String toString() {
        return b1 + " " + b2 + " = " + getValue();
    }

    static public int combineBytes(int highByte, int lowByte) {
        return (highByte << 4) | lowByte;
    }

    static public int getHighOrder(int value) {
        return (value & 0xf0) >> 4;
    }

    static public int getLowOrder(int value) {
        return value & 0x0f;
    }

    static public String formatByte(int _byte) {
        String strByte = Integer.toString(_byte);
        switch (_byte) {
            case 10:
                strByte = "a";
                break;
            case 11:
                strByte = "b";
                break;
            case 12:
                strByte = "c";
                break;
            case 13:
                strByte = "d";
                break;
            case 14:
                strByte = "e";
                break;
            case 15:
                strByte = "f";
                break;
        }
        return strByte;
    }

    static public int formatStringToByte(String _byte) {
        if (_byte.equals("a")) {
            return 10;
        }
        if (_byte.equals("b")) {
            return 11;
        }
        if (_byte.equals("c")) {
            return 12;
        }
        if (_byte.equals("d")) {
            return 13;
        }
        if (_byte.equals("e")) {
            return 14;
        }
        if (_byte.equals("f")) {
            return 15;
        }
        return Integer.parseInt(_byte);
    }
}
