/**
 * <p>Title: GeneralFileFilter</p>
 * <p>Description:</p>
 * @author mgokhale
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.utils;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.regex.Pattern;
import java.util.ArrayList;

public class GeneralFileFilter implements FileFilter, FilenameFilter {
    ArrayList<Pattern> patterns = new ArrayList<Pattern>();

    public GeneralFileFilter(String pattern) {
        //
        pattern = pattern.replaceAll("\\*", ".*");
        String[] pats = pattern.split(";");
        for (String pat : pats) {
            this.patterns.add(Pattern.compile(pat.trim()));
        }
        //this.pattern = Pattern.compile(pattern);
    }

    @Override
	public boolean accept(File pathname) {
        boolean rtn = false;
        if (pathname.isDirectory()) {
        } else {
            if (!pathname.getName().toLowerCase().contains("tmp")) {
                if (pathname.length() == 0) {
                    return false;
                }
                for (Pattern p : patterns) {
                    rtn = p.matcher(pathname.getName()).matches();
                    if (rtn) {
                        break;
                    }
                }
            }
            //rtn = pattern.matcher(pathname.getName()).matches();
        }
        return rtn;
    }

    @Override
	public boolean accept(File pathname, String name) {
        boolean rtn = false;
        File path = new File(pathname.getAbsolutePath() + name);
        if (name.toLowerCase().contains("tmp")|| name.toLowerCase().contains("history.log")|| name.toLowerCase().contains("dbout")) {
            return false;
        }

        if (path.isDirectory()) {
        } else {
                if (path.length() == 0) {
//                return false;
                }
                for (Pattern p : patterns) {
                    rtn = p.matcher(name).matches();
                    if (rtn) {
                        break;
                    }
                }
                //rtn = pattern.matcher(pathname.getName()).matches();
        }
        return rtn;
    }
}
