/**
 * <p>Title: StringFormatter</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.utils;

import java.util.Calendar;
import java.util.Date;

public class StringFormatter {
    public StringFormatter() {

    }

    public static String formatIntoHHMMSS(long milliseconds) {
        long secsIn = milliseconds / 1000;
        long hours = secsIn / 3600
          , remainder = secsIn % 3600
          , minutes = remainder / 60
          , seconds = remainder % 60;

        return ((hours < 10 ? "0" : "") + hours
                + ":" + (minutes < 10 ? "0" : "") + minutes
                + ":" + (seconds < 10 ? "0" : "") + seconds);

    }

    public static String formatDateAgo(Date _date) {
        Long date = _date.getTime();
        String latestCall = "n/a";
        long hh;
        long mi;
        long ss;
        long dd;
        long mm;

        if (date != 0) {
            date = new Date().getTime() - date;
            ss = date / 1000;
            mi = ((date / 1000) / 60);
            hh = ((date / 1000) / 60) / 60;
            dd = (((date / 1000) / 60) / 60) / 24;
            mm = ((((date / 1000) / 60) / 60) / 24) / 31;

            if (ss == 0) {
                latestCall = "just now";
            }

            if (ss > 0) {
                latestCall = ss + " sec" + (ss > 1 ? "s" : "") + " ago";
            }
            if (mi > 0) {
                latestCall = mi + " min" + (mi > 1 ? "s" : "") + " ago";
            }
            if (hh > 1) {
                latestCall = hh + " hour" + (hh > 1 ? "s" : "") + " ago";
            }

            if (dd > 1) {
                latestCall = dd + " day" + (dd > 1 ? "s" : "") + " ago";
            }

            if (mm > 1) {
                latestCall = mm + " month" + (mm > 1 ? "s" : "") + " ago";
            }

        }
        return latestCall;

    }
    public static String replaceVariables(String str) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(new Date().getTime());
        //String mm = (cal.get(Calendar.MONTH)<10?"a":"b");
        String mm = (cal.get(Calendar.MONTH) < 10 ? "0" + new Integer(cal.get(Calendar.MONTH) + 1).toString() : new Integer(cal.get(Calendar.MONTH) + 1).toString());
        String dd = (cal.get(Calendar.DATE) < 10 ? "0" + new Integer(cal.get(Calendar.DATE)).toString() : new Integer(cal.get(Calendar.DATE)).toString());
        String yyyy = new Integer(cal.get(Calendar.YEAR)).toString();
        String yy = new Integer(cal.get(Calendar.YEAR)).toString().substring(2, 4);

        str = str.replaceAll("#MM#", mm);
        str = str.replaceAll("#mm#", mm);
        str = str.replaceAll("#DD#", dd);
        str = str.replaceAll("#dd#", dd);
        str = str.replaceAll("#YYYY#", yyyy);
        str = str.replaceAll("#yyyy#", yyyy);
        str = str.replaceAll("#YY#", yy);
        str = str.replaceAll("#yy#", yy);
        return str;
    }
}
