/**
 * <p>Title: UsageFileTool</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.feedmanager.utils;

import java.io.*;

public class UsageFileTool {
    public UsageFileTool() {

    }

    public static boolean isDuplicateFileInLog(File file, File log) {
        boolean rtn = false;
        try {
            BufferedReader input = new BufferedReader(new FileReader(log));

            int iBuffer = 0;
            String record = null;

            while ((record = input.readLine()) != null) {
                iBuffer++;
                if (file.getName().toLowerCase().contains(record.toLowerCase())) {
                    rtn = true;
                }
            }
            input.close();
        } catch (Exception error) {
            error.printStackTrace();
        }
        return rtn;
    }

    public static String getRollFileName(String strFileName) {
        String strFN;

        int iExt = 0;
        String strExt;
        boolean fileExists = false;

        fileExists = new File(strFileName).exists();
        while (fileExists) {
            strFN = strFileName;
            strExt = strFN.substring(strFN.length() - 3, strFN.length());

            if (strExt.startsWith(".")&&!strExt.equals(".99")) {
                try {
                    iExt = Integer.parseInt(strExt.substring(1, 3));
                    iExt = iExt + 1;
                    strExt = Integer.toString(iExt);
                    if (strExt.length() == 1) {
                        strExt = "0" + strExt;
                    }
                    strFN = strFN.substring(0, strFN.length() - 2) + strExt;
                } catch (Exception error) {
                    //is not number
                    strFN = strFN + ".00";
                }
            } else {
                strFN = strFN + ".00";
            }
            fileExists = new File(strFN).exists();
            if (!fileExists) {
                fileExists = new File(strFN + ".gz").exists();
            }
            strFileName = strFN;
        }
        return strFileName;
    }

    public static void copyFile(File in, File out) throws Exception {
        FileInputStream fis = new FileInputStream(in);
        FileOutputStream fos = new FileOutputStream(out);
        byte[] buf = new byte[1024];
        int i = 0;
        while ((i = fis.read(buf)) != -1) {
            fos.write(buf, 0, i);
        }
        fis.close();
        fos.close();
    }

    public static void main(String[] args) {

    }
}
