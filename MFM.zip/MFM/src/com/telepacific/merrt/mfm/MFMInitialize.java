package com.telepacific.merrt.mfm;

import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.URL;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.rmi.RMIConnectorServer;

import org.apache.log4j.Logger;

import com.telepacific.merrt.JMX.CreateManagementLayer;
import com.telepacific.merrt.JMX.FeedProcessJMX;
import com.telepacific.merrt.JMX.FeedProcessJMXMBean;
import com.telepacific.merrt.JMX.MFMJMX;
import com.telepacific.merrt.JMX.MFMJMXMBean;
import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.config.MERRTFeedManagerDAO;
import com.telepacific.merrt.config.MFMConfig;
import com.telepacific.merrt.config.MFMFeedHandlerStatus;
import com.telepacific.merrt.config.MFMStatus;
import com.telepacific.merrt.feedmanager.datafeed.DataFeed;
import com.telepacific.merrt.feedmanager.datafeed.DataFeedManager;
import com.telepacific.merrt.feedmanager.dataprocessor.DataProcessorThread;


public class MFMInitialize {
	
	public static MERRTFeedManagerDAO mfmDAO; 
	public static CreateManagementLayer createManagementLayer;
	public static MFMJMXMBean mbean;
	public static FeedProcessJMXMBean handlerMbean;
	public static MBeanServer mbs;
	public static List<String> listFeedHalderIDbyIPAddress;
	public static List<Integer> listDataFeedListbyMFMID;
	public static Registry registry = null;
	// Map between Data Feed and associated Data Processor Thread
	private static Hashtable<Integer, DataProcessorThread> hmDFDPT = new Hashtable<Integer, DataProcessorThread>();
	private static ArrayList<MFMFeedHandlerStatus> alHandlerStatusObj = new ArrayList<MFMFeedHandlerStatus>();
	static ArrayList<Integer> listFeedHandlerIds = null;
	public static String strIPAddress = null;
	public static boolean isStartJMXServer = true;
	public static boolean isMbeanFeedHandler = true;
	public static String console_display=null;
	public static HashMap<Integer,ObjectName> hmFeedHandlerNames = new HashMap<Integer,ObjectName>();
	public static 	ArrayList <ObjectName> alMBean = new ArrayList<ObjectName> ();
	
	static MFMConfig mfmConfig;
	public static ObjectName mbeanName = null;
	static ObjectName feedProcessMBean;
	static Logger log = Logger.getLogger("MFMInitialize");
	static URL root;
	public static String remoteDrive = null;
	public static String remoteSharedDirectory = null;
	private static boolean shutdown = false;
	void MFMStartup(){
		
	}
	public MFMInitialize(){
		mfmDAO = new MERRTFeedManagerDAO();
		root = getClass().getProtectionDomain().getCodeSource().getLocation();
		MFMInitializeThread();
	//	SS7DropThreadInitialize ss7= new SS7DropThreadInitialize();
	//	ss7.start();
	}
	static void MFMInitializeThread()
	{
	
		MFMStatus mfmStatus;
		
		MFMFeedHandlerStatus mfmfeedHandlerStatus;
				
		
		int mfmID = 0;
		List <MFMConfig> listMFM = null;
		
		int ifeedId = 0;
		log.info("### -----------------------------MERRT Feed Manager Ver 1.0 ----------------###");
		log.info("### Starting MERRT Feed Manager (MFM).... ###");
		try{	
			
			InetAddress address = InetAddress.getLocalHost();
			
			new InitSessionFactory();
			
			 URL propertiesFile = new URL(root, "mfmproperties.properties"); 
			 Properties mfmProperties = new Properties();
			 //FileInputStream in = new FileInputStream(".\\mfmproperties.properties");     
			 mfmProperties.load(propertiesFile.openStream()); 
			 console_display=mfmProperties.getProperty("console_display");
		     
		 	// log.info("Property file Loaded"+propertiesFile.toString());
		 	
			 strIPAddress = mfmProperties.getProperty("ipaddress").trim();
		   
		     log.info("Console Display  :::::" +console_display);
		 	//System.out.println("Console Display  :::::"+console_display);
			 if(console_display.contains("y"))
			 {
				 System.out.println("Property file Loaded ::: "+propertiesFile.getFile()); 
				 log.info("Property file Loaded ::: "+propertiesFile.getFile()); 
			 }
			 log.info("Property file Loaded ::: "+propertiesFile.getFile()); 
		 
			 mfmID = Integer.parseInt(mfmProperties.getProperty("mfmid"));
			 
			log.info("MFM Id :::"+mfmID);
			log.info("### Verifying MERRT Feed Manager registration for IP Address" + strIPAddress + ".");
			 // validating MFM server ip address with configuration data
			if(!strIPAddress.equals(address.getHostAddress())){
				if(console_display.contains("y"))
				{
				System.out.println("### MERRT Feed Manager registration check failed for " + strIPAddress + " . "); 
				System.out.println("Please check MFM configuration and ensure that MFM had be configured to start on a host with IP Address  ");
				}
				
				log.info("### MERRT Feed Manager registration check failed for " + strIPAddress + " . "); 
				log.info("Please check MFM configuration and ensure that MFM had be configured to start on a host with IP Address  ");
				
			} else {
			//	System.out.println("Connected To Database :::: ");
				log.info("### MERRT Feed Manager registration succeded on IP Address " + strIPAddress + ".");
				
				if(console_display.contains("y"))
				{
				System.out.println("### MERRT Feed Manager registration succeded on IP Address " + strIPAddress + ".");
				}
				
				listMFM = mfmDAO.checkRegistration(strIPAddress,mfmID);
				
				// checking MFM configured or not
				
				if (listMFM.size() == 0 ){

					log.info("### MFM Registration failed - invalid MFM ID or IP Address ###");
					
					if(console_display.contains("y"))
					{
					System.out.println("### MFM Registration failed - invalid MFM ID or IP Address ###");
					}
					

				// updating MFM status table	
					mfmStatus = new MFMStatus();
					mfmStatus.setStatus(false);
					mfmStatus.setErrorCode("0001");
					mfmStatus.setMFMId(mfmID);
					//mfmStatus.setDateTime(dateTime);

					mfmDAO.setMFMStartupStatus(mfmStatus);

				} else 
				{
					if(console_display.contains("y"))
					{
					System.out.println("### Loading MFM Configuration from Database ###");
					}
				    log.info("### Loading MFM Configuration from Database ###");
					if("Yes".equalsIgnoreCase(mfmProperties.getProperty("remoteDrive")))
						remoteDrive = mfmProperties.getProperty("mappedDrive");
					
					remoteSharedDirectory = mfmProperties.getProperty("remoteSharedDirectory");
					
					mfmConfig = (MFMConfig) listMFM.get(0);
					
					//Mbean initializing for MFM
					
					
					// if (isStartJMXServer){ // this flag checks the Jconsole agent restart required  or not.
							mbeanName = new ObjectName("MERRT Feed Manager:type= MFM");
						     // Create the MFM MBean
						  mbean = new MFMJMX();
						  
						  mbs = ManagementFactory.getPlatformMBeanServer();
						  alMBean.add(mbeanName);
						  startJMXServer(mfmConfig.getServerIPAddress(),mfmConfig.getJMXPort());
					 
						  
					    // Register the MFM MBean
						  if (! mbs.isRegistered(mbeanName))
							  mbs.registerMBean(mbean, mbeanName);
						  
					  mbean.setMFMID(mfmConfig.getMFMId());
					  mbean.setMFMName(mfmConfig.getMFMName());
					  mbean.setServerLocation(mfmConfig.getServerIPAddress());
					  mbean.setJMXPort(mfmConfig.getJMXPort());  
						    
					log.info("### Loading Feed Handlers list  for MFM_ID "+mfmID);
					if(console_display.contains("y"))
					{
						System.out.println("### Loading Feed Handlers list  for MFM_ID "+mfmID);
					}
					//getting MFM configured handlers list
					listFeedHandlerIds = (ArrayList <Integer>) mfmDAO.getFeedIDListByMFMID(mfmConfig.getMFMId());
					
					// validating feed handler size if zero means, no handler was configured
					
					if (listFeedHandlerIds.size() == 0){
						
						log.info("### No Feed handlers are configured for this MFM ###");
						if(console_display.contains("y"))
						{
						System.out.println("### No Feed handlers are configured for this MFM_id"+mfmID);
						}
						//updating MFM status table	
						mfmStatus = new MFMStatus();
						mfmStatus.setStatus(true);
						mfmStatus.setErrorCode("0002");
						mfmStatus.setMFMId(mfmID);

						mfmDAO.setMFMStartupStatus(mfmStatus);
						
					} else {
						
						
						// initiating data processor threads by using feed handler id 

						DataFeedManager dataFeedMgr = DataFeedManager.getInstance();
						DataFeed dataFeed = null;
						if(console_display.contains("y"))
						{
						System.out.println("MFM - Initilaizing Feed Handlers....... ");
						}
						log.info("### MFM - Initilaizing Feed Handlers....... ###");
						log.info(	"### MFM - No. of Feed handlers Configured  : " + listFeedHandlerIds.size());
						// Create DataProcessorThread for each Feed Handler
						
						if(console_display.contains("y"))
						{
						System.out.println(	"### MFM - No. of Feed handlers Configured  : " + listFeedHandlerIds.size());
						}
						for (int i = 0; i< listFeedHandlerIds.size(); i++)
						{
						
							try {
								ifeedId = listFeedHandlerIds.get(i);
								dataFeed = dataFeedMgr.getDataFeed(ifeedId);
								// created data processor thread using feed handler id
							
								DataProcessorThread dataProcessorThread = new DataProcessorThread(dataFeed);
								// Feed Handler started
								
							   //int f=	dataProcessorThread.getFilesInQueue();
							
						
								dataProcessorThread.start();
							//	dataProcessorThread.join();
								log.info(" The Feed Handler Started for Feed "+dataFeed.getDataFeedName());
								
								if(console_display.contains("y"))
								{
								System.out.println(" The Feed Handler Started for Feed  :: "+dataFeed.getDataFeedName());
								}
								
							
								hmDFDPT.put(ifeedId, dataProcessorThread);
								
								// updating feed handler status table
								
								mfmfeedHandlerStatus = new MFMFeedHandlerStatus();
								mfmfeedHandlerStatus.setMfmID(mfmID);
								mfmfeedHandlerStatus.setFeedID(ifeedId);							
								mfmfeedHandlerStatus.setisRunning(true);
								mfmfeedHandlerStatus.setStatus("RUNNING");
								mfmfeedHandlerStatus.setErrorCode("0004");
								
								if (mfmDAO.isFeedhandlerStatusExist(mfmID, ifeedId)){
									
									mfmDAO.updateMFMFeedHandlerStatus(mfmfeedHandlerStatus);
								} else {
									
									mfmDAO.saveMFMFeedHandlerStatus(mfmfeedHandlerStatus);
								}
								
								alHandlerStatusObj.add(mfmfeedHandlerStatus);
								//hmFeedHandlerStatusObj.put(ifeedId, mfmfeedHandlerStatus);
								
								//if(isMbeanFeedHandler){
									
									feedProcessMBean = new ObjectName("MERRT Feed Manager:type="+dataFeed.getDisplayName());
									hmFeedHandlerNames.put(dataFeed.getDataFeedID(),feedProcessMBean);
						    		// Create the Feed Process MBean
									handlerMbean = new FeedProcessJMX();
								
									// Register the Feed Process MBean
						    		mbs.registerMBean(handlerMbean, feedProcessMBean);
					
						    		// setting MBean values
						    		handlerMbean.setFeedHandlerID(dataFeed.getDataFeedID());
						    		handlerMbean.setFeedHandlerName(dataFeed.getDisplayName());
						    		handlerMbean.setLastProcessedFeedFile(dataProcessorThread.getLastStatusDate());
						    		handlerMbean.setFolderName(dataProcessorThread.getDataFeed().getPath());
						    		handlerMbean.setServerLocation(address.getHostAddress());
						    		handlerMbean.setFeedHandlerStatus("RUNNING");
						    		DataProcessorThread.setFeedProcessJMXBean(handlerMbean);
							}
							catch (Exception e) {
								
								log.error("Problem in starting thread for Feed ID " + ifeedId+" Error Message"+e);
								if(console_display.contains("y"))
								{
								//	System.out.println("Problem in starting thread for Feed ID " + ifeedId+" Error Message"+e);
								}
								
							}
					    		
						}
						log.info("### MFM - Successfully started Feed handlers ");
					
						log.info("### MFM - No. of Feed handlers : " + listFeedHandlerIds.size() + "");
						if(console_display.contains("y"))
						{
						System.out.println("### MFM - Successfully started Feed handlers ");
						System.out.println(	"### MFM - No. of Feed handlers Successfully Started : " + listFeedHandlerIds.size());
						}
						
						// updating MFM status table
						mfmStatus = new MFMStatus();
						mfmStatus.setStatus(true);
						mfmStatus.setErrorCode("0003");
						mfmStatus.setMFMId(mfmID);
						
						mfmDAO.setMFMStartupStatus(mfmStatus);
						
						
					}
				} 
				log.info("### MERRT Feed Manager (MFM)Startup completed... ###");
				if(console_display.contains("y"))
				{
				System.out.println("### MERRT Feed Manager (MFM)Startup completed... ###");
				}
			} 
		}
		catch(Exception e){
			//e.printStackTrace();\
		
		
			log.info("### MERRT Feed Manager (MFM)Startup Failed :: Error "+e.toString());
		//	log.error("Feed Manager Startup Error "+e.toString());
			}
			
		}
	
		 
	
	/* startJMXServer method is used to start jMX agent.
	 *  
	 */
    static void startJMXServer(String strIPAddress, int iPortNo){
    	
    	HashMap<String, Object> env = new HashMap<String, Object>(1);
    	try{
    		if(console_display.contains("y"))
			{
    			System.out.println("### Jconsole MBean Server starting... ###");

			}
    		  log.info("### Jconsole MBean Server starting... ###");
    		
    		   env.put(RMIConnectorServer.JNDI_REBIND_ATTRIBUTE, "true");
    		   if (isStartJMXServer)
    		   registry = LocateRegistry.createRegistry(iPortNo);
    		   
    		   
    	        JMXServiceURL url =
    	            new JMXServiceURL("service:jmx:rmi://"+strIPAddress+
    	            ":"+iPortNo+"/jndi/rmi://"+strIPAddress+":"+iPortNo+"/jmxrmi");
    	        final JMXConnectorServer cnnectorServer =
    	                JMXConnectorServerFactory.newJMXConnectorServer(url, env, mbs);
    	        cnnectorServer.start();  
    	        
    	        isStartJMXServer = false;
    	        
    	        if(console_display.contains("Y"))
    			{
    	        	System.out.println("### Jconsole MBean Server started. ###");
    			}
		    log.info("### Jconsole MBean Server started. ###");
		    
    	} catch (Exception e){
    		//e.printStackTrace();
    		log.error("Excption in Starting JMX "+e.toString());
    		  if(console_display.contains("Y"))
  			{
    			  System.out.println("Excption in Starting JMX "+e.toString());
  			}
    	}
    }
    
    /*
     *  MFMShutDown method is used for stopping MERRT Feed Manager and associated Feed handlers
     *  
     *  
     */
	public static void mfmShutDown()
	{
		MFMFeedHandlerStatus mfmfeedHandlerStatus;
		isStartJMXServer = false;
		isMbeanFeedHandler = false;
		if(console_display.contains("y"))
		{
		System.out.println("Stopping MERRT Feed Manager.....");
		System.out.println("Stopping  Feed Handlers.....");
		}
		log.info("### Stopping MERRT Feed Manager..... ###");
		try {
			
			//stopping thread one by one.
			
			for (int i=0; i<alHandlerStatusObj.size(); i++){
				
				mfmfeedHandlerStatus = (MFMFeedHandlerStatus) alHandlerStatusObj.get(i);
				
				mfmfeedHandlerStatus.setisRunning(false);
				mfmfeedHandlerStatus.setStatus("STOPPED");
				
				mfmDAO.updateMFMFeedHandlerStatus(mfmfeedHandlerStatus);
				
			//	hmDFDPT.get(mfmfeedHandlerStatus.getFeedID()).stopProcess();
				DataProcessorThread th= hmDFDPT.get(mfmfeedHandlerStatus.getFeedID());
				if(th==null)
				{
				//	log.info("Thread is "+th.getId());
				}else
				{
					th.stopProcess();
				}
				
				hmDFDPT.remove(mfmfeedHandlerStatus.getFeedID());
			}
			

			for (int i=0; i<listFeedHandlerIds.size();i++){
				if(hmFeedHandlerNames.get(listFeedHandlerIds.get(i))!=null){
				mbs.unregisterMBean(hmFeedHandlerNames.get(listFeedHandlerIds.get(i)));
				}
			
			}
			
			
			//if (mbeanName != null)
			//if (mbs.isRegistered(alMBean.get(0)))
			mbs.unregisterMBean(mbeanName);
			
			mbs = null;
			
			if(console_display.contains("y"))
			{
			System.out.print("Stopped Feed Handlers.....");
			System.out.print("Stopped MERRT Feed Manager.");
			log.info("### Stopped MERRT Feed Manager. ###");
			}
			//System.exit(0);
		}catch (Exception e){
			log.error(" MFMShutDown "+e.toString());
			//e.printStackTrace();
		}
	}
	
    /*
     *  MFMRestart method is used for restarting of MERRT Feed Manager and associated Feed handlers
     *  
     */
	
	public static void mfmRestart(){
		
		if(console_display.contains("y"))
		{
        System.out.println("Restarting MERRT Feed Manager.....");
		}
		log.info("Restarting MERRT Feed Manager.....");
		
		try {
			//log.info("MERRT Feed Manager Stopping...");
			// shutdown the MFM server and associated Feed handlers
			mfmShutDown();
			//log.info("MERRT Feed Manager Stopped.");
			// MFM Restarting of MFM and associated Feed handlers
			MFMInitializeThread();
			
			log.info("MERRT Feed Manager Started...");
			if(console_display.contains("y"))
			{
			System.out.println("MERRT Feed Manager Started...");
			}
			log.info("Ready for Processing File.");

			
		}catch (Exception e){
			log.error(e.toString());
		}
	}
	
	public static void feedHandlerRestart(int iDataFeed){
		
		log.info("Restarting Feed Handler.....");
		
		
		try {
			DataFeedManager dataFeedMgr = DataFeedManager.getInstance();
			DataFeed dataFeed = dataFeedMgr.getDataFeed(iDataFeed);
			//hmDFDPT
			if(console_display.contains("y"))
			{
			System.out.println("Feed Handler Stopping ::::"+dataFeed.getDataFeedName());
			}
			log.info("Feed Handler Stopping ::::"+dataFeed.getDataFeedName());
			feedHandlerStop(iDataFeed);
			log.info("Feed Handler Stopped ::: "+dataFeed.getDataFeedName());
			if(console_display.contains("y"))
			{
			System.out.println("Feed Handler Stopped ::: "+dataFeed.getDataFeedName());
			}
			log.info("Restarting Feed Handler:::"+dataFeed.getDataFeedName());
			if(console_display.contains("y"))
			{
			System.out.println("Restarting Feed Handler:::"+dataFeed.getDataFeedName());
			}
			
			
			// MFM Restarting of MFM and associated Feed handlers
			feedHandlerStart(iDataFeed);
			
			log.info("Feed Handler Started..."+dataFeed.getDataFeedName());
			if(console_display.contains("y"))
			{
			System.out.println("Feed Handler Started..."+dataFeed.getDataFeedName());
			}
			log.info("Ready for Processing File.");

			
		}catch (Exception e){
			log.error(" feedHandlerRestart "+e.toString());
		}
	}
	public static void feedHandlerStop(int iDataFeed){
		
		MFMFeedHandlerStatus mfmfeedHandlerStatus = null;
		try {
			DataFeedManager dataFeedMgr = DataFeedManager.getInstance();
			DataFeed dataFeed = dataFeedMgr.getDataFeed(iDataFeed);
			hmDFDPT.get(iDataFeed).stopProcess();
			
             log.info(" The Feed Handler Stopped  "+dataFeed.getDataFeedName());
             if(console_display.contains("Y"))
			{
			System.out.println(" The Feed Handler Stopped  :: "+dataFeed.getDataFeedName());
			}
			for(int i=0; i< alHandlerStatusObj.size();i++){
				if (alHandlerStatusObj.get(0).getFeedID() == iDataFeed)
					mfmfeedHandlerStatus = (MFMFeedHandlerStatus) alHandlerStatusObj.get(i);
				}
			mfmfeedHandlerStatus.setisRunning(false);
			mfmfeedHandlerStatus.setStatus("STOPPED");
			
			mfmDAO.updateMFMFeedHandlerStatus(mfmfeedHandlerStatus);

			hmDFDPT.remove(iDataFeed);
			mbs.unregisterMBean(hmFeedHandlerNames.get(iDataFeed));
			if(console_display.contains("y"))
			{
			System.out.println("Feed Handles Stopped for Feed Id "+iDataFeed);
			}
			
		}catch (Exception e){
			log.error(" Error in  feedHandlerStop for Feed id  "+iDataFeed+" Error Msg :::,"+e.toString());
			if(console_display.contains("y"))
			{
			System.out.println(" Error in  feedHandlerStop for Feed id  "+iDataFeed+" Error Msg :::,"+e.toString());
			}
		}
	}

	public static void feedHandlerStart(int ifeedId){
		
		
		try {

			DataFeedManager dataFeedMgr = DataFeedManager.getInstance();
			DataFeed dataFeed = dataFeedMgr.getDataFeed(ifeedId);

			DataProcessorThread dataProcessorThread = new DataProcessorThread(dataFeed);
			dataProcessorThread.start();
			log.info(" The Feed Handler Started for Feed "+dataFeed.getDataFeedName());
			if(console_display.contains("y"))
			{
			System.out.println(" The Feed Handler Started for feed  :: "+dataFeed.getDataFeedName());
			}
			
			hmDFDPT.put(dataFeed.getDataFeedID(), dataProcessorThread);
			
			feedProcessMBean = new ObjectName("MERRT Feed Manager:type="+dataFeed.getDisplayName());
			hmFeedHandlerNames.put(dataFeed.getDataFeedID(),feedProcessMBean);
    		// Create the Feed Process MBean
			handlerMbean = new FeedProcessJMX();
		
			// Register the Feed Process MBean
    		mbs.registerMBean(handlerMbean, feedProcessMBean);

    		// setting MBean values
    		handlerMbean.setFeedHandlerID(dataFeed.getDataFeedID());
    		handlerMbean.setFeedHandlerName(dataFeed.getDisplayName());
    		handlerMbean.setLastProcessedFeedFile(dataProcessorThread.getLastStatusDate());
    		handlerMbean.setFolderName(dataProcessorThread.getDataFeed().getPath());
    		handlerMbean.setServerLocation(mfmConfig.getServerIPAddress());
    		handlerMbean.setFeedHandlerStatus("RUNNING");
    		
    		DataProcessorThread.setFeedProcessJMXBean(handlerMbean);
			
			
		}catch (Exception e){
			log.error(" Error in  feedHandlerStart for Feed id  "+ifeedId+" Error Msg :::,"+e.toString());
			if(console_display.contains("y"))
			{
			System.out.println(" Error in  feedHandlerStart for Feed id  "+ifeedId+" Error Msg :::,"+e.toString());
			}
		}
	}
	
	public static void StartMFM(){
		
		System.out.println("Starting MERRT Feed Manager 1.0..... ");
		
		System.out.println("MERRT Feed Manager Started...");
		new MFMInitialize();
		
		//System.out.println("Ready for Processing File.");
		System.out.println("Please connect to MFM using JConsole to view the health of MFM.");
		System.out.println("Press ctrl + c to stop MERRT Feed Manager.. ");
		Runtime.getRuntime().addShutdownHook(
				new Thread(){ 
					public void run() {
						mfmShutDown(); }
				}
				
				);
	}
	
	public static void main (String[] args)
	{
         MFMInitialize.StartMFM();
	}
	
}
