package com.telepacific.merrt.mfm;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;





public class SS7DropThreadInitialize extends Thread {
	
	static Logger log = Logger.getLogger(SS7DropThreadInitialize.class);
	private static SS7DropThreadInitialize instance = null;

    private static String url = "jdbc:sqlserver://netdw.telepacific.com:1433;DatabaseName=ss7;SelectMethod=cursor";
    private static String username = "networkdwqa";
    private static String password = "networkdwqa"; 
   
	Connection conn=null;
  	ResultSet rs =null;
  	Statement stmt=null;
  
	
	
	 //private boolean doRun = false;
public static SS7DropThreadInitialize getInstance() {
	
		
	 log.info(" SS7 Drop  ThreadInitialize thread started");
		if(instance == null) {
			instance = new SS7DropThreadInitialize();
			
		}
		//instance.getSleepTime();
        return instance;
	}
  public SS7DropThreadInitialize() {
	// TODO Auto-generated constructor stub
	//  start();
}
	
  public void dropSS7tables() throws SQLException, ClassNotFoundException
	 {
		 
	  log.info(" Drop Table Start  ");
	  String inputTableQA = "tbl_merrt_transfer_queue_qa";
	  String inputTablePD = "tbl_merrt_transfer_queue";
	  String where = "PENDING_DROP=1";
	  String dateTransferedQA = null;
	  String dateTransferedPD = null;
	  String databaseTable=null;
	//  String databaseTableQA=null;
	//  String databaseTablePD=null;
	 try
	 {
		 

   	  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		 
      conn = DriverManager.getConnection(url, username, password);
      log.info(" Database connected ");
	
		try
		{

			stmt = conn.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM " + inputTableQA
					+ "WHERE  " +where);
	 while (rs.next()) {
				
				//dateTransferedQA=   rs.getString("DATE_TRANSFERED");
				databaseTable  =  rs.getString("TABLE_NAME");
			
		try
		{

			stmt = conn.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM " + inputTableQA+ " where TABLE_NAME=" +databaseTable);
			while (rs.next()) {
				
				dateTransferedQA=   rs.getString("DATE_TRANSFERED");
				//databaseTableQA  =  rs.getString("TABLE_NAME");
			}
			
			
		}
		catch(SQLException s)
		{
			log.error("SQL exception 1 "+s);
		}

		try
		{

			stmt = conn.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM " + inputTablePD+" WHERE TABLE_NAME="+databaseTable);
			while (rs.next()) {
				
				dateTransferedPD  = rs.getString("DATE_TRANSFERED");
				//databaseTablePD   = rs.getString("TABLE_NAME");
				
			}
			
			
		}
		catch(SQLException sq)
		{
			log.error("SQL exception 2 "+sq);
		}
		
		if (dateTransferedPD!=null && dateTransferedQA!=null)
		{
			
			try
			{
				Statement  stmt = conn.createStatement();
				int isDrop = stmt.executeUpdate("DROP TABLE " + databaseTable);
				if (isDrop>0)
				{
				//log.info("The database  table "+databaseTable+" is  Deleted")
			    stmt = conn.createStatement();
				int isUpdated = stmt.executeUpdate("UPDATE " + inputTableQA+" set PENDING_DROP=0 WHERE TABLE_NAME="+databaseTable);
				if(isUpdated>0)
				{
					log.info("The database  table "+databaseTable+" is Dropped and Updated with PENDING_DROP=0  ");
				}  else
					
				{
					log.info("The database  table "+databaseTable+" is not  Updated with PENDING_DROP=0  ");
				}
						
				}
				else
				{
					log.info("The database  table "+databaseTable+" is not  Dropped" );
				}
			}
			catch(SQLException e)
			{
				log.error("SQL exception in deleting table  "+databaseTable+" error is :::  "+e);
			}
			
			
		}
       
	 }
			
	}
		catch(SQLException s)
		{
			log.error("SQL exception  "+s);
		}
		
		
     }
       catch(Exception Ex)
      {
    	   log.error(" Error in drop tables Method  "+Ex.toString());
      }
      finally
      {
      	if (rs!=null){rs.close();}
      
      	if(stmt!=null){stmt.close();}
      
      	if(conn!=null){conn.close();}
      	
      }
		 
	 }
  

	public void run() {
     	 
    	try {
    		while(true) {
    			
    		dropSS7tables();
    			// Thread will run for every 1 mminutes 
    			sleep(60000);
    		}
		} catch (Exception e) {
		
			log.error("Thread Interrupt Exception"+e);
		}
    }

  
//	public void run()
//
//	{
//
//		 System.out.println(" ThreadIniialize thread started ");
//       
//       
//    try {
//    	//  Calling getTableStatus Method to get Latest two records from Table TBL_TABLE_INDEX_RECORD_UPDATE_LOG  
//    	  Thread.sleep(20000);
//    	getTablestatus();
//        //sleep(60000);    
//        }
//    catch (Exception error) {
//    	 System.out.println("Error in Thread"+error);
//            error.printStackTrace();
//        }
//       
//	 }
	 public static void main (String args[])
	 {
		// System.out.println ("Main Method");
		//SS7DropThreadInitialize.getInstance();
		// sleep(30000);
		 
	 }

  }
