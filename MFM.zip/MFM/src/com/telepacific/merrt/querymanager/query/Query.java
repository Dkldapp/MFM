/**
 * <p>Title: Query</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.query;

import java.util.Date;

public class Query {
    private int queryID;
    private String owner;
    private int queryTypeID;
    private String queryName;
    private String queryDesc;
    private Integer dataTypeID;
    private boolean autoRun;
    private boolean publicQuery;
    private int runIndex;
    private String queryText;
    private String outputTable;
    private boolean dropBefore;
    private Date dateActive;
    private Date dateInactive;
    private Date dateCreated;
    private Date dateLastModified;
    private String lastModifiedBy;
    private Date dateFrom;
    private Date dateTo;

    public Query() {

    }


    public Date getDateActive() {
        return dateActive;
    }

    public void setDateActive(Date dateActive) {
        this.dateActive = dateActive;
    }

    public Integer getDataTypeID() {
        return dataTypeID;
    }

    public void setDataTypeID(Integer dataTypeID) {
        this.dataTypeID = dataTypeID;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateInactive() {
        return dateInactive;
    }

    public void setDateInactive(Date dateInactive) {
        this.dateInactive = dateInactive;
    }

    public Date getDateLastModified() {
        return dateLastModified;
    }

    public void setDateLastModified(Date dateLastModified) {
        this.dateLastModified = dateLastModified;
    }

    public boolean isDropBefore() {
        return dropBefore;
    }

    public void setDropBefore(boolean dropBefore) {
        this.dropBefore = dropBefore;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getOutputTable() {
        return outputTable;
    }

    public void setOutputTable(String outputTable) {
        this.outputTable = outputTable;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getQueryDesc() {
        return queryDesc;
    }

    public void setQueryDesc(String queryDesc) {
        this.queryDesc = queryDesc;
    }

    public int getQueryID() {
        return queryID;
    }

    public void setQueryID(int queryID) {
        this.queryID = queryID;
    }

    public String getQueryName() {
        return queryName;
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    public String getQueryText() {
        return queryText;
    }

    public void setQueryText(String queryText) {
        this.queryText = queryText;
    }

    public int getQueryTypeID() {
        return queryTypeID;
    }

    public void setQueryTypeID(int queryTypeID) {
        this.queryTypeID = queryTypeID;
    }

    public int getRunIndex() {
        return runIndex;
    }

    public void setRunIndex(int runIndex) {
        this.runIndex = runIndex;
    }

    public boolean isAutoRun() {
        return autoRun;
    }

    public void setAutoRun(boolean autoRun) {
        this.autoRun = autoRun;
    }

    public boolean isPublicQuery() {
        return publicQuery;
    }

    public void setPublicQuery(boolean publicQuery) {
        this.publicQuery = publicQuery;
    }


    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public String getOutputTableName() {
        String str = this.getOutputTable();
        if (str.indexOf(".") == -1) {
            str = "usagesearch.dbo." + str;
        }
        str = str.substring(str.indexOf(".") + 5, str.length());
        return str;
    }

    public String getOutputTableDatabase() {
        String str = this.getOutputTable();
        if (str.indexOf(".") == -1) {
            str = "usagesearch.dbo." + str;
        }
        str = str.substring(0, str.indexOf("."));
        return str;
    }
}
