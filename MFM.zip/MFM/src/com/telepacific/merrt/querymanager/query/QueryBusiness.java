/**
 * <p>Title: QueryBusiness</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.query;

import com.telepacific.merrt.querymanager.query.Query;
import com.telepacific.merrt.querymanager.query.QueryBusiness;
import com.telepacific.merrt.querymanager.query.QueryCache;
import com.telepacific.merrt.querymanager.query.QueryDAO;
import com.telepacific.merrt.querymanager.query.QueryManager;

public class QueryBusiness implements QueryManager {
    private QueryManager dao;
    private QueryManager cache;

    private static QueryManager instance = null;

    public static QueryManager getInstance() {
        if (instance == null) {
            instance = new QueryBusiness();
        }
        return instance;
    }

    private QueryBusiness() {
        this.reload();
    }

    @Override
	public Query[] getQuery() {
        return cache.getQuery();
    }

    @Override
	public Query getQuery(int queryID) {
        return cache.getQuery(queryID);
    }


    @Override
	public Query[] getQueryByOwner(String owner) {
        return cache.getQueryByOwner(owner);
    }

    @Override
	public Query[] getQueryByQueryTypeID(int queryTypeID) {
        return cache.getQueryByQueryTypeID(queryTypeID);
    }


    @Override
	public Query[] getQueryPublic() {
        return cache.getQueryPublic();
    }

    @Override
	public Query[] getQueryAutoRun() {
        return cache.getQueryAutoRun();
    }

    @Override
	public void reload() {
        cache = new QueryCache();
        dao = new QueryDAO();
        for (Query query : dao.getQuery()) {
            if (query.getDateInactive()==null) {
                cache.setQuery(query);
            }
        }
    }

    @Override
	public Query setQuery(Query query) {
        query = dao.setQuery(query);
        cache.setQuery(query);
        return query;
    }


    @Override
	public void delete(Query query) {
        dao.delete(query);
        cache.delete(query);
    }
}
