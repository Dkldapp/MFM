/**
 * <p>Title: QueryCache</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.query;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;

import com.telepacific.merrt.querymanager.query.Query;
import com.telepacific.merrt.querymanager.query.QueryManager;

public class QueryCache implements QueryManager {
    private Hashtable<Integer, Query> querys;
    private Hashtable<Integer, Hashtable<Integer, Query>> querysByQueryTypeID;
    private Hashtable<Integer, Query> querysByPublicQuery;
    private Hashtable<Integer, Query> querysByAutoRun;
    private Hashtable<String, Hashtable<Integer, Query>> querysByOwner;

    public QueryCache() {
        this.reload();
    }

    @Override
	public Query[] getQuery() {
        Query[] rtn = querys.values().toArray(new Query[querys.size()]);
        Arrays.sort(rtn, new Comparator<Query>() {
            @Override
			public int compare(Query o1, Query o2) {
                return o1.getQueryName().compareTo(o2.getQueryName());
            }
        });

        return rtn;
    }

    @Override
	public Query getQuery(int queryID) {
        return querys.get(queryID);
    }


    @Override
	public Query[] getQueryByOwner(String owner) {
        Hashtable<Integer, Query> list;
        if (querysByOwner.containsKey(owner)) {
            list = querysByOwner.get(owner);
        } else {
            list = new Hashtable<Integer, Query>();
        }
        Query[] rtn = list.values().toArray(new Query[list.size()]);
        Arrays.sort(rtn, new Comparator<Query>() {
            @Override
			public int compare(Query o1, Query o2) {
                return new Integer(o2.getQueryID()).compareTo(new Integer(o1.getQueryID()));
            }
        });

        return rtn;
    }

    @Override
	public Query[] getQueryByQueryTypeID(int queryTypeID) {
        Hashtable<Integer, Query> list;
        if (querysByQueryTypeID.containsKey(queryTypeID)) {
            list = querysByQueryTypeID.get(queryTypeID);
        } else {
            list = new Hashtable<Integer, Query>();
        }
        Query[] rtn = list.values().toArray(new Query[list.size()]);
        Arrays.sort(rtn, new Comparator<Query>() {
            @Override
			public int compare(Query o1, Query o2) {
                return new Integer(o2.getQueryID()).compareTo(new Integer(o1.getQueryID()));
            }
        });

        return rtn;
    }

    @Override
	public Query[] getQueryPublic() {
        Query[] rtn = querysByPublicQuery.values().toArray(new Query[querysByPublicQuery.size()]);
        Arrays.sort(rtn, new Comparator<Query>() {
            @Override
			public int compare(Query o1, Query o2) {
                return new Integer(o2.getQueryID()).compareTo(new Integer(o1.getQueryID()));
            }
        });

        return rtn;
    }

    @Override
	public Query[] getQueryAutoRun() {
        Query[] rtn = querysByAutoRun.values().toArray(new Query[querysByAutoRun.size()]);
        Arrays.sort(rtn, new Comparator<Query>() {
            @Override
			public int compare(Query o1, Query o2) {
                return new Integer(o1.getRunIndex()).compareTo(new Integer(o2.getRunIndex()));
            }
        });

        return rtn;

    }

    @Override
	public void reload() {
        querys = new Hashtable<Integer, Query>();
        querysByQueryTypeID = new Hashtable<Integer, Hashtable<Integer, Query>>();
        querysByOwner = new Hashtable<String, Hashtable<Integer, Query>>();
        querysByAutoRun = new Hashtable<Integer, Query>();
        querysByPublicQuery = new Hashtable<Integer, Query>();
    }

    @Override
	public synchronized Query setQuery(Query query) {
        querys.put(query.getQueryID(), query);
        Hashtable<Integer, Query> queryQueryTypeList;
        if (querysByQueryTypeID.containsKey(query.getQueryTypeID())) {
            queryQueryTypeList = querysByQueryTypeID.get(query.getQueryTypeID());
        } else {
            queryQueryTypeList = new Hashtable<Integer, Query>();
        }
        if (queryQueryTypeList.containsKey(query.getQueryID())) {
            queryQueryTypeList.remove(query.getQueryID());
        }

        queryQueryTypeList.put(query.getQueryID(), query);

        if (query.isAutoRun()) {
            if (querysByAutoRun.containsKey(query.getQueryID())) {
                synchronized (querysByAutoRun) {
                    querysByAutoRun.remove(query.getQueryID());
                }
            }
            synchronized (querysByAutoRun) {
                querysByAutoRun.put(query.getQueryID(), query);
            }
        }

        if (query.isPublicQuery()) {
            if (querysByPublicQuery.containsKey(query.getQueryID())) {
                synchronized(querysByPublicQuery) {
                    querysByPublicQuery.remove(query.getQueryID());
                }
            }
            synchronized (querysByPublicQuery) {
                querysByPublicQuery.put(query.getQueryID(), query);
            }
        }

//        System.out.println(query.isPublicQuery());
        querysByQueryTypeID.put(query.getQueryTypeID(), queryQueryTypeList);

        Hashtable<Integer, Query> queryOwnerList;
        if (querysByOwner.containsKey(query.getOwner())) {
            queryOwnerList = querysByOwner.get(query.getOwner());
        } else {
            queryOwnerList = new Hashtable<Integer, Query>();
        }
        Query rm = null;
        if (queryOwnerList.containsKey(query.getQueryID())) {
            queryOwnerList.remove(query.getQueryID());
        }

        queryOwnerList.put(query.getQueryID(), query);

        querysByOwner.put(query.getOwner(), queryOwnerList);

        return query;
    }


    @Override
	public void delete(Query query) {
        querys.remove(query.getQueryID());
        Hashtable<Integer, Query> queryOwnerList;
        if (querysByOwner.containsKey(query.getOwner())) {
            queryOwnerList = querysByOwner.get(query.getOwner());
        } else {
            queryOwnerList = new Hashtable<Integer, Query>();
        }
        if (queryOwnerList.containsKey(query.getQueryID())) {
            queryOwnerList.remove(query.getQueryID());
        }
        if (querysByAutoRun.containsKey(query.getQueryID())) {
            synchronized (querysByAutoRun) {
                querysByAutoRun.remove(query.getQueryID());
            }
        }
        if (querysByPublicQuery.containsKey(query.getQueryID())) {
            synchronized (querysByPublicQuery) {
                querysByPublicQuery.remove(query.getQueryID());
            }
        }
        Hashtable<Integer, Query> queryQueryTypeList;
        if (querysByQueryTypeID.containsKey(query.getQueryTypeID())) {
            queryQueryTypeList = querysByQueryTypeID.get(query.getQueryTypeID());
        } else {
            queryQueryTypeList = new Hashtable<Integer, Query>();
        }
        if (queryQueryTypeList.containsKey(query.getQueryID())) {
            queryQueryTypeList.remove(query.getQueryID());
        }


    }
}
