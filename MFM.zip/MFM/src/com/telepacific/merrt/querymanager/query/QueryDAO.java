/**
 * <p>Title: QueryDAO</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.query;

import com.telepacific.merrt.config.InitSessionFactory;
import  com.telepacific.merrt.querymanager.query.Query;
import  com.telepacific.merrt.querymanager.query.QueryManager;

import org.apache.log4j.Logger;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.*;


public class QueryDAO implements QueryManager {
    public QueryDAO() {

    }
    Logger log = Logger.getLogger(QueryDAO.class);
    @Override
	public Query[] getQuery() {
        log.info("########QueryManagerDAO.getQuery()########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from Query as u").list();
        tx.commit();
        Query[] rtn = (Query[]) data.toArray(new Query[data.size()]);
        Arrays.sort(rtn, new Comparator<Query>() {
            @Override
			public int compare(Query o1, Query o2) {
                return o2.getQueryName().compareTo(o1.getQueryName());
            }
        });
        return rtn;
    }

    @Override
	public Query getQuery(int queryID) {
        return null;
    }


    @Override
	public Query[] getQueryByOwner(String owner) {
        return new Query[0];
    }


    @Override
	public Query[] getQueryPublic() {
        return new Query[0];
    }

    @Override
	public Query[] getQueryAutoRun() {
        return new Query[0];
    }

    @Override
	public Query[] getQueryByQueryTypeID(int queryTypeID) {
        return new Query[0];
    }

    @Override
	public void reload() {

    }

    @Override
	public Query setQuery(Query query) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (query.getQueryID() <= 0) {
                session.save(query);
            } else {
                session.update(query);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return query;
    }

    @Override
	public void delete(Query query) {
        query.setDateInactive(new Date());
        this.setQuery(query);
/*        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(query);
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        */
    }
}
