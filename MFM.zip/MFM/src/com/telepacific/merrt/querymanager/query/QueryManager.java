/**
 * <p>Title: QueryManager</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.query;

import  com.telepacific.merrt.querymanager.query.Query;

public interface QueryManager {
    public Query[] getQuery();

    public Query[] getQueryByOwner(String owner);

    public Query[] getQueryPublic();

    public Query[] getQueryAutoRun();

    public Query[] getQueryByQueryTypeID(int queryTypeID);

    public Query getQuery(int queryID);

    public Query setQuery(Query query);

    public void reload();

    public void delete(Query query);
}
