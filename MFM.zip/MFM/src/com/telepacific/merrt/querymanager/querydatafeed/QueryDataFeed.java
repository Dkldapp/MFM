/**
 * <p>Title: QueryDataFeed</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.querydatafeed;

public class QueryDataFeed {
    private int queryDataFeedID;
    private int queryID;
    private int dataFeedID;

    public QueryDataFeed() {

    }

    public int getDataFeedID() {
        return dataFeedID;
    }

    public void setDataFeedID(int dataFeedID) {
        this.dataFeedID = dataFeedID;
    }

    public int getQueryDataFeedID() {
        return queryDataFeedID;
    }

    public void setQueryDataFeedID(int queryDataFeedID) {
        this.queryDataFeedID = queryDataFeedID;
    }

    public int getQueryID() {
        return queryID;
    }

    public void setQueryID(int queryID) {
        this.queryID = queryID;
    }
}
