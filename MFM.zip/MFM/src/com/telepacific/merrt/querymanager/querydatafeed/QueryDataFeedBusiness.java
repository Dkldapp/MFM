/**
 * <p>Title: QueryDataFeedBusiness</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.querydatafeed;

import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeed;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeedBusiness;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeedCache;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeedDAO;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeedManager;

public class QueryDataFeedBusiness implements QueryDataFeedManager {
    private QueryDataFeedManager dao;
    private QueryDataFeedManager cache;

    private static QueryDataFeedManager instance = null;

    public static QueryDataFeedManager getInstance() {
        if (instance == null) {
            instance = new QueryDataFeedBusiness();
        }
        return instance;
    }

    private QueryDataFeedBusiness() {
        this.reload();
    }

    @Override
	public QueryDataFeed[] getQueryDataFeed() {
        return cache.getQueryDataFeed();
    }

    @Override
	public QueryDataFeed getQueryDataFeed(int queryID) {
        return cache.getQueryDataFeed(queryID);
    }


    @Override
	public QueryDataFeed[] getQueryDataFeedByDataFeedID(int dataFeedID) {
        return cache.getQueryDataFeedByDataFeedID(dataFeedID);
    }

    @Override
	public QueryDataFeed[] getQueryDataFeedByQueryID(int queryID) {
        return cache.getQueryDataFeedByQueryID(queryID);
    }

    @Override
	public void reload() {
        cache = new QueryDataFeedCache();
        dao = new QueryDataFeedDAO();
        for (QueryDataFeed query : dao.getQueryDataFeed()) {
            cache.setQueryDataFeed(query);
        }
    }

    @Override
	public QueryDataFeed setQueryDataFeed(QueryDataFeed query) {
        query = dao.setQueryDataFeed(query);
        cache.setQueryDataFeed(query);
        return query;
    }


    @Override
	public void delete(QueryDataFeed query) {
        dao.delete(query);
        cache.delete(query);

    }
}
