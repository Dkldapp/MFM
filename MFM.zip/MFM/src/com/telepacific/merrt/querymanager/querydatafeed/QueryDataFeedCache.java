/**
 * <p>Title: QueryDataFeedCache</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.querydatafeed;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeed;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeedManager;

public class QueryDataFeedCache implements QueryDataFeedManager{
    private Hashtable<Integer, QueryDataFeed> queryDataFeeds;
    private Hashtable<Integer, ArrayList<QueryDataFeed>> queryDataFeedsByDataFeedID;
    private Hashtable<Integer, ArrayList<QueryDataFeed>> queryDataFeedsByQueryID;

    public QueryDataFeedCache() {
        this.reload();
    }

    @Override
	public QueryDataFeed[] getQueryDataFeed() {
        QueryDataFeed[] rtn = queryDataFeeds.values().toArray(new QueryDataFeed[queryDataFeeds.size()]);
/*        Arrays.sort(rtn, new Comparator<QueryDataFeed>() {
            public int compare(QueryDataFeed o1, QueryDataFeed o2) {
                return o1.getQueryID().compareTo(o2.getQueryDataFeedName());
            }
        });
*/
        return rtn;
    }

    @Override
	public QueryDataFeed getQueryDataFeed(int queryDataFeedID) {
        return queryDataFeeds.get(queryDataFeedID);
    }

    @Override
	public void reload() {
        queryDataFeeds = new Hashtable<Integer, QueryDataFeed>();
        queryDataFeedsByDataFeedID = new Hashtable<Integer, ArrayList<QueryDataFeed>>();
        queryDataFeedsByQueryID = new Hashtable<Integer, ArrayList<QueryDataFeed>>();
    }

    @Override
	public QueryDataFeed setQueryDataFeed(QueryDataFeed queryDataFeed) {
        queryDataFeeds.put(queryDataFeed.getQueryDataFeedID(), queryDataFeed);

        ArrayList<QueryDataFeed> queryDataFeedList;
        if (queryDataFeedsByDataFeedID.containsKey(queryDataFeed.getDataFeedID())) {
            queryDataFeedList = queryDataFeedsByDataFeedID.get(queryDataFeed.getDataFeedID());
        } else {
            queryDataFeedList = new ArrayList<QueryDataFeed>();
        }
        queryDataFeedList.add(queryDataFeed);

        queryDataFeedsByDataFeedID.put(queryDataFeed.getDataFeedID(), queryDataFeedList);

        ArrayList<QueryDataFeed> queryDataFeedByQueryIDList;
        if (queryDataFeedsByQueryID.containsKey(queryDataFeed.getQueryID())) {
            queryDataFeedByQueryIDList = queryDataFeedsByQueryID.get(queryDataFeed.getQueryID());
        } else {
            queryDataFeedByQueryIDList = new ArrayList<QueryDataFeed>();
        }
        queryDataFeedByQueryIDList.add(queryDataFeed);

        queryDataFeedsByQueryID.put(queryDataFeed.getQueryID(), queryDataFeedByQueryIDList);

        return queryDataFeed;
    }


    @Override
	public QueryDataFeed[] getQueryDataFeedByDataFeedID(int dataFeedID) {
        ArrayList<QueryDataFeed> list;
        if (queryDataFeedsByDataFeedID.containsKey(dataFeedID)) {
            list = queryDataFeedsByDataFeedID.get(dataFeedID);
        } else {
            list = new ArrayList<QueryDataFeed>();
        }
        QueryDataFeed[] rtn = list.toArray(new QueryDataFeed[list.size()]);
        Arrays.sort(rtn, new Comparator<QueryDataFeed>() {
            @Override
			public int compare(QueryDataFeed o1, QueryDataFeed o2) {
                return new Integer(o1.getQueryID()).compareTo(o2.getQueryID());
            }
        });

        return rtn;
    }

    @Override
	public QueryDataFeed[] getQueryDataFeedByQueryID(int queryID) {
        ArrayList<QueryDataFeed> list;
        if (queryDataFeedsByQueryID.containsKey(queryID)) {
            list = queryDataFeedsByQueryID.get(queryID);
        } else {
            list = new ArrayList<QueryDataFeed>();
        }
        return list.toArray(new QueryDataFeed[list.size()]);
    }

    @Override
	public void delete(QueryDataFeed queryDataFeed) {
        queryDataFeeds.remove(queryDataFeed.getQueryDataFeedID());

        ArrayList<QueryDataFeed> queryDataFeedList;
        if (queryDataFeedsByDataFeedID.containsKey(queryDataFeed.getDataFeedID())) {
            queryDataFeedList = queryDataFeedsByDataFeedID.get(queryDataFeed.getDataFeedID());
        } else {
            queryDataFeedList = new ArrayList<QueryDataFeed>();
        }
        queryDataFeedList.remove(queryDataFeed);

        queryDataFeedsByDataFeedID.put(queryDataFeed.getDataFeedID(), queryDataFeedList);

        ArrayList<QueryDataFeed> queryDataFeedByQueryIDList;
        if (queryDataFeedsByQueryID.containsKey(queryDataFeed.getQueryID())) {
            queryDataFeedByQueryIDList = queryDataFeedsByQueryID.get(queryDataFeed.getQueryID());
        } else {
            queryDataFeedByQueryIDList = new ArrayList<QueryDataFeed>();
        }
        queryDataFeedByQueryIDList.remove(queryDataFeed);

        queryDataFeedsByQueryID.put(queryDataFeed.getQueryID(), queryDataFeedByQueryIDList);

    }
}
