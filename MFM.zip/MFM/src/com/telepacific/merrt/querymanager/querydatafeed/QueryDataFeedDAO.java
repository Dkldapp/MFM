/**
 * <p>Title: QueryDataFeedDAO</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.querydatafeed;


import com.telepacific.merrt.config.InitSessionFactory;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeed;
import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeedManager;

import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.List;
import java.util.Vector;


public class QueryDataFeedDAO implements QueryDataFeedManager{
    public QueryDataFeedDAO() {

    }

    @Override
	public QueryDataFeed[] getQueryDataFeed() {
        System.out.println("########QueryDataFeedManagerDAO.getQueryDataFeed()########");
        List data = new Vector();
        Transaction tx = null;
        Session session = InitSessionFactory.getInstance().getCurrentSession();
        tx = session.beginTransaction();
        data = session.createQuery("select u from QueryDataFeed as u").list();
        tx.commit();
        QueryDataFeed[] rtn = (QueryDataFeed[]) data.toArray(new QueryDataFeed[data.size()]);
/*        Arrays.sort(rtn, new Comparator<QueryDataFeed>() {
            public int compare(QueryDataFeed o1, QueryDataFeed o2) {
                return o2.getQueryDataFeedName().compareTo(o1.getQueryDataFeedName());
            }
        });
*/
        return rtn;
    }

    @Override
	public QueryDataFeed getQueryDataFeed(int queryDataFeedID) {
        return null;
    }

    @Override
	public void reload() {

    }

    @Override
	public QueryDataFeed setQueryDataFeed(QueryDataFeed queryDataFeed) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();

            if (queryDataFeed.getQueryDataFeedID() <= 0) {
                session.save(queryDataFeed);
            } else {
                session.update(queryDataFeed);
            }
            tx.commit();
        } catch (Exception error) {
            error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
        return queryDataFeed;
    }


    @Override
	public QueryDataFeed[] getQueryDataFeedByDataFeedID(int dataFeedID) {
        return new QueryDataFeed[0];
    }

    @Override
	public QueryDataFeed[] getQueryDataFeedByQueryID(int queryID) {
        return new QueryDataFeed[0];
    }

    @Override
	public void delete(QueryDataFeed queryDataFeed) {
        Transaction tx = null;
        try {
            org.hibernate.Session session = InitSessionFactory.getInstance().getCurrentSession();
            tx = session.beginTransaction();
            session.delete(queryDataFeed);
            tx.commit();
        } catch (Exception error) {
            //error.printStackTrace();
            if (tx != null && tx.isActive()) tx.rollback();
        }
    }
}
