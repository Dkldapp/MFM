/**
 * <p>Title: QueryDataFeedManager</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.querymanager.querydatafeed;

import com.telepacific.merrt.querymanager.querydatafeed.QueryDataFeed;

public interface QueryDataFeedManager {
    public QueryDataFeed[] getQueryDataFeed();

    public QueryDataFeed getQueryDataFeed(int queryDataFeedID);

    public QueryDataFeed[] getQueryDataFeedByQueryID(int queryID);

    public QueryDataFeed[] getQueryDataFeedByDataFeedID(int dataFeedID);

    public QueryDataFeed setQueryDataFeed(QueryDataFeed queryDataFeed);

    public void reload();

    public void delete(QueryDataFeed queryDataFeed);
}
