package com.telepacific.merrt.service;

import org.apache.log4j.Logger;
import org.boris.winrun4j.AbstractService;
import org.boris.winrun4j.ServiceException;

import com.telepacific.merrt.mfm.MFMInitialize;

/**
 * A basic service.
 */
public class MerrtServiceTest extends AbstractService
{
 public	static Logger log = Logger.getLogger(MerrtServiceTest.class);
    public int serviceMain(String[] args) throws ServiceException {

            	//System.out.println(" Starting  Merrt Service");
            	//log.info(" Starting  Merrt Service");
                MFMInitialize.StartMFM();
        return 0;
    }
}
