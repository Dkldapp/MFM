package com.telepacific.merrt.validators;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.log4j.Logger;

import com.telepacific.merrt.config.MFMFeedHandlerStatus;
import com.telepacific.merrt.mfm.MFMInitialize;

/**
 * This Class is using for checking feed handler folders are exist or not and creating of feed handler folders if folders are not existed.
 * It also checks the available disk space and will update details.
 * @author HCL
 *
 */

public class FeedHandlerUtils {
	
	public static MFMFeedHandlerStatus mfmFeedHandlerStatus = null;
	
	static Logger log = Logger.getLogger(FeedHandlerUtils.class);
	
	public static boolean isFolderExist(String strFolderName){
				
			try{
			
				File fileFolder = new File (strFolderName);
				
				if (!fileFolder.exists()){

					fileFolder.mkdirs();
					new File (strFolderName+"\\err_file").mkdir();
					new File (strFolderName+"\\processed").mkdir();
					new File (strFolderName+"\\duplicate").mkdir();
				//	new File (strFolderName+"\\files_backup").mkdir();
					
				//	log.info(" All Data Files Folders are created");

				} else {
					
					File subFolder = new File (strFolderName+"\\err_file");
		        	if (!subFolder.exists())
		        		subFolder.mkdir();
		        	
		        	 subFolder = new File (strFolderName+"\\processed");
		        	 if (!subFolder.exists())
		         		subFolder.mkdir();
		        	 
		        	 subFolder = new File (strFolderName+"\\duplicate");
		        	 if (!subFolder.exists())
		         		subFolder.mkdir();
		        	 
		        	 
//		        	 subFolder = new File (strFolderName+"\\files_backup");
//		        	 if (!subFolder.exists())
//		         		subFolder.mkdir();
//		        	 
		        	 
		        	 
		        	//	log.info(" All Data Files Sub Folders are created");
				}	
				
			
			} catch(Exception e){
				log.error(e.toString());
				
			}
		return true;
	}
	
	public static boolean fileMove(String strSourceDirectory, String strFileName, String destination){
	
		boolean success = false;
		boolean deleted;
		// File (or directory) to be moved
		try {
			
			
			
			File file = new File(strSourceDirectory);	
			// Destination directory
			
			File dir = new File(strSourceDirectory.subSequence(0, strSourceDirectory.lastIndexOf(strFileName))+destination);
			// Move file to new directory
			File fileCheck= new File(strSourceDirectory.subSequence(0, strSourceDirectory.lastIndexOf(strFileName))+destination+"\\"+strFileName);
			
			if (fileCheck.exists()){
				fileCheck.delete();
			}
			
		
			success = file.renameTo(new File(dir, file.getName()));
			deleted=file.delete();
			
			if (!success) {
				log.info(" File was not moved to specified directory ");
			}else
				
				log.info(" File was moved to specified directory ");

		
		}catch (Exception e){
			
			log.error(" Error: File was not moved to specified directory " +e.toString());
		}
		
		return success;
	}
	
	
	public static void copyfile(String srFile, String dtFile){
		
		log.info("Source path"+srFile);
		log.info("Dest path"+dtFile);
		try{
		  File f1 = new File(srFile);
		  File f2 = new File(dtFile);
		  InputStream in = new FileInputStream(f1);
		  
		  //For Append the file.
		//  OutputStream out = new FileOutputStream(f2,true);

		  //For Overwrite the file.
		  OutputStream out = new FileOutputStream(f2);

		  byte[] buf = new byte[1024];
		  int len;
		  while ((len = in.read(buf)) > 0){
		  out.write(buf, 0, len);
		  }
		  in.close();
		  out.close();
		  log.info("File copied. -"+ dtFile);
		  }
		  catch(FileNotFoundException ex){
			  log.error("File copied FileNotFoundException -" +ex.getMessage());
		  }
		  catch(IOException e){
			  log.error("File copied IOException -"+e.getMessage());  
		}
	}	
	public static boolean fileCopy(String strSourceDirectory, String strFileName, String destination){
		
		boolean success = false;
		
		// File (or directory) to be moved
		try {
			
			
			
			File file = new File(strSourceDirectory);	
			// Destination directory
			
			File dir = new File(strSourceDirectory.subSequence(0, strSourceDirectory.lastIndexOf(strFileName))+destination);
			// Move file to new directory
			File fileCheck= new File(strSourceDirectory.subSequence(0, strSourceDirectory.lastIndexOf(strFileName))+destination+"\\"+strFileName);
			
			if (fileCheck.exists()){
				fileCheck.delete();
			}
			
		
			//success = file.renameTo(new File(dir, file.getName()));
		
			
			if (!success) {
				log.info(" File was not copied  to specified directory ");
			}else
				
				log.info(" File was copied to specified directory ");

		
		}catch (Exception e){
			
			log.error(" Error: File was not copied to specified directory " +e.toString());
		}
		
		return success;
	}
	
	
	
	
	
	public static String getMFMPath(String path) {
		if(MFMInitialize.remoteDrive != null) {
        	return MFMInitialize.remoteDrive + ":" + path.substring(path.toLowerCase().indexOf("\\" + MFMInitialize.remoteSharedDirectory + "\\")+MFMInitialize.remoteSharedDirectory.length()+1);
        } else {
        	return path;
        }
	}

	
	public static void main(String arg[]){
		
	/*	System.out.println(System.getProperty("user.dir"));
		String strCurrentDirectory = System.getProperty("user.dir");
		strCurrentDirectory = strCurrentDirectory.substring(0, 1);
		strCurrentDirectory = strCurrentDirectory+"\\udash_logs";
		File file = new File(strCurrentDirectory);
		file.mkdirs();
		*/
		
		
	}
}
