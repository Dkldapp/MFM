/**
 * <p>Title: TableStatistics</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.webmanager;

import com.telepacific.merrt.feedmanager.tableindex.TableIndex;
import com.telepacific.merrt.webmanager.TableStatistics;
import com.telepacific.merrt.webmanager.TableStatisticsData;

import java.util.*;

public class TableStatistics {
    Hashtable<String, Hashtable<Date, Hashtable<Long, TableIndex>>> tables = new Hashtable<String, Hashtable<Date, Hashtable<Long, TableIndex>>>();
    Hashtable<String, String[]> table_values = new Hashtable<String, String[]>();

    public TableStatistics() {

    }

    long date_from_long = 0;
    long date_to_long = 0;
    boolean byweekday = true;

    public void addStatistic(String field_values[], TableIndex tableIndex) {
        Calendar cal = Calendar.getInstance();
        Date date;
        if (byDate) {
            date = tableIndex.getUsageDate();
        } else {
            date = new Date();
        }
        cal.setTimeInMillis(date.getTime());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        date = new Date(cal.getTimeInMillis());
        if (date.getTime() > date_to_long) {
            date_to_long = date.getTime();
        }
        if (date.getTime() < date_from_long || date_from_long==0) {
            date_from_long = date.getTime();
        }
        String field_key = "";
        for (String field : field_values) {
            field_key += field + "_";
        }
        table_values.put(field_key, field_values);

        Hashtable<Date, Hashtable<Long, TableIndex>> key_tables;
        Hashtable<Long, TableIndex> date_tables;
        if (tables.containsKey(field_key)) {
            key_tables = tables.get(field_key);
        } else {
            key_tables = new Hashtable<Date, Hashtable<Long, TableIndex>>();
        }

        if (key_tables.containsKey(date)) {
            date_tables = key_tables.get(date);
        } else {
            date_tables = new Hashtable<Long, TableIndex>();
        }
        date_tables.put(tableIndex.getTableIndexID(), tableIndex);
        key_tables.put(date, date_tables);
        tables.put(field_key, key_tables);
    }
    public String getFieldValues(String key) {
        String[] fields = table_values.get(key);
        String rtn = "";
        int i = 0;
        for (String vals : fields) {
            rtn += (i != 0 ? ", " : "") + vals;
            i++;
        }

        return rtn;
    }

    public boolean isByWeekday() {
        return byweekday;
    }

    public void setByWeekday(boolean byweekday) {
        this.byweekday = byweekday;
    }

    private boolean byDate = true;

    public boolean isByDate() {
        return byDate;
    }

    public void setByDate(boolean byDate) {
        this.byDate = byDate;
    }

    public TableStatisticsData[] run() {
        Hashtable<Date, Hashtable<Long, TableIndex>> key_tables;
        Hashtable<Long, TableIndex> date_tables;
        //Date usage_date;
        String output;
        long records;
        long networkduration;
        long billingduration;
        Calendar cal = Calendar.getInstance();


        Hashtable<Date, Hashtable<String, TableIndex>> stats = new Hashtable<Date, Hashtable<String, TableIndex>>();
        Hashtable<String, TableIndex> daily_stats;
        Date date;
        Date date_to;
        Date date_from;

        long date_diff;
        cal.setTimeInMillis(date_to_long);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        date_to = new Date(cal.getTimeInMillis());

        cal.setTimeInMillis(date_from_long);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        date_from = new Date(cal.getTimeInMillis());
//        System.out.println("Date From: " + date_from + " - " + date_to);
        date_diff = (date_to.getTime()) - (date_from.getTime());
        date_diff = date_diff / 86400000;
        long ind = 0;
        cal.setTimeInMillis(date_from.getTime());
        date_diff = 0;
        while (ind<date_to_long) {
            ind = cal.getTimeInMillis();
            date_diff ++;
            cal.add(Calendar.DATE, 1);
        }
//        System.out.println(date_diff);
        cal.setTimeInMillis(date_from.getTime());
        TableIndex tbl;

        for (int i = 0; i < date_diff; i++) {
            date = new Date(cal.getTimeInMillis());
            daily_stats = new Hashtable<String, TableIndex>();

            for (String field_key : tables.keySet()) {
                tbl = new TableIndex();
                tbl.setRecords(0);
                tbl.setNetworkMilliseconds(0);
                tbl.setBillingMilliseconds(0);
                daily_stats.put(field_key, tbl);
            }
            stats.put(date, daily_stats);
            cal.add(Calendar.DATE, 1);
        }

        for (String field_key : tables.keySet()) {
            key_tables = tables.get(field_key);
            for (Date usage_date : key_tables.keySet()) {
                output = getFieldValues(field_key);
                date_tables = key_tables.get(usage_date);
                output += " - " + usage_date;
                records = 0;
                networkduration = 0;
                billingduration = 0;
                for (TableIndex table_index : date_tables.values().toArray(new TableIndex[date_tables.size()])) {
                    records += table_index.getRecords();
                    networkduration += table_index.getNetworkMilliseconds();
                    billingduration += table_index.getBillingMilliseconds();
                }
                if (stats.containsKey(usage_date)) {
                    daily_stats = stats.get(usage_date);
                    tbl = new TableIndex();
                    tbl.setRecords(records);
                    tbl.setNetworkMilliseconds(networkduration);
                    tbl.setBillingMilliseconds(billingduration);

                    daily_stats.put(field_key, tbl);
                }


                output += " - " + records;
                //                System.out.println(output);
            }

        }
        Date[] stat_keys = stats.keySet().toArray(new Date[stats.size()]);
        String[] field_keys;
//        Arrays.sort(stat_keys, Collections.reverseOrder());
        Arrays.sort(stat_keys);

        Hashtable<Date, Hashtable<String, TableIndex>> stats_avg = new Hashtable<Date, Hashtable<String, TableIndex>>();
        Hashtable<String, TableIndex[]> daily_stats_avg = new Hashtable<String, TableIndex[]>();
        TableIndex[] tbl_avg;
        long count;
        int weekday;
        long avg;
        long avg_billing;
        long avg_network;

        TableStatisticsData data;
        ArrayList<TableStatisticsData> dataa = new ArrayList<TableStatisticsData>();
        for (Date usage_date : stat_keys) {

            field_keys = stats.get(usage_date).keySet().toArray(new String[stats.get(usage_date).size()]);
            Arrays.sort(field_keys);
            cal.setTimeInMillis(usage_date.getTime());
            if (byweekday) {
                weekday =  cal.get(Calendar.DAY_OF_WEEK);
            } else {
                weekday = 0;
            }

            for (String field_key : field_keys) {
                tbl = stats.get(usage_date).get(field_key);
                if (daily_stats_avg.containsKey(weekday + "_" + field_key)) {
                    tbl_avg = daily_stats_avg.get(weekday + "_" + field_key);
                } else {
                    tbl_avg = new TableIndex[5];
                    tbl_avg[0] = new TableIndex();
                    tbl_avg[1] = new TableIndex();
                    tbl_avg[2] = new TableIndex();
                    tbl_avg[3] = new TableIndex();
                    tbl_avg[4] = new TableIndex();
                }
                tbl_avg[4].setRecords(tbl_avg[3].getRecords());
                tbl_avg[3].setRecords(tbl_avg[2].getRecords());
                tbl_avg[2].setRecords(tbl_avg[1].getRecords());
                tbl_avg[1].setRecords(tbl_avg[0].getRecords());
                tbl_avg[0].setRecords(0);

                tbl_avg[4].setBillingMilliseconds(tbl_avg[3].getBillingMilliseconds());
                tbl_avg[3].setBillingMilliseconds(tbl_avg[2].getBillingMilliseconds());
                tbl_avg[2].setBillingMilliseconds(tbl_avg[1].getBillingMilliseconds());
                tbl_avg[1].setBillingMilliseconds(tbl_avg[0].getBillingMilliseconds());

                tbl_avg[4].setNetworkMilliseconds(tbl_avg[3].getNetworkMilliseconds());
                tbl_avg[3].setNetworkMilliseconds(tbl_avg[2].getNetworkMilliseconds());
                tbl_avg[2].setNetworkMilliseconds(tbl_avg[1].getNetworkMilliseconds());
                tbl_avg[1].setNetworkMilliseconds(tbl_avg[0].getNetworkMilliseconds());

                tbl_avg[0].setBillingMilliseconds(tbl.getBillingMilliseconds());
                tbl_avg[0].setNetworkMilliseconds(tbl.getNetworkMilliseconds());

                avg = 0;
                avg_billing = 0;
                avg_network = 0;
                for (int i=1;i<tbl_avg.length;i++) {
                    avg += tbl_avg[i].getRecords();
                    avg_billing += tbl_avg[i].getBillingMilliseconds();
                    avg_network += tbl_avg[i].getNetworkMilliseconds();
                }
                tbl_avg[0].setRecords(tbl.getRecords());

//                tbl_avg[0].setRecords(avg / tbl_avg.length);
                tbl_avg[0].setBillingMilliseconds(tbl.getBillingMilliseconds());
                tbl_avg[0].setNetworkMilliseconds(tbl.getNetworkMilliseconds());


                avg = avg / (tbl_avg.length - 1);
                daily_stats_avg.put(weekday + "_" + field_key, tbl_avg);
                data = new TableStatisticsData();
                data.setBillingDuration(tbl.getBillingMilliseconds());
                data.setNetworkDuration(tbl.getNetworkMilliseconds());
                data.setRecords(tbl.getRecords());
                data.setRecordsAvg(avg);
                data.setBillingDurationAvg(avg_billing);
                data.setNetworkDurationAvg(avg_network);
                data.setValues(table_values.get(field_key));
                data.setUsageDate(usage_date);
                dataa.add(data);
//                System.out.println(getFieldValues(field_key) + " - " + usage_date + " - " + tbl.getRecords() + " - " + tbl.getNetworkMilliseconds() + " - " + tbl.getBillingMilliseconds() + " - " + avg);
            }
        }
        TableStatisticsData[] rtn = dataa.toArray(new TableStatisticsData[dataa.size()]);
        Arrays.sort(rtn, new Comparator<TableStatisticsData>() {
            @Override
			public int compare(TableStatisticsData o1, TableStatisticsData o2) {
                return o2.getUsageDate().compareTo(o1.getUsageDate());
            }
        });

        return rtn;
    }

    public static void main(String[] args) {
        TableStatistics stat = new TableStatistics();
        stat.setByDate(false);
        stat.setByWeekday(false);
        String[] fields = new String[2];
        fields[0] = "40625";
        fields[1] = "110";
        String[] fieldsb = new String[2];
        fieldsb[0] = "40625";
        fieldsb[1] = "142";
        Date date = new Date();
        TableIndex tableIndex = new TableIndex();
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(new Date().getTime());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        int flip =0;
        for (int i=0;i<10;i++) {
            tableIndex = new TableIndex();
            tableIndex.setUsageDate(new Date(cal.getTimeInMillis()));
            tableIndex.setRecords(50 + i);
            tableIndex.setNetworkMilliseconds(1);
            tableIndex.setTableIndexID(i);
            flip = 0;
            stat.addStatistic(fieldsb, tableIndex);
            cal.add(Calendar.DATE, 7);
        }
        TableStatisticsData[] dataa = stat.run();
        String[] values;
        String valuess;
        for (TableStatisticsData data : dataa) {
            values = data.getValues();
            valuess = "";
            for (String value : values) {
                valuess += value + " - ";
            }
            System.out.println(valuess + data.getUsageDate() + " - " + data.getRecords() + " - " + data.getRecordsAvg());
        }
    }
}
