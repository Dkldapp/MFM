/**
 * <p>Title: TableStatisticsData</p>
 * <p>Description:</p>
 * @author Bradley Gude
 * @version 1.0
 */

package com.telepacific.merrt.webmanager;

import java.util.Date;

public class TableStatisticsData {
    private String[] values;
    private Date usageDate;
    private long records;
    private long networkDuration;
    private long billingDuration;

    private long recordsAvg;
    private long networkDurationAvg;
    private long billingDurationAvg;

    public TableStatisticsData() {

    }

    public long getBillingDuration() {
        return billingDuration;
    }

    public void setBillingDuration(long billingDuration) {
        this.billingDuration = billingDuration;
    }

    public long getBillingDurationAvg() {
        return billingDurationAvg;
    }

    public void setBillingDurationAvg(long billingDurationAvg) {
        this.billingDurationAvg = billingDurationAvg;
    }

    public long getNetworkDuration() {
        return networkDuration;
    }

    public void setNetworkDuration(long networkDuration) {
        this.networkDuration = networkDuration;
    }

    public long getNetworkDurationAvg() {
        return networkDurationAvg;
    }

    public void setNetworkDurationAvg(long networkDurationAvg) {
        this.networkDurationAvg = networkDurationAvg;
    }

    public long getRecords() {
        return records;
    }

    public void setRecords(long records) {
        this.records = records;
    }

    public long getRecordsAvg() {
        return recordsAvg;
    }

    public void setRecordsAvg(long recordsAvg) {
        this.recordsAvg = recordsAvg;
    }

    public Date getUsageDate() {
        return usageDate;
    }

    public void setUsageDate(Date usageDate) {
        this.usageDate = usageDate;
    }

    public String[] getValues() {
        return values;
    }

    public void setValues(String[] values) {
        this.values = values;
    }
}
