package org.boris.winrun4j.test;

import org.boris.winrun4j.AbstractService;
import org.boris.winrun4j.EventLog;
import org.boris.winrun4j.ServiceException;
import com.telepacific.merrt.mfm.MFMInitialize;

/**
 * A basic service.
 */
public class MerrtService extends AbstractService
{
	//private volatile boolean shutdown = false;
	
    public int serviceMain(String[] args) throws ServiceException {
       
        MFMInitialize.StartMFM();
        int count =0;
        while (!shutdown) {
            try {
            	
                Thread.sleep(6000);
            } catch (InterruptedException e) {
            	System.out.println(" Thread Interuppted " +e.getLocalizedMessage());
            }

            if (++count % 10 == 0)
                EventLog.report("WinRun4J Test Service", EventLog.INFORMATION,
                        "Ping");
        }
        MFMInitialize.mfmShutDown(); 
        
        return 0;
    }
}
