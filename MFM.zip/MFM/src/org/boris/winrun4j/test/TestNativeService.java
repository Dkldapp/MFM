package org.boris.winrun4j.test;

public class TestNativeService
{
    public static void main(String[] args) throws Exception {
    }
}
